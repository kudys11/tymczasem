# Dokumenty wspólnoty 2.9.0 MVP

Dodaje panel:

`/admin/raporty/dokumenty-wspolnoty/`

Bez migracji. Wykorzystuje istniejące modele:
- DocumentCategory
- Document
- DocumentAttachment

Uruchom:

```bash
cd /opt/_docker-compose/wspolnota
unzip dokumenty_wspolnoty_2_9_0_mvp.zip
chmod +x wdroz_dokumenty_wspolnoty_2_9_0_mvp.sh
./wdroz_dokumenty_wspolnoty_2_9_0_mvp.sh
```
