#!/usr/bin/env bash
set -euo pipefail

cd /opt/_docker-compose/wspolnota

echo "== Backup =="
mkdir -p _backup_dokumenty_2_9_0
cp -f apps/audit/admin.py _backup_dokumenty_2_9_0/admin.py.bak || true
cp -f apps/audit/admin_reports_center.py _backup_dokumenty_2_9_0/admin_reports_center.py.bak || true
cp -f apps/audit/admin_documents_panel.py _backup_dokumenty_2_9_0/admin_documents_panel.py.bak 2>/dev/null || true

echo "== Tworzę panel dokumentów wspólnoty =="
cat > apps/audit/admin_documents_panel.py <<'PY'
from datetime import date

from django.contrib import admin
from django.db.models import Count
from django.http import HttpResponse
from django.urls import path


def _year_options(selected_year):
    current = date.today().year
    years = range(current - 5, current + 2)
    html = '<option value="all">Wszystkie</option>'
    for y in years:
        sel = "selected" if str(y) == str(selected_year) else ""
        html += f'<option value="{y}" {sel}>{y}</option>'
    return html


def documents_panel_view(request):
    category_filter = request.GET.get("category") or "all"
    visibility_filter = request.GET.get("visibility") or "all"
    year_filter = request.GET.get("year") or "all"

    try:
        from apps.documents.models import Document, DocumentCategory, DocumentAttachment

        qs = (
            Document.objects
            .select_related("community", "category", "uploaded_by")
            .annotate(attachments_count=Count("attachments", distinct=True))
            .order_by("-document_date", "-created_at", "-id")
        )

        if category_filter != "all":
            qs = qs.filter(category_id=category_filter)

        if visibility_filter != "all":
            qs = qs.filter(visibility=visibility_filter)

        if year_filter != "all":
            qs = qs.filter(document_date__year=year_filter)

        docs = list(qs)
        all_docs = list(Document.objects.select_related("category").annotate(attachments_count=Count("attachments", distinct=True)))
        categories = list(DocumentCategory.objects.filter(is_active=True).order_by("sort_order", "name"))
        attachments_count = DocumentAttachment.objects.filter(is_active=True).count()

    except Exception:
        docs = []
        all_docs = []
        categories = []
        attachments_count = 0

    public_docs = [x for x in all_docs if getattr(x, "visibility", "") == "public" or getattr(x, "is_public", False)]
    board_docs = [x for x in all_docs if getattr(x, "visibility", "") == "board_only"]
    selected_docs = [x for x in all_docs if getattr(x, "visibility", "") == "selected_apartments"]
    current_year_docs = [
        x for x in all_docs
        if getattr(x, "document_date", None) and x.document_date.year == date.today().year
    ]
    with_attachments = [x for x in all_docs if getattr(x, "attachments_count", 0)]

    category_options = '<option value="all">Wszystkie</option>'
    for cat in categories:
        selected = "selected" if str(cat.id) == str(category_filter) else ""
        category_options += f'<option value="{cat.id}" {selected}>{cat.name}</option>'

    def selected(value, current):
        return "selected" if value == current else ""

    def visibility_label(doc):
        try:
            return doc.get_visibility_display()
        except Exception:
            return getattr(doc, "visibility", "-")

    def file_link(doc):
        if getattr(doc, "file", None):
            try:
                return f'<a href="{doc.file.url}" target="_blank" rel="noopener">Otwórz plik ↗</a>'
            except Exception:
                return "-"
        return "-"

    def admin_link(doc):
        return f'<a href="/admin/documents/document/{doc.id}/change/" target="_blank" rel="noopener">Edycja ↗</a>'

    def row(doc, index):
        category = doc.category.name if doc.category else "-"
        doc_date = doc.document_date or "-"
        uploaded = doc.uploaded_by or "-"
        public_badge = '<span class="badge ok">Tak</span>' if doc.is_public else '<span class="badge mutedb">Nie</span>'
        return f"""
        <tr>
          <td>{index}</td>
          <td>{doc_date}</td>
          <td>{category}</td>
          <td><strong>{doc.title}</strong><br><span class="muted">{doc.description or ""}</span></td>
          <td>{visibility_label(doc)}</td>
          <td>{public_badge}</td>
          <td>{getattr(doc, "attachments_count", 0)}</td>
          <td>{uploaded}</td>
          <td>{file_link(doc)}</td>
          <td>{admin_link(doc)}</td>
        </tr>
        """

    rows_html = "".join(row(x, i + 1) for i, x in enumerate(docs))
    if not rows_html:
        rows_html = '<tr><td colspan="10">Brak dokumentów dla wybranych filtrów.</td></tr>'

    html = f"""
    <!doctype html>
    <html lang="pl">
    <head>
      <meta charset="utf-8">
      <title>Dokumenty wspólnoty</title>
      <style>
        body{{font-family:Arial,sans-serif;padding:18px;color:#0f172a;background:#fff}}
        .topbar{{display:flex;justify-content:space-between;gap:16px;align-items:flex-start}}
        h1{{margin:0 0 4px 0;font-size:32px}} h2{{margin-top:22px}}
        .muted{{color:#64748b}}
        .box{{border:1px solid #dfe5ec;padding:12px;border-radius:8px;background:#f8fafc}}
        .filters{{display:flex;gap:8px;flex-wrap:wrap;align-items:end}}
        .filters label{{display:flex;flex-direction:column;font-size:12px;color:#64748b}}
        select,input{{padding:8px 10px}} button{{padding:9px 14px;cursor:pointer}}
        .links{{display:flex;gap:8px;flex-wrap:wrap;margin:14px 0}}
        .links a, td a{{display:inline-block;border:1px solid #cbd5e1;padding:7px 10px;border-radius:6px;text-decoration:none;color:#0f172a;background:#fff}}
        .grid{{display:grid;grid-template-columns:repeat(6,minmax(140px,1fr));gap:12px;margin:16px 0}}
        .card{{border:1px solid #dfe5ec;border-radius:10px;padding:14px;background:#fff;box-shadow:0 1px 2px rgba(15,23,42,.04)}}
        .card strong{{display:block;font-size:24px;margin-top:6px}}
        table{{width:100%;border-collapse:collapse;margin-top:12px}}
        th,td{{border:1px solid #dfe5ec;padding:8px 10px;text-align:left;vertical-align:top}}
        th{{background:#f1f5f9}}
        .badge{{display:inline-block;border-radius:999px;padding:4px 9px;font-weight:700;font-size:12px}}
        .ok{{background:#ecfdf5;color:#0a8f3c;border:1px solid #bbf7d0}}
        .mutedb{{background:#f1f5f9;color:#64748b;border:1px solid #cbd5e1}}
        .note{{color:#64748b;margin-top:12px;font-size:13px}}
        @media(max-width:1200px){{.grid{{grid-template-columns:repeat(3,1fr)}} .topbar{{display:block}} .box{{margin-top:12px}}}}
        @media print{{.box,.links,td a{{display:none}} @page{{size:A4 landscape;margin:8mm}} body{{font-size:8px;padding:0}} h1{{font-size:18px}} th,td{{padding:3px 4px}} .grid{{grid-template-columns:repeat(3,1fr)}}}}
      </style>
    </head>
    <body>
      <div class="topbar">
        <div>
          <h1>📚 Dokumenty wspólnoty</h1>
          <div class="muted">Uchwały, protokoły, umowy, sprawozdania, skany i załączniki</div>
        </div>
        <form class="box" method="get">
          <div class="filters">
            <label>Kategoria
              <select name="category">{category_options}</select>
            </label>
            <label>Widoczność
              <select name="visibility">
                <option value="all" {selected("all", visibility_filter)}>Wszystkie</option>
                <option value="board_only" {selected("board_only", visibility_filter)}>Tylko zarząd</option>
                <option value="public" {selected("public", visibility_filter)}>Publiczne</option>
                <option value="selected_apartments" {selected("selected_apartments", visibility_filter)}>Wybrane lokale</option>
                <option value="private" {selected("private", visibility_filter)}>Prywatne</option>
              </select>
            </label>
            <label>Rok
              <select name="year">{_year_options(year_filter)}</select>
            </label>
            <button type="submit">Pokaż</button>
          </div>
        </form>
      </div>

      <div class="links">
        <a href="/admin/raporty/" target="_blank" rel="noopener">Dashboard Zarządcy ↗</a>
        <a href="/admin/documents/document/add/" target="_blank" rel="noopener">Dodaj dokument ↗</a>
        <a href="/admin/documents/document/" target="_blank" rel="noopener">Admin dokumentów ↗</a>
        <a href="/admin/documents/documentcategory/" target="_blank" rel="noopener">Kategorie ↗</a>
        <a href="/admin/documents/documentattachment/add/" target="_blank" rel="noopener">Dodaj załącznik ↗</a>
        <a href="#" onclick="window.print(); return false;">PDF listy</a>
      </div>

      <div class="grid">
        <div class="card">Wszystkie<strong>{len(all_docs)}</strong></div>
        <div class="card">Publiczne<strong>{len(public_docs)}</strong></div>
        <div class="card">Tylko zarząd<strong>{len(board_docs)}</strong></div>
        <div class="card">Wybrane lokale<strong>{len(selected_docs)}</strong></div>
        <div class="card">Z załącznikami<strong>{len(with_attachments)}</strong></div>
        <div class="card">Bieżący rok<strong>{len(current_year_docs)}</strong></div>
      </div>

      <h2>Lista dokumentów</h2>
      <table>
        <tr>
          <th>#</th><th>Data</th><th>Kategoria</th><th>Tytuł / opis</th><th>Widoczność</th>
          <th>Publiczny</th><th>Zał.</th><th>Dodał</th><th>Plik</th><th>Akcje</th>
        </tr>
        {rows_html}
      </table>

      <p class="note">Panel korzysta z istniejących modeli Document, DocumentCategory i DocumentAttachment. Nie wymaga migracji.</p>
    </body>
    </html>
    """
    return HttpResponse(html)


_original_get_urls_documents_panel = admin.site.get_urls


def get_urls_documents_panel():
    urls = _original_get_urls_documents_panel()
    custom = [
        path("raporty/dokumenty-wspolnoty/", admin.site.admin_view(documents_panel_view), name="community_documents_panel"),
    ]
    return custom + urls


if not getattr(admin.site, "_community_documents_panel_patched", False):
    admin.site.get_urls = get_urls_documents_panel
    admin.site._community_documents_panel_patched = True
PY

echo "== Podpinam import w audit/admin.py =="
python3 - <<'PY'
from pathlib import Path

p = Path("apps/audit/admin.py")
txt = p.read_text(encoding="utf-8")
line = "from . import admin_documents_panel  # noqa"
if line not in txt:
    txt = txt.rstrip() + "\n\n# Etap 2.9.0 - panel dokumentów wspólnoty\n" + line + "\n"
    p.write_text(txt, encoding="utf-8")
    print("OK: dodano import panelu dokumentów")
else:
    print("OK: import już istnieje")
PY

echo "== Dodaję link do Centrum raportów =="
python3 - <<'PY'
from pathlib import Path

p = Path("apps/audit/admin_reports_center.py")
txt = p.read_text(encoding="utf-8")

card = """
      <div class="report-card">
        <h2>📚 Dokumenty wspólnoty</h2>
        <p>Uchwały, protokoły, umowy, sprawozdania, skany i załączniki wspólnoty.</p>
        <a href="/admin/raporty/dokumenty-wspolnoty/?year=all" target="_blank" rel="noopener">Otwórz panel ↗</a>
        <a href="/admin/documents/document/add/" target="_blank" rel="noopener">Dodaj dokument ↗</a>
      </div>
"""

if "/admin/raporty/dokumenty-wspolnoty/" not in txt:
    marker = """
      <div class="report-card">
        <h2>📘 Sprawozdanie roczne</h2>
        <p>Zbiorcze sprawozdanie wspólnoty: finanse, salda, media, zobowiązania i alerty.</p>
        <a href="/admin/raporty/sprawozdanie-roczne/?date={default_date}" target="_blank" rel="noopener">Otwórz raport ↗</a>
      </div>
"""
    if marker in txt:
        txt = txt.replace(marker, marker + "\n" + card, 1)
        print("OK: dodano kafelek Dokumenty wspólnoty po Sprawozdaniu rocznym")
    else:
        marker2 = '    <h2 class="section-title">⚡ Szybkie akcje</h2>'
        txt = txt.replace(marker2, card + "\n" + marker2, 1)
        print("OK: dodano kafelek Dokumenty wspólnoty przed Szybkimi akcjami")
else:
    print("OK: link dokumentów już istnieje")

p.write_text(txt, encoding="utf-8")
PY

echo "== Rebuild =="
docker compose down
docker compose build --no-cache
docker compose up -d

echo "== Czekam na start =="
sleep 15

echo "== Check =="
docker compose exec web python manage.py check

echo "== Kontrola URL =="
docker compose exec web python manage.py shell -c "from django.urls import reverse; print(reverse('admin:community_documents_panel'))"

echo "GOTOWE: Dokumenty wspólnoty 2.9.0 MVP."
