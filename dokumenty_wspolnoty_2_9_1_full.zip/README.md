# Dokumenty wspólnoty 2.9.1 FULL

Dodaje:
- Panel dokumentów wspólnoty
- Rejestr uchwał
- Rejestr umów
- Rejestr protokołów
- Filtrowanie po kategorii, roku, widoczności
- Powiązanie z lokalami
- Obsługę załączników
- Ulepszony admin dokumentów
- Automatyczne utworzenie kategorii bazowych

Uruchom:

```bash
cd /opt/_docker-compose/wspolnota
unzip dokumenty_wspolnoty_2_9_1_full.zip
chmod +x wdroz_dokumenty_wspolnoty_2_9_1_full.sh
./wdroz_dokumenty_wspolnoty_2_9_1_full.sh
```
