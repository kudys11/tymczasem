#!/usr/bin/env bash
set -euo pipefail

cd /opt/_docker-compose/wspolnota

echo "== Backup =="
mkdir -p _backup_dokumenty_2_9_1_full
cp -f apps/audit/admin.py _backup_dokumenty_2_9_1_full/audit_admin.py.bak || true
cp -f apps/audit/admin_reports_center.py _backup_dokumenty_2_9_1_full/admin_reports_center.py.bak || true
cp -f apps/audit/admin_documents_panel.py _backup_dokumenty_2_9_1_full/admin_documents_panel.py.bak 2>/dev/null || true
cp -f apps/documents/admin.py _backup_dokumenty_2_9_1_full/documents_admin.py.bak || true

echo "== Ulepszam admin dokumentów =="
cat > apps/documents/admin.py <<'PY'
from django.contrib import admin
from django.utils.html import format_html

from .models import DocumentCategory, Document


@admin.register(DocumentCategory)
class DocumentCategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "community", "is_active", "sort_order")
    list_filter = ("community", "is_active")
    search_fields = ("name",)
    ordering = ("community", "sort_order", "name")


try:
    from .models import DocumentAttachment
except Exception:
    DocumentAttachment = None


class DocumentAttachmentInline(admin.TabularInline):
    model = DocumentAttachment
    extra = 0
    fields = ("title", "attachment_type", "file", "is_active", "created_at")
    readonly_fields = ("created_at",) if DocumentAttachment else ()


@admin.register(Document)
class DocumentAdmin(admin.ModelAdmin):
    list_display = (
        "title",
        "community",
        "category",
        "document_date",
        "visibility",
        "is_public",
        "created_at",
        "file_link",
    )
    list_filter = ("community", "category", "visibility", "is_public", "document_date", "created_at")
    search_fields = ("title", "description", "category__name", "community__name")
    filter_horizontal = ("apartments",)
    readonly_fields = ("created_at", "updated_at", "file_link")
    date_hierarchy = "document_date"
    ordering = ("-document_date", "-created_at", "-id")
    fieldsets = (
        ("Podstawowe dane", {
            "fields": ("community", "category", "title", "description", "file", "file_link", "document_date")
        }),
        ("Widoczność", {
            "fields": ("visibility", "is_public", "apartments", "visible_from", "visible_to")
        }),
        ("System", {
            "fields": ("uploaded_by", "created_at", "updated_at")
        }),
    )
    inlines = [DocumentAttachmentInline] if DocumentAttachment else []

    def file_link(self, obj):
        if obj and obj.file:
            return format_html('<a href="{}" target="_blank" rel="noopener">Otwórz plik ↗</a>', obj.file.url)
        return "-"

    file_link.short_description = "Plik"

    def save_model(self, request, obj, form, change):
        if not obj.uploaded_by_id:
            obj.uploaded_by = request.user
        super().save_model(request, obj, form, change)


if DocumentAttachment:

    @admin.register(DocumentAttachment)
    class DocumentAttachmentAdmin(admin.ModelAdmin):
        list_display = (
            "title",
            "attachment_type",
            "document",
            "expense_document",
            "is_active",
            "created_at",
            "file_link",
        )
        list_filter = ("attachment_type", "is_active", "created_at")
        search_fields = (
            "title",
            "description",
            "document__title",
            "expense_document__document_number",
            "expense_document__vendor__name",
        )
        readonly_fields = ("created_at", "updated_at", "file_link")
        ordering = ("-created_at", "-id")

        def file_link(self, obj):
            if obj and obj.file:
                return format_html('<a href="{}" target="_blank" rel="noopener">Otwórz plik ↗</a>', obj.file.url)
            return "-"

        file_link.short_description = "Plik"
PY

echo "== Tworzę panel Dokumenty FULL =="
cat > apps/audit/admin_documents_panel.py <<'PY'
from datetime import date

from django.contrib import admin
from django.db.models import Count
from django.http import HttpResponse
from django.urls import path


DOC_KEYWORDS = {
    "all": [],
    "resolutions": ["uchwa"],
    "contracts": ["umow", "umowa", "kontrakt"],
    "protocols": ["protok"],
    "reports": ["sprawozd"],
    "invoices": ["faktur", "skan"],
}


def _year_options(selected_year):
    current = date.today().year
    years = range(current - 5, current + 2)
    html = '<option value="all">Wszystkie</option>'
    for y in years:
        sel = "selected" if str(y) == str(selected_year) else ""
        html += f'<option value="{y}" {sel}>{y}</option>'
    return html


def _selected(value, current):
    return "selected" if value == current else ""


def _safe_file_link(file_obj):
    if file_obj:
        try:
            return f'<a href="{file_obj.url}" target="_blank" rel="noopener">Otwórz plik ↗</a>'
        except Exception:
            return "-"
    return "-"


def _visibility_label(doc):
    try:
        return doc.get_visibility_display()
    except Exception:
        return getattr(doc, "visibility", "-")


def _category_match(doc, mode):
    keywords = DOC_KEYWORDS.get(mode) or []
    if not keywords:
        return True
    name = ""
    if getattr(doc, "category", None):
        name += f" {doc.category.name}"
    name += f" {getattr(doc, 'title', '')} {getattr(doc, 'description', '')}"
    name = name.lower()
    return any(k in name for k in keywords)


def _load_documents(request, mode="all"):
    from apps.documents.models import Document, DocumentCategory, DocumentAttachment

    category_filter = request.GET.get("category") or "all"
    visibility_filter = request.GET.get("visibility") or "all"
    year_filter = request.GET.get("year") or "all"

    qs = (
        Document.objects
        .select_related("community", "category", "uploaded_by")
        .prefetch_related("apartments")
        .annotate(attachments_count=Count("attachments", distinct=True))
        .order_by("-document_date", "-created_at", "-id")
    )

    if category_filter != "all":
        qs = qs.filter(category_id=category_filter)

    if visibility_filter != "all":
        qs = qs.filter(visibility=visibility_filter)

    if year_filter != "all":
        qs = qs.filter(document_date__year=year_filter)

    docs_all = list(
        Document.objects
        .select_related("community", "category", "uploaded_by")
        .prefetch_related("apartments")
        .annotate(attachments_count=Count("attachments", distinct=True))
    )
    docs = [x for x in list(qs) if _category_match(x, mode)]
    docs_all_mode = [x for x in docs_all if _category_match(x, mode)]

    categories = list(DocumentCategory.objects.filter(is_active=True).order_by("sort_order", "name"))
    attachments_count = DocumentAttachment.objects.filter(is_active=True).count()

    return docs, docs_all_mode, categories, attachments_count, category_filter, visibility_filter, year_filter


def _ensure_default_categories():
    try:
        from apps.communities.models import Community
        from apps.documents.models import DocumentCategory

        community = Community.objects.first()
        if not community:
            return

        defaults = [
            ("Uchwały", 10),
            ("Protokoły zebrań", 20),
            ("Umowy", 30),
            ("Sprawozdania", 40),
            ("Faktury i skany", 50),
            ("Inne dokumenty", 90),
        ]

        for name, order in defaults:
            DocumentCategory.objects.get_or_create(
                community=community,
                name=name,
                defaults={"sort_order": order, "is_active": True},
            )
    except Exception:
        pass


def seed_document_categories_view(request):
    _ensure_default_categories()
    return HttpResponse("""
    <html><head><meta charset="utf-8"><title>Kategorie dokumentów</title></head>
    <body style="font-family:Arial;padding:24px">
      <h1>✅ Kategorie dokumentów uzupełnione</h1>
      <p>Dodano brakujące kategorie: Uchwały, Protokoły zebrań, Umowy, Sprawozdania, Faktury i skany, Inne dokumenty.</p>
      <p><a href="/admin/raporty/dokumenty-wspolnoty/">Wróć do panelu dokumentów</a></p>
    </body></html>
    """)


def documents_panel_view(request, mode="all"):
    mode_titles = {
        "all": ("📚 Dokumenty wspólnoty", "Uchwały, protokoły, umowy, sprawozdania, skany i załączniki"),
        "resolutions": ("📜 Rejestr uchwał", "Uchwały wspólnoty, dokumenty zatwierdzające i załączniki"),
        "contracts": ("📝 Rejestr umów", "Umowy z kontrahentami, aneksy, terminy i skany"),
        "protocols": ("🗒️ Rejestr protokołów", "Protokoły zebrań, obecności, załączniki i dokumenty powiązane"),
    }
    title, subtitle = mode_titles.get(mode, mode_titles["all"])

    try:
        docs, all_docs, categories, attachments_count, category_filter, visibility_filter, year_filter = _load_documents(request, mode)
    except Exception:
        docs, all_docs, categories, attachments_count = [], [], [], 0
        category_filter, visibility_filter, year_filter = "all", "all", "all"

    public_docs = [x for x in all_docs if getattr(x, "visibility", "") == "public" or getattr(x, "is_public", False)]
    board_docs = [x for x in all_docs if getattr(x, "visibility", "") == "board_only"]
    selected_docs = [x for x in all_docs if getattr(x, "visibility", "") == "selected_apartments"]
    current_year_docs = [x for x in all_docs if getattr(x, "document_date", None) and x.document_date.year == date.today().year]
    with_attachments = [x for x in all_docs if getattr(x, "attachments_count", 0)]

    category_options = '<option value="all">Wszystkie</option>'
    for cat in categories:
        selected = "selected" if str(cat.id) == str(category_filter) else ""
        category_options += f'<option value="{cat.id}" {selected}>{cat.name}</option>'

    def related_apartments(doc):
        try:
            names = [str(x) for x in doc.apartments.all()[:5]]
            if not names:
                return "-"
            suffix = "..." if doc.apartments.count() > 5 else ""
            return ", ".join(names) + suffix
        except Exception:
            return "-"

    def row(doc, index):
        category = doc.category.name if doc.category else "-"
        doc_date = doc.document_date or "-"
        uploaded = doc.uploaded_by or "-"
        public_badge = '<span class="badge ok">Tak</span>' if doc.is_public else '<span class="badge mutedb">Nie</span>'
        return f"""
        <tr>
          <td>{index}</td>
          <td>{doc_date}</td>
          <td>{category}</td>
          <td><strong>{doc.title}</strong><br><span class="muted">{doc.description or ""}</span></td>
          <td>{_visibility_label(doc)}</td>
          <td>{public_badge}</td>
          <td>{related_apartments(doc)}</td>
          <td>{getattr(doc, "attachments_count", 0)}</td>
          <td>{uploaded}</td>
          <td>{_safe_file_link(getattr(doc, "file", None))}</td>
          <td><a href="/admin/documents/document/{doc.id}/change/" target="_blank" rel="noopener">Edycja ↗</a></td>
        </tr>
        """

    rows_html = "".join(row(x, i + 1) for i, x in enumerate(docs))
    if not rows_html:
        rows_html = '<tr><td colspan="11">Brak dokumentów dla wybranych filtrów.</td></tr>'

    html = f"""
    <!doctype html>
    <html lang="pl">
    <head>
      <meta charset="utf-8">
      <title>{title}</title>
      <style>
        body{{font-family:Arial,sans-serif;padding:18px;color:#0f172a;background:#fff}}
        .topbar{{display:flex;justify-content:space-between;gap:16px;align-items:flex-start}}
        h1{{margin:0 0 4px 0;font-size:32px}} h2{{margin-top:22px}}
        .muted{{color:#64748b}}
        .box{{border:1px solid #dfe5ec;padding:12px;border-radius:8px;background:#f8fafc}}
        .filters{{display:flex;gap:8px;flex-wrap:wrap;align-items:end}}
        .filters label{{display:flex;flex-direction:column;font-size:12px;color:#64748b}}
        select,input{{padding:8px 10px}} button{{padding:9px 14px;cursor:pointer}}
        .links{{display:flex;gap:8px;flex-wrap:wrap;margin:14px 0}}
        .links a, td a{{display:inline-block;border:1px solid #cbd5e1;padding:7px 10px;border-radius:6px;text-decoration:none;color:#0f172a;background:#fff}}
        .grid{{display:grid;grid-template-columns:repeat(6,minmax(140px,1fr));gap:12px;margin:16px 0}}
        .card{{border:1px solid #dfe5ec;border-radius:10px;padding:14px;background:#fff;box-shadow:0 1px 2px rgba(15,23,42,.04)}}
        .card strong{{display:block;font-size:24px;margin-top:6px}}
        table{{width:100%;border-collapse:collapse;margin-top:12px}}
        th,td{{border:1px solid #dfe5ec;padding:8px 10px;text-align:left;vertical-align:top}}
        th{{background:#f1f5f9}}
        .badge{{display:inline-block;border-radius:999px;padding:4px 9px;font-weight:700;font-size:12px}}
        .ok{{background:#ecfdf5;color:#0a8f3c;border:1px solid #bbf7d0}}
        .mutedb{{background:#f1f5f9;color:#64748b;border:1px solid #cbd5e1}}
        .note{{color:#64748b;margin-top:12px;font-size:13px}}
        @media(max-width:1200px){{.grid{{grid-template-columns:repeat(3,1fr)}} .topbar{{display:block}} .box{{margin-top:12px}}}}
        @media print{{.box,.links,td a{{display:none}} @page{{size:A4 landscape;margin:8mm}} body{{font-size:8px;padding:0}} h1{{font-size:18px}} th,td{{padding:3px 4px}} .grid{{grid-template-columns:repeat(3,1fr)}}}}
      </style>
    </head>
    <body>
      <div class="topbar">
        <div>
          <h1>{title}</h1>
          <div class="muted">{subtitle}</div>
        </div>
        <form class="box" method="get">
          <div class="filters">
            <label>Kategoria
              <select name="category">{category_options}</select>
            </label>
            <label>Widoczność
              <select name="visibility">
                <option value="all" {_selected("all", visibility_filter)}>Wszystkie</option>
                <option value="board_only" {_selected("board_only", visibility_filter)}>Tylko zarząd</option>
                <option value="public" {_selected("public", visibility_filter)}>Publiczne</option>
                <option value="selected_apartments" {_selected("selected_apartments", visibility_filter)}>Wybrane lokale</option>
                <option value="private" {_selected("private", visibility_filter)}>Prywatne</option>
              </select>
            </label>
            <label>Rok
              <select name="year">{_year_options(year_filter)}</select>
            </label>
            <button type="submit">Pokaż</button>
          </div>
        </form>
      </div>

      <div class="links">
        <a href="/admin/raporty/" target="_blank" rel="noopener">Dashboard Zarządcy ↗</a>
        <a href="/admin/raporty/dokumenty-wspolnoty/" target="_blank" rel="noopener">Wszystkie dokumenty ↗</a>
        <a href="/admin/raporty/rejestr-uchwal/" target="_blank" rel="noopener">Uchwały ↗</a>
        <a href="/admin/raporty/rejestr-umow/" target="_blank" rel="noopener">Umowy ↗</a>
        <a href="/admin/raporty/rejestr-protokolow/" target="_blank" rel="noopener">Protokoły ↗</a>
        <a href="/admin/documents/document/add/" target="_blank" rel="noopener">Dodaj dokument ↗</a>
        <a href="/admin/documents/document/" target="_blank" rel="noopener">Admin dokumentów ↗</a>
        <a href="/admin/raporty/dokumenty-wspolnoty/utworz-kategorie/" target="_blank" rel="noopener">Utwórz kategorie ↗</a>
        <a href="#" onclick="window.print(); return false;">PDF listy</a>
      </div>

      <div class="grid">
        <div class="card">Wszystkie<strong>{len(all_docs)}</strong></div>
        <div class="card">Publiczne<strong>{len(public_docs)}</strong></div>
        <div class="card">Tylko zarząd<strong>{len(board_docs)}</strong></div>
        <div class="card">Wybrane lokale<strong>{len(selected_docs)}</strong></div>
        <div class="card">Z załącznikami<strong>{len(with_attachments)}</strong></div>
        <div class="card">Bieżący rok<strong>{len(current_year_docs)}</strong></div>
      </div>

      <h2>Lista dokumentów</h2>
      <table>
        <tr>
          <th>#</th><th>Data</th><th>Kategoria</th><th>Tytuł / opis</th><th>Widoczność</th>
          <th>Publiczny</th><th>Lokale</th><th>Zał.</th><th>Dodał</th><th>Plik</th><th>Akcje</th>
        </tr>
        {rows_html}
      </table>

      <p class="note">Moduł wykorzystuje Document, DocumentCategory i DocumentAttachment. Rejestry uchwał, umów i protokołów działają na kategoriach dokumentów — bez dodatkowych migracji.</p>
    </body>
    </html>
    """
    return HttpResponse(html)


_original_get_urls_documents_panel = admin.site.get_urls


def get_urls_documents_panel():
    urls = _original_get_urls_documents_panel()
    custom = [
        path("raporty/dokumenty-wspolnoty/", admin.site.admin_view(lambda request: documents_panel_view(request, "all")), name="community_documents_panel"),
        path("raporty/rejestr-uchwal/", admin.site.admin_view(lambda request: documents_panel_view(request, "resolutions")), name="community_resolutions_register"),
        path("raporty/rejestr-umow/", admin.site.admin_view(lambda request: documents_panel_view(request, "contracts")), name="community_contracts_register"),
        path("raporty/rejestr-protokolow/", admin.site.admin_view(lambda request: documents_panel_view(request, "protocols")), name="community_protocols_register"),
        path("raporty/dokumenty-wspolnoty/utworz-kategorie/", admin.site.admin_view(seed_document_categories_view), name="community_documents_seed_categories"),
    ]
    return custom + urls


if not getattr(admin.site, "_community_documents_panel_patched", False):
    admin.site.get_urls = get_urls_documents_panel
    admin.site._community_documents_panel_patched = True
PY

echo "== Import w audit/admin.py =="
python3 - <<'PY'
from pathlib import Path
p = Path("apps/audit/admin.py")
txt = p.read_text(encoding="utf-8")
line = "from . import admin_documents_panel  # noqa"
if line not in txt:
    txt = txt.rstrip() + "\n\n# Etap 2.9.1 FULL - dokumenty wspólnoty\n" + line + "\n"
p.write_text(txt, encoding="utf-8")
print("OK")
PY

echo "== Linki w Centrum raportów =="
python3 - <<'PY'
from pathlib import Path
p = Path("apps/audit/admin_reports_center.py")
txt = p.read_text(encoding="utf-8")

card = """
      <div class="report-card">
        <h2>📚 Dokumenty wspólnoty</h2>
        <p>Uchwały, protokoły, umowy, sprawozdania, skany i załączniki wspólnoty.</p>
        <a href="/admin/raporty/dokumenty-wspolnoty/?year=all" target="_blank" rel="noopener">Panel dokumentów ↗</a>
        <a href="/admin/raporty/rejestr-uchwal/" target="_blank" rel="noopener">Uchwały ↗</a>
        <a href="/admin/raporty/rejestr-umow/" target="_blank" rel="noopener">Umowy ↗</a>
        <a href="/admin/raporty/rejestr-protokolow/" target="_blank" rel="noopener">Protokoły ↗</a>
        <a href="/admin/documents/document/add/" target="_blank" rel="noopener">Dodaj dokument ↗</a>
      </div>
"""

if "/admin/raporty/dokumenty-wspolnoty/" not in txt:
    marker = '    <h2 class="section-title">⚡ Szybkie akcje</h2>'
    txt = txt.replace(marker, card + "\n" + marker, 1)

p.write_text(txt, encoding="utf-8")
print("OK")
PY

echo "== Rebuild =="
docker compose down
docker compose build --no-cache
docker compose up -d
sleep 15

docker compose exec web python manage.py check

echo "== Kontrola URL =="
docker compose exec web python manage.py shell -c "
from django.urls import reverse
print(reverse('admin:community_documents_panel'))
print(reverse('admin:community_resolutions_register'))
print(reverse('admin:community_contracts_register'))
print(reverse('admin:community_protocols_register'))
"

echo "GOTOWE: Dokumenty wspólnoty 2.9.1 FULL."
