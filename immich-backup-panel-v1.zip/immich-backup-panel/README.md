# Niezależny panel kopii Immich (rsync)

## Instalacja
1. Skopiuj ten katalog na serwer do `/opt/docker/immich-backup`.
2. `cd /opt/docker/immich-backup`
3. `cp .env.example .env`
4. Edytuj `.env`: ustaw własne `PANEL_PASSWORD` i `FLASK_SECRET_KEY`; nie publikuj tego pliku.
5. `docker compose config` — sprawdź konfigurację.
6. `docker compose up -d --build`
7. Panel dostępny tylko lokalnie na `http://127.0.0.1:8788`. Z komputera po SSH: `ssh -L 8788:127.0.0.1:8788 root@192.168.1.18`, potem otwórz ten adres lokalnie.

## Jak działa
- Kopiuje całe `/mnt/immich-data/Foto`, w tym istniejące zrzuty SQL, oraz trzy pliki konfiguracji Immich.
- Nie kopiuje aktywnego katalogu PostgreSQL i nie tworzy własnego zrzutu bazy.
- Źródła są montowane tylko do odczytu.
- Migawki są tygodniowe, domyślnie w niedzielę o 03:30, retencja 90 dni.
- Używa rsync `--link-dest` do współdzielenia niezmienionych plików między migawkami. Przed kopią sprawdza, czy udział SMB obsługuje hardlinki. Jeśli nie, przerywa bez pełnego kopiowania jako awaryjnego obejścia.
- W razie niedostępności udziału nie wykonuje kopii i wysyła powiadomienie na istniejący NTFY `immich-backup-alerts`.
- Przywracanie przygotowuje dane w `restore-staging/`; nie nadpisuje automatycznie działającego Immich.

## Bezpieczeństwo
Repozytorium nie jest szyfrowane, zgodnie z wyborem użytkownika. Dostęp do SMB oznacza potencjalny dostęp do kopii pliku `.env`. Panel ma Basic Auth i nasłuchuje wyłącznie na localhost hosta. Nie wystawiaj portu 8788 bezpośrednio do Internetu.

## Ważne
To pierwsza wersja do wdrożenia testowego. Po uruchomieniu najpierw sprawdź status SMB i wykonaj pierwszą kopię, a następnie przetestuj przygotowanie odtwarzania. Rozmiar pokazywany przez `du` może liczyć współdzielone hardlinki wielokrotnie.
