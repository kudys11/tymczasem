import os, re, json, time, shutil, threading, subprocess
from pathlib import Path
from datetime import datetime
from functools import wraps
import requests
from flask import Flask, render_template, request, redirect, url_for, flash, Response

app = Flask(__name__)
app.secret_key = os.environ["FLASK_SECRET_KEY"]
ROOT = Path(os.environ.get("BACKUP_ROOT", "/backup"))
MEDIA = Path(os.environ.get("SOURCE_MEDIA", "/source/Foto"))
CONFIG = Path(os.environ.get("SOURCE_CONFIG", "/immich-config"))
SNAPS = ROOT / "immich-snapshots"
STATE = Path("/state")
LOG = STATE / "operations.log"
STATUS = STATE / "status.json"
RETENTION = int(os.environ.get("RETENTION_DAYS", "90"))
DAY = os.environ.get("SCHEDULE_DAY", "SUN").upper()[:3]
CLOCK = os.environ.get("SCHEDULE_TIME", "03:30")
NTFY = os.environ.get("NTFY_URL", "http://ntfy/immich-backup-alerts")
USER = os.environ.get("PANEL_USERNAME", "admin")
PASS = os.environ["PANEL_PASSWORD"]
STATE.mkdir(exist_ok=True, parents=True)
lock = threading.Lock()
running = False
action = "Brak aktywnej operacji"

def log(s):
    line = f"[{datetime.now().astimezone().isoformat(timespec='seconds')}] {s}"
    with LOG.open("a", encoding="utf-8") as f: f.write(line + "\\n")
    return line

def notify(title, message, priority="default", tags="floppy_disk"):
    try:
        requests.post(NTFY, data=message.encode(), headers={"Title": title, "Priority": priority, "Tags": tags}, timeout=8)
    except Exception as e: log(f"NTFY: nie udało się wysłać: {e}")

def set_status(state, detail):
    STATUS.write_text(json.dumps({"status":state,"detail":detail,"updated":datetime.now().astimezone().isoformat(timespec="seconds")}, ensure_ascii=False), encoding="utf-8")

def smb_ok():
    try:
        rows = subprocess.check_output(["findmnt","-T",str(ROOT),"-n","-o","FSTYPE,SOURCE"], text=True, timeout=5).splitlines()
        return any("cifs" in r.lower() and "//192.168.1.50/Immich_beckup" in r for r in rows)
    except Exception: return False

def hardlinks_ok():
    p = SNAPS / ".hardlink-probe"
    try:
        p.mkdir(parents=True, exist_ok=False)
        a, b = p/"a", p/"b"
        a.write_text("probe")
        os.link(a,b)
        return a.stat().st_ino == b.stat().st_ino
    except Exception as e:
        log(f"Test hardlinków nieudany: {e}")
        return False
    finally: shutil.rmtree(p, ignore_errors=True)

def snapshots():
    result=[]
    if not SNAPS.is_dir(): return result
    for p in sorted(SNAPS.iterdir(), reverse=True):
        if not p.is_dir() or p.name.startswith("."): continue
        try: meta=json.loads((p/"snapshot.json").read_text(encoding="utf-8"))
        except Exception: meta={}
        try: size=subprocess.check_output(["du","-sh",str(p)],text=True).split()[0]
        except Exception: size="?"
        result.append({"name":p.name,"created":meta.get("created",p.name),"status":meta.get("status","brak metadanych"),"size":size})
    return result

def prev_snapshot():
    if not SNAPS.exists(): return None
    for p in sorted(SNAPS.iterdir(), reverse=True):
        if p.is_dir() and re.fullmatch(r"\d{8}T\d{6}",p.name) and (p/"Foto").is_dir() and (p/"immich-config").is_dir():
            try:
                m=json.loads((p/"snapshot.json").read_text())
                if m.get("status")=="success": return p
            except Exception: pass
    return None

def run_backup():
    global running, action
    if not lock.acquire(blocking=False): return False, "Inna operacja już trwa."
    running=True
    name=datetime.now().strftime("%Y%m%dT%H%M%S")
    target=SNAPS/name
    try:
        action="Sprawdzanie udziału SMB"
        if not smb_ok(): raise RuntimeError("SMB nie jest zamontowany jako oczekiwany CIFS. Kopia przerwana.")
        if not MEDIA.is_dir() or not CONFIG.is_dir(): raise RuntimeError("Brak dostępu do katalogów źródłowych.")
        for f in ("docker-compose.yml",".env","example.env"):
            if not (CONFIG/f).is_file(): raise RuntimeError(f"Brak pliku konfiguracji: {f}")
        SNAPS.mkdir(parents=True, exist_ok=True)
        if not hardlinks_ok(): raise RuntimeError("SMB nie obsługuje hardlinków; kopia przerwana, aby uniknąć zapełnienia dysku.")
        previous=prev_snapshot()
        target.mkdir()
        (target/"Foto").mkdir()
        (target/"immich-config").mkdir()
        set_status("running",f"Tworzenie migawki {name}")
        log(f"Start kopii {name}")
        action="Kopiowanie mediów i zrzutów SQL"
        media_cmd=["rsync","-aH","--numeric-ids","--delete","--human-readable","--stats"]
        if previous: media_cmd.append(f"--link-dest={previous/'Foto'}")
        media_cmd += [str(MEDIA)+"/",str(target/"Foto")+"/"]
        with LOG.open("a",encoding="utf-8") as f:
            subprocess.run(media_cmd,check=True,stdout=f,stderr=subprocess.STDOUT,timeout=43200)
        action="Kopiowanie konfiguracji Immich"
        cfg_cmd=["rsync","-aH","--numeric-ids","--delete","--include=/docker-compose.yml","--include=/.env","--include=/example.env","--exclude=*"]
        if previous: cfg_cmd.append(f"--link-dest={previous/'immich-config'}")
        cfg_cmd += [str(CONFIG)+"/",str(target/"immich-config")+"/"]
        with LOG.open("a",encoding="utf-8") as f:
            subprocess.run(cfg_cmd,check=True,stdout=f,stderr=subprocess.STDOUT,timeout=600)
        meta={"created":datetime.now().astimezone().isoformat(timespec="seconds"),"status":"success","encrypted":False,"previous_snapshot":previous.name if previous else None,"includes":["Foto: media i istniejące zrzuty SQL","docker-compose.yml",".env","example.env"]}
        (target/"snapshot.json").write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding="utf-8")
        prune()
        msg=f"Kopia zakończona: {name}"
        set_status("success",msg); log(msg); notify("Immich: kopia zakończona",msg,tags="white_check_mark")
        return True,msg
    except Exception as e:
        msg=f"BŁĄD kopii: {e}"
        log(msg); set_status("error",msg); notify("Immich: błąd kopii",msg,"high","warning")
        if target.exists():
            try: (target/"snapshot.json").write_text(json.dumps({"created":datetime.now().astimezone().isoformat(),"status":"failed","error":str(e)},ensure_ascii=False,indent=2))
            except Exception: pass
        return False,msg
    finally:
        action="Brak aktywnej operacji"; running=False; lock.release()

def prune():
    if not smb_ok(): raise RuntimeError("SMB niedostępny; retencja zablokowana.")
    cutoff=time.time()-RETENTION*86400
    removed=[]
    for p in SNAPS.iterdir() if SNAPS.exists() else []:
        if not p.is_dir() or not re.fullmatch(r"\d{8}T\d{6}",p.name): continue
        try:
            stamp=datetime.strptime(p.name,"%Y%m%dT%H%M%S").timestamp()
            if stamp<cutoff: shutil.rmtree(p); removed.append(p.name)
        except Exception as e:
            log(f"Błąd retencji {p.name}: {e}")
            notify("Immich: błąd retencji",f"{p.name}: {e}","high","warning")
    if removed:
        msg="Retencja usunęła migawki: "+", ".join(removed)
        log(msg); notify("Immich: retencja",msg)

def scheduler():
    last=None
    while True:
        now=datetime.now()
        if now.strftime("%a").upper()[:3]==DAY and now.strftime("%H:%M")==CLOCK and last!=now.date().isoformat():
            last=now.date().isoformat()
            run_backup()
        time.sleep(20)

def auth(fn):
    from functools import wraps
    @wraps(fn)
    def wrapped(*a,**kw):
        x=request.authorization
        if not x or x.username!=USER or x.password!=PASS:
            return Response("Wymagane logowanie",401,{"WWW-Authenticate":'Basic realm="Panel kopii Immich"'})
        return fn(*a,**kw)
    return wrapped

def get_status():
    try: return json.loads(STATUS.read_text(encoding="utf-8"))
    except Exception: return {"status":"unknown","detail":"Nie wykonano jeszcze kopii","updated":"—"}

@app.get("/health")
def health(): return {"status":"ok"}

@app.get("/")
@auth
def home():
    logs=LOG.read_text(encoding="utf-8").splitlines()[-80:] if LOG.exists() else []
    return render_template("index.html",status=get_status(),snaps=snapshots(),running=running,action=action,smb=smb_ok(),retention=RETENTION,day=DAY,clock=CLOCK,logs=logs)

@app.post("/backup")
@auth
def backup():
    if running: flash("Kopia już trwa.","warning")
    elif not smb_ok(): flash("SMB niedostępny — kopia zablokowana.","error")
    else: threading.Thread(target=run_backup,daemon=True).start(); flash("Uruchomiono kopię. Odśwież panel, aby sprawdzić wynik.","success")
    return redirect(url_for("home"))

@app.post("/delete/<name>")
@auth
def delete(name):
    p=SNAPS/name
    if not re.fullmatch(r"\d{8}T\d{6}",name) or not p.is_dir(): flash("Nieprawidłowa migawka.","error")
    elif not smb_ok(): flash("SMB niedostępny — usuwanie zablokowane.","error")
    elif running or not lock.acquire(blocking=False): flash("Inna operacja trwa.","warning")
    else:
        try: shutil.rmtree(p); log(f"Usunięto migawkę {name}"); notify("Immich: usunięto migawkę",name); flash(f"Usunięto migawkę {name}.","success")
        except Exception as e: log(f"Błąd usuwania {name}: {e}"); notify("Immich: błąd usuwania",str(e),"high","warning"); flash(f"Błąd: {e}","error")
        finally: lock.release()
    return redirect(url_for("home"))

@app.post("/restore/<name>")
@auth
def restore(name):
    p=SNAPS/name
    if not re.fullmatch(r"\d{8}T\d{6}",name) or not p.is_dir(): flash("Nieprawidłowa migawka.","error")
    elif not smb_ok(): flash("SMB niedostępny — odtwarzanie zablokowane.","error")
    elif running or not lock.acquire(blocking=False): flash("Inna operacja trwa.","warning")
    else:
        try:
            meta=json.loads((p/"snapshot.json").read_text())
            if meta.get("status")!="success": raise RuntimeError("Można odtwarzać tylko migawkę ze statusem success.")
            stage=ROOT/"restore-staging"/name
            if stage.exists(): raise RuntimeError(f"Katalog {stage} już istnieje.")
            stage.parent.mkdir(parents=True,exist_ok=True); stage.mkdir()
            shutil.copytree(p/"Foto",stage/"Foto",copy_function=shutil.copy2)
            shutil.copytree(p/"immich-config",stage/"immich-config",copy_function=shutil.copy2)
            log(f"Przygotowano staging odtwarzania: {stage}")
            notify("Immich: przygotowano odtwarzanie",str(stage))
            flash(f"Dane przygotowane do weryfikacji w {stage}. Bieżące dane nie zostały nadpisane.","success")
        except Exception as e: log(f"Błąd odtwarzania {name}: {e}"); notify("Immich: błąd odtwarzania",str(e),"high","warning"); flash(f"Błąd: {e}","error")
        finally: lock.release()
    return redirect(url_for("home"))

@app.post("/prune")
@auth
def prune_route():
    if running: flash("Kopia trwa; retencja zablokowana.","warning")
    else:
        try: prune(); flash("Retencja zakończona.","success")
        except Exception as e: flash(f"Błąd retencji: {e}","error")
    return redirect(url_for("home"))

if __name__=="__main__":
    threading.Thread(target=scheduler,daemon=True).start()
    app.run(host="0.0.0.0",port=8080,threaded=True)
