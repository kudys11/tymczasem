from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden, HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from openpyxl import load_workbook
from decimal import Decimal
from datetime import date, datetime
import calendar
from .models import *
from .services import calculate_month, working_days, sync_calendar_days


def pof(r):
    """Return the application profile, creating an ADMIN profile for superusers."""
    if not r.user.is_authenticated:
        return None
    p = getattr(r.user, 'profile', None)
    if p is None and r.user.is_superuser:
        p, _ = Profile.objects.get_or_create(
            user=r.user,
            defaults={'role': Profile.ROLE_ADMIN},
        )
        if p.role != Profile.ROLE_ADMIN or p.department_id is not None:
            p.role = Profile.ROLE_ADMIN
            p.department = None
            p.save(update_fields=['role', 'department'])
    return p


def allowed(r, m, write=False):
    p = pof(r)
    if not p:
        return False
    if p.role == 'ADMIN':
        return True
    if p.role == 'FIN':
        return not write
    return p.department_id == m.department_id


def login_view(r):
    if r.user.is_authenticated:
        return redirect('dashboard')
    if r.method == 'POST':
        u = authenticate(r, username=r.POST.get('username'), password=r.POST.get('password'))
        if u:
            login(r, u)
            return redirect('dashboard')
    return render(r, 'registration/login.html')


def logout_view(r):
    logout(r)
    return redirect('login')


@login_required
def dashboard(r):
    p = pof(r)
    if p is None:
        return HttpResponseForbidden('Brak przypisanej roli użytkownika. Administrator powinien utworzyć profil użytkownika.')

    departments = Department.objects.all().order_by('name')
    if p.role == 'DEPT':
        departments = departments.filter(pk=p.department_id)

    # Pierwszy panel pokazuje wybrany okres dla wszystkich dostępnych działów.
    available_months = Month.objects.select_related('department').filter(status__in=[Month.OPEN, Month.CALC, Month.REOPENED])
    if p.role == 'DEPT':
        available_months = available_months.filter(department=p.department)
    available_months = available_months.order_by('-year', '-month', 'department__name')

    selected_period = r.GET.get('period', '').strip()
    if not selected_period:
        first = available_months.first()
        selected_period = f'{first.year:04d}-{first.month:02d}' if first else f'{timezone.localdate().year:04d}-{timezone.localdate().month:02d}'

    try:
        sy, sm = [int(x) for x in selected_period.split('-', 1)]
        if not (1 <= sm <= 12 and 2000 <= sy <= 2100):
            raise ValueError
        selected_period = f'{sy:04d}-{sm:02d}'
    except (ValueError, TypeError):
        sy, sm = timezone.localdate().year, timezone.localdate().month
        selected_period = f'{sy:04d}-{sm:02d}'

    selected_qs = Month.objects.select_related('department').filter(year=sy, month=sm)
    if p.role == 'DEPT':
        selected_qs = selected_qs.filter(department=p.department)
    selected_map = {m.department_id: m for m in selected_qs}
    selected_departments = [
        {'department': dept, 'month': selected_map.get(dept.id)}
        for dept in departments
    ]

    # Wszystkie pozostałe miesiące otwarte/wyliczone, których nie pokazuje pierwszy panel.
    other_months = available_months.exclude(year=sy, month=sm)

    # Katalog zamkniętych miesięcy. Pusty zakres nie wykonuje zapytania.
    closed_from = r.GET.get('closed_from', '').strip()
    closed_to = r.GET.get('closed_to', '').strip()
    closed_months = Month.objects.none()
    if closed_from and closed_to:
        try:
            fy, fm = [int(x) for x in closed_from.split('-', 1)]
            ty, tm = [int(x) for x in closed_to.split('-', 1)]
            from_key = fy * 12 + fm
            to_key = ty * 12 + tm
            if 1 <= fm <= 12 and 1 <= tm <= 12 and from_key <= to_key:
                closed_months = Month.objects.select_related('department').filter(status=Month.CLOSED)
                if p.role == 'DEPT':
                    closed_months = closed_months.filter(department=p.department)
                closed_months = [m for m in closed_months if from_key <= m.year * 12 + m.month <= to_key]
                closed_months.sort(key=lambda m: (m.year, m.month, m.department.name), reverse=True)
        except (ValueError, TypeError):
            closed_months = []

    return render(r, 'core/dashboard.html', {
        'months': other_months,
        'profile': p,
        'departments': departments,
        'selected_departments': selected_departments,
        'selected_period': selected_period,
        'closed_from': closed_from,
        'closed_to': closed_to,
        'closed_months': closed_months,
    })


@login_required
def export_closed_month(r, pk):
    """Eksport zamkniętego miesiąca w układzie zbliżonym do arkusza źródłowego premii."""
    m = get_object_or_404(Month.objects.select_related('department'), pk=pk)
    if not allowed(r, m) or m.status != Month.CLOSED:
        return HttpResponseForbidden()

    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
    from openpyxl.utils import get_column_letter

    results = list(PremiumResult.objects.filter(month=m).select_related('employee').order_by(
        'employee__sort_order', 'employee__last_name', 'employee__first_name'
    ))
    sap = {x.personnel_no: x for x in SAPRecord.objects.filter(month=m)}
    notes = {x.employee_id: x for x in EmployeeNote.objects.filter(month=m)}

    wb = Workbook()
    ws = wb.active
    ws.title = 'Premie'

    # Główny arkusz jest celowo płaski i odpowiada danym używanym w arkuszu źródłowym:
    # dane SAP + dane kalendarza/premii + ręczne opisy.
    headers = [
        'Raport wywołano', 'Okres rozliczeniowy', 'Zakład', 'Numer osobowy',
        'Imię', 'Nazwisko', 'Data zatrudnienia', 'Podgrupa pracowników', 'EPC',
        'Efektywność w %', 'GK', 'Nadgodz/Godz.ujem.', 'Urlop wypoczynkowy',
        'choroba zwykła', 'Nieob. nieuspr. niepłatna', 'Pozost. nieobecn.',
        'Tryb', 'Premia bazowa', 'Potrącenie robocze', 'Potrącenie kalendarzowe',
        'Dyskwalifikacja', 'Do wypłaty', 'Jakość', 'BHP', 'Uwagi'
    ]
    ws.append(headers)
    for x in results:
        e = x.employee
        sr = sap.get(e.personnel_no)
        n = notes.get(e.id)
        details = x.calculation_details or {}
        ws.append([
            sr.report_called if sr else '',
            sr.settlement_period if sr else f'{m.month:02d}/{m.year}',
            sr.plant if sr else m.department.name,
            e.personnel_no, e.first_name, e.last_name,
            sr.employment_date if sr else None,
            sr.subgroup if sr else '', sr.epc if sr else '',
            float(sr.efficiency) if sr else None,
            float(sr.gk) if sr else None,
            float(sr.overtime) if sr else None,
            float(sr.vacation) if sr else None,
            float(sr.sick) if sr else None,
            float(sr.unpaid_absence) if sr else None,
            float(sr.other_absence) if sr else None,
            'Portier' if e.premium_mode == Employee.PREMIUM_PORTIER else 'Standardowe',
            float(x.granted), float(x.deduction_working), float(x.deduction_calendar),
            'TAK' if details.get('disqualified') else 'NIE', float(x.payable),
            n.quality if n else '', n.bhp if n else '', n.notes if n else '',
        ])

    # Kalendarz pozostaje osobnym arkuszem, aby eksport zachował pełny zapis każdego dnia.
    ws_cal = wb.create_sheet('Kalendarz')
    days = sync_calendar_days(m.year, m.month)
    employees = Employee.objects.filter(department=m.department).order_by('sort_order', 'last_name', 'first_name', 'id')
    entries = {(ce.employee_id, ce.day): ce for ce in CalendarEntry.objects.filter(month=m).select_related('code')}
    ws_cal.append(['Nr osobowy', 'Nazwisko', 'Imię'] + [f"{d['day']:02d} {d['weekday_short']}" for d in days])
    for emp in employees:
        row = [emp.personnel_no, emp.last_name, emp.first_name]
        for d in days:
            ce = entries.get((emp.id, d['date']))
            row.append(ce.code.code if ce and ce.code else (float(ce.hours) if ce and ce.hours is not None else ''))
        ws_cal.append(row)

    ws_sap = wb.create_sheet('SAP - źródło')
    sap_headers = [
        'Raport wywołano', 'Okres rozliczeniowy', 'Zakład', 'Numer osobowy', 'Imię', 'Nazwisko',
        'Data zatrudnienia', 'Podgrupa pracowników', 'EPC', 'Efektywność w %', 'GK',
        'Nadgodz/Godz.ujem.', 'Urlop wypoczynkowy', 'choroba zwykła',
        'Nieob. nieuspr. niepłatna', 'Pozost. nieobecn.'
    ]
    ws_sap.append(sap_headers)
    for sr in sorted(sap.values(), key=lambda x: (x.last_name, x.first_name, x.personnel_no)):
        ws_sap.append([
            sr.report_called, sr.settlement_period, sr.plant, sr.personnel_no, sr.first_name, sr.last_name,
            sr.employment_date, sr.subgroup, sr.epc, float(sr.efficiency), float(sr.gk), float(sr.overtime),
            float(sr.vacation), float(sr.sick), float(sr.unpaid_absence), float(sr.other_absence)
        ])

    ws_notes = wb.create_sheet('Jakość-BHP-Uwagi')
    ws_notes.append(['Nr osobowy', 'Nazwisko', 'Imię', 'Jakość', 'BHP', 'Uwagi'])
    for n in sorted(notes.values(), key=lambda x: (x.employee.last_name, x.employee.first_name)):
        ws_notes.append([n.employee.personnel_no, n.employee.last_name, n.employee.first_name, n.quality, n.bhp, n.notes])

    # Metadane zamkniętego miesiąca — snapshot parametrów eksportu.
    ws_info = wb.create_sheet('Informacje')
    ws_info.append(['Parametr', 'Wartość'])
    ws_info.append(['Dział', m.department.name])
    ws_info.append(['Okres', f'{m.month:02d}/{m.year}'])
    ws_info.append(['Status', m.get_status_display()])
    ws_info.append(['Premia bazowa', float(m.base_premium)])
    ws_info.append(['Data zamknięcia', m.closed_at.strftime('%d.%m.%Y %H:%M') if m.closed_at else ''])
    ws_info.append(['Suma do wypłaty', float(sum((x.payable for x in results), Decimal('0')))])

    thin = Side(style='thin', color='D9E2EC')
    for sheet in wb.worksheets:
        sheet.freeze_panes = 'A2'
        sheet.auto_filter.ref = sheet.dimensions
        for cell in sheet[1]:
            cell.font = Font(bold=True)
            cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            cell.fill = PatternFill('solid', fgColor='DCE6F1')
            cell.border = Border(bottom=thin)
        for row in sheet.iter_rows():
            for cell in row:
                cell.alignment = Alignment(vertical='top', wrap_text=True)
        for col in sheet.columns:
            max_len = max(len(str(cell.value or '')) for cell in col)
            sheet.column_dimensions[get_column_letter(col[0].column)].width = min(max(max_len + 2, 11), 32)
        sheet.row_dimensions[1].height = 32

    AuditLog.objects.create(user=r.user, month=m, action='EXPORT_XLSX', details='Eksport zamkniętego miesiąca do XLSX — układ źródłowy premii')
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    safe_dept = ''.join(ch if ch.isalnum() or ch in ' _-' else '_' for ch in m.department.name).strip().replace(' ', '_')
    response['Content-Disposition'] = f'attachment; filename="Premia_{safe_dept}_{m.month:02d}_{m.year}.xlsx"'
    wb.save(response)
    return response


@login_required
def new_month(r):
    p = pof(r)
    if p is None or p.role not in ('ADMIN', 'DEPT'):
        return HttpResponseForbidden()
    dept = p.department if p.role == 'DEPT' else None
    if p.role == 'ADMIN' and r.method == 'GET':
        return render(r, 'core/new_month.html', {'departments': Department.objects.all(), 'profile': p})
    if r.method == 'POST':
        dept = get_object_or_404(Department, pk=r.POST.get('department')) if p.role == 'ADMIN' else p.department
        y = int(r.POST['year'])
        mo = int(r.POST['month'])
        m, created = Month.objects.get_or_create(
            department=dept, year=y, month=mo,
            defaults={'base_premium': dept.base_premium},
        )
        return redirect('month', pk=m.pk)
    return render(r, 'core/new_month.html', {'departments': [dept], 'profile': p})



@login_required
def employees_view(r):
    """Zarządzanie pracownikami: użytkownik działu tylko swoim działem, admin wszystkimi."""
    p = pof(r)
    if not p or p.role == Profile.ROLE_FIN:
        return HttpResponseForbidden()
    if p.role == Profile.ROLE_ADMIN:
        departments = Department.objects.all()
        dept_id = r.GET.get('department') or r.POST.get('department')
        dept = get_object_or_404(Department, pk=dept_id) if dept_id else departments.first()
    else:
        departments = Department.objects.filter(pk=p.department_id)
        dept = p.department
    if dept is None:
        return HttpResponseForbidden('Użytkownik nie ma przypisanego działu.')
    employees = Employee.objects.filter(department=dept).order_by('sort_order', 'last_name', 'first_name', 'id')
    return render(r, 'core/employees.html', {
        'profile': p, 'departments': departments, 'department': dept,
        'employees': employees,
        'active_count': employees.filter(active=True).count(),
    })


@login_required
def employee_add(r):
    p = pof(r)
    if not p or p.role == Profile.ROLE_FIN:
        return HttpResponseForbidden()
    if p.role == Profile.ROLE_ADMIN:
        dept = get_object_or_404(Department, pk=r.POST.get('department') or r.GET.get('department'))
    else:
        dept = p.department
    if dept is None:
        return HttpResponseForbidden('Użytkownik nie ma przypisanego działu.')
    if r.method == 'POST':
        personnel_no = r.POST.get('personnel_no', '').strip()
        first_name = r.POST.get('first_name', '').strip()
        last_name = r.POST.get('last_name', '').strip()
        premium_mode = r.POST.get('premium_mode', Employee.PREMIUM_STANDARD)
        if premium_mode not in dict(Employee.PREMIUM_MODES):
            premium_mode = Employee.PREMIUM_STANDARD
        if not personnel_no or not first_name or not last_name:
            return render(r, 'core/employee_form.html', {'profile': p, 'department': dept, 'error': 'Numer osobowy, imię i nazwisko są wymagane.'})
        if Employee.objects.filter(department=dept, personnel_no=personnel_no).exists():
            return render(r, 'core/employee_form.html', {'profile': p, 'department': dept, 'error': 'Pracownik o takim numerze osobowym już istnieje w tym dziale.'})
        last_order = Employee.objects.filter(department=dept).order_by('-sort_order').values_list('sort_order', flat=True).first()
        Employee.objects.create(department=dept, personnel_no=personnel_no, first_name=first_name, last_name=last_name, premium_mode=premium_mode, sort_order=(last_order or 0) + 1)
        AuditLog.objects.create(user=r.user, action='ADD_EMPLOYEE', details=f'Dział: {dept.name}; Nr: {personnel_no}; Pracownik: {last_name} {first_name}')
        return redirect(f'/employees/?department={dept.id}')
    return render(r, 'core/employee_form.html', {'profile': p, 'department': dept})


@login_required
def employee_edit(r, pk):
    p = pof(r)
    if not p or p.role == Profile.ROLE_FIN:
        return HttpResponseForbidden()
    emp = get_object_or_404(Employee.objects.select_related('department'), pk=pk)
    if p.role != Profile.ROLE_ADMIN and emp.department_id != p.department_id:
        return HttpResponseForbidden()
    if r.method == 'POST':
        personnel_no = r.POST.get('personnel_no', '').strip()
        first_name = r.POST.get('first_name', '').strip()
        last_name = r.POST.get('last_name', '').strip()
        premium_mode = r.POST.get('premium_mode', Employee.PREMIUM_STANDARD)
        if premium_mode not in dict(Employee.PREMIUM_MODES):
            premium_mode = Employee.PREMIUM_STANDARD
        if not personnel_no or not first_name or not last_name:
            return render(r, 'core/employee_form.html', {'profile': p, 'department': emp.department, 'employee': emp, 'error': 'Numer osobowy, imię i nazwisko są wymagane.'})
        if Employee.objects.filter(department=emp.department, personnel_no=personnel_no).exclude(pk=emp.pk).exists():
            return render(r, 'core/employee_form.html', {'profile': p, 'department': emp.department, 'employee': emp, 'error': 'Pracownik o takim numerze osobowym już istnieje w tym dziale.'})
        emp.personnel_no, emp.first_name, emp.last_name, emp.premium_mode = personnel_no, first_name, last_name, premium_mode
        emp.save(update_fields=['personnel_no', 'first_name', 'last_name', 'premium_mode'])
        AuditLog.objects.create(user=r.user, action='EDIT_EMPLOYEE', details=f'Pracownik ID {emp.id}; Nr: {personnel_no}; {last_name} {first_name}')
        return redirect(f'/employees/?department={emp.department_id}')
    return render(r, 'core/employee_form.html', {'profile': p, 'department': emp.department, 'employee': emp})


@login_required
def employee_toggle(r, pk):
    p = pof(r)
    if not p or p.role == Profile.ROLE_FIN or r.method != 'POST':
        return HttpResponseForbidden()
    emp = get_object_or_404(Employee.objects.select_related('department'), pk=pk)
    if p.role != Profile.ROLE_ADMIN and emp.department_id != p.department_id:
        return HttpResponseForbidden()
    emp.active = not emp.active
    emp.save(update_fields=['active'])
    AuditLog.objects.create(user=r.user, action='ACTIVATE_EMPLOYEE' if emp.active else 'DEACTIVATE_EMPLOYEE', details=f'Pracownik ID {emp.id}; {emp}')
    return redirect(f'/employees/?department={emp.department_id}')


@login_required
def employee_move(r, pk, direction):
    p = pof(r)
    if not p or p.role == Profile.ROLE_FIN or r.method != 'POST':
        return HttpResponseForbidden()
    emp = get_object_or_404(Employee, pk=pk)
    if p.role != Profile.ROLE_ADMIN and emp.department_id != p.department_id:
        return HttpResponseForbidden()
    qs = list(Employee.objects.filter(department=emp.department, active=True).order_by('sort_order', 'last_name', 'first_name', 'id'))
    try:
        i = [x.id for x in qs].index(emp.id)
    except ValueError:
        return redirect(f'/employees/?department={emp.department_id}')
    j = i - 1 if direction == 'up' else i + 1
    if j < 0 or j >= len(qs):
        return redirect(f'/employees/?department={emp.department_id}')
    qs[i].sort_order, qs[j].sort_order = qs[j].sort_order, qs[i].sort_order
    Employee.objects.bulk_update([qs[i], qs[j]], ['sort_order'])
    AuditLog.objects.create(user=r.user, action='SORT_EMPLOYEES', details=f'Dział: {emp.department.name}; {emp}; kierunek: {direction}')
    return redirect(f'/employees/?department={emp.department_id}')

@login_required
def month_detail(r, pk):
    m = get_object_or_404(Month.objects.select_related('department'), pk=pk)
    if not allowed(r, m):
        return HttpResponseForbidden()
    results = PremiumResult.objects.filter(month=m).select_related('employee').order_by('employee__sort_order', 'employee__last_name', 'employee__first_name')
    employees = Employee.objects.filter(department=m.department, active=True).order_by('sort_order', 'last_name', 'first_name', 'id')
    notes = {n.employee_id: n for n in EmployeeNote.objects.filter(month=m)}
    sap_records = {x.personnel_no: x for x in SAPRecord.objects.filter(month=m)}
    results_map = {x.employee_id: x for x in results}
    total = sum((x.payable for x in results), Decimal('0'))
    return render(r, 'core/month.html', {
        'm': m, 'results': results, 'employees': employees, 'notes': notes,
        'sap_records': sap_records, 'results_map': results_map, 'total': total, 'profile': pof(r),
    })


@login_required
def update_base_premium(r, pk):
    m = get_object_or_404(Month.objects.select_related('department'), pk=pk)
    if not allowed(r, m, True) or r.method != 'POST' or m.status == 'CLOSED':
        return HttpResponseForbidden()
    try:
        value = Decimal(str(r.POST.get('base_premium', '')).replace(',', '.'))
        if value < 0 or value > Decimal('99999999.99'):
            raise ValueError
    except (ValueError, TypeError, ArithmeticError):
        return redirect('month', pk=m.pk)
    old = m.base_premium
    m.base_premium = value.quantize(Decimal('0.01'))
    m.save(update_fields=['base_premium'])
    # Ustawienie działu jest domyślną premią dla kolejnych nowych miesięcy.
    m.department.base_premium = m.base_premium
    m.department.save(update_fields=['base_premium'])
    if m.status == Month.CALC or m.status == Month.REOPENED:
        m.status = Month.OPEN
        m.save(update_fields=['status'])
    AuditLog.objects.create(
        user=r.user, month=m, action='UPDATE_BASE_PREMIUM',
        details=f'Premia bazowa: {old} zł -> {m.base_premium} zł; Dział: {m.department.name}'
    )
    return redirect('month', pk=m.pk)


@login_required
def import_sap(r, pk):
    m = get_object_or_404(Month, pk=pk)
    p = pof(r)
    if not p or not allowed(r, m, True) or p.role == 'FIN' or m.status == 'CLOSED' or not m.department.use_sap:
        return HttpResponseForbidden()
    if r.method == 'POST' and 'file' in r.FILES:
        ws = load_workbook(r.FILES['file'], data_only=True, read_only=True).active
        headers = list(next(ws.iter_rows(values_only=True)))
        idx = {str(v).strip(): i for i, v in enumerate(headers) if v is not None}
        SAPRecord.objects.filter(month=m).delete()

        def val(row, name, default=''):
            i = idx.get(name)
            return row[i] if i is not None and i < len(row) else default

        def dec(row, name):
            raw = val(row, name, 0)
            if raw in (None, ''):
                return Decimal('0')
            try:
                text = str(raw).strip().replace(',', '.')
                if text.endswith('%'):
                    text = text[:-1].strip()
                return Decimal(text)
            except Exception:
                return Decimal('0')

        def as_date(raw):
            if raw in (None, ''):
                return None
            if isinstance(raw, datetime):
                return raw.date()
            if isinstance(raw, date):
                return raw
            for fmt in ('%d.%m.%Y', '%Y-%m-%d', '%d/%m/%Y'):
                try:
                    return date.fromisoformat(str(raw)) if fmt == '%Y-%m-%d' else datetime.strptime(str(raw), fmt).date()
                except Exception:
                    pass
            return None

        for row in ws.iter_rows(values_only=True):
            no = val(row, 'Numer osobowy', None)
            if no is None:
                continue
            no = str(no)
            first = str(val(row, 'Imię', '') or '')
            last = str(val(row, 'Nazwisko', '') or '')
            emp, _ = Employee.objects.get_or_create(
                department=m.department, personnel_no=no,
                defaults={'first_name': first, 'last_name': last},
            )
            SAPRecord.objects.create(
                month=m, report_called=str(val(row, 'Raport wywołano', '') or ''),
                settlement_period=str(val(row, 'Okres rozliczeniowy', '') or ''),
                plant=str(val(row, 'Zakład', '') or ''), personnel_no=no,
                first_name=first or emp.first_name, last_name=last or emp.last_name,
                employment_date=as_date(val(row, 'Data zatrudnienia', None)),
                subgroup=str(val(row, 'Podgrupa pracowników', '') or ''),
                epc=str(val(row, 'EPC', '') or ''),
                efficiency=dec(row, 'Efektywność w %'), gk=dec(row, 'GK'),
                overtime=dec(row, 'Nadgodz/Godz.ujem.'),
                vacation=dec(row, 'Urlop wypoczynkowy'), sick=dec(row, 'choroba zwykła'),
                unpaid_absence=dec(row, 'Nieob. nieuspr. niepłatna'),
                other_absence=dec(row, 'Pozost. nieobecn.'),
            )
        if m.status == Month.CALC or m.status == Month.REOPENED:
            m.status = Month.OPEN
            m.save(update_fields=['status'])
        AuditLog.objects.create(user=r.user, month=m, action='IMPORT_SAP', details='Import XLSX')
        return redirect('month', pk=pk)
    return render(r, 'core/import.html', {'m': m})


@login_required
def calendar_view(r, pk):
    m = get_object_or_404(Month, pk=pk)
    if not allowed(r, m):
        return HttpResponseForbidden()
    employees = Employee.objects.filter(department=m.department, active=True).order_by('sort_order', 'last_name', 'first_name', 'id')
    days = sync_calendar_days(m.year, m.month)
    codes = AbsenceCode.objects.filter(active=True).order_by('sort_order', 'code')
    entries = {}
    for ce in CalendarEntry.objects.filter(month=m):
        entries.setdefault(ce.employee_id, {})[ce.day.day] = ce
    p = pof(r)
    return render(r, 'core/calendar.html', {'m': m, 'employees': employees, 'days': days, 'codes': codes, 'entries': entries, 'can_edit': p and p.role != 'FIN' and m.status != 'CLOSED', 'profile': p})


@login_required
def calendar_fill_8h(r, pk):
    """Uzupełnij 8 h w pustych dniach roboczych wszystkich aktywnych pracowników."""
    m = get_object_or_404(Month.objects.select_related('department'), pk=pk)
    p = pof(r)
    if not p or not allowed(r, m, True) or p.role == 'FIN' or m.status == 'CLOSED' or r.method != 'POST':
        return HttpResponseForbidden()

    days = sync_calendar_days(m.year, m.month)
    working_dates = [d['date'] for d in days if d['is_working']]
    employees = Employee.objects.filter(department=m.department, active=True)
    created = 0
    for emp in employees:
        existing = set(
            CalendarEntry.objects.filter(month=m, employee=emp, day__in=working_dates)
            .values_list('day', flat=True)
        )
        for day in working_dates:
            if day not in existing:
                CalendarEntry.objects.create(month=m, employee=emp, day=day, hours=Decimal('8.00'))
                created += 1

    # Wpisanie danych zmienia stan wyliczenia — trzeba je ponownie policzyć.
    if m.status == Month.CALC or m.status == Month.REOPENED:
        m.status = Month.OPEN
        m.save(update_fields=['status'])
    AuditLog.objects.create(
        user=r.user, month=m, action='FILL_8H',
        details=f'Uzupełniono 8 h w pustych dniach roboczych. Nowych wpisów: {created}.'
    )
    return redirect('calendar', pk=pk)


@login_required
def calendar_save(r, pk):
    m = get_object_or_404(Month, pk=pk)
    p = pof(r)
    if not p or not allowed(r, m, True) or p.role == 'FIN' or m.status == 'CLOSED':
        return HttpResponseForbidden()
    if r.method == 'POST':
        employee_ids = {int(k.split('_')[1]) for k in r.POST if k.startswith('h_') or k.startswith('c_')}
        for eid in employee_ids:
            emp = get_object_or_404(Employee, pk=eid, department=m.department)
            for day_no in range(1, calendar.monthrange(m.year, m.month)[1] + 1):
                hval = r.POST.get(f'h_{eid}_{day_no}', '').strip()
                cval = r.POST.get(f'c_{eid}_{day_no}', '').strip()
                d = date(m.year, m.month, day_no)
                if cval:
                    code = get_object_or_404(AbsenceCode, code=cval, active=True)
                    CalendarEntry.objects.update_or_create(month=m, employee=emp, day=d, defaults={'hours': None, 'code': code})
                elif hval:
                    try:
                        hours = Decimal(hval.replace(',', '.'))
                    except Exception:
                        continue
                    CalendarEntry.objects.update_or_create(month=m, employee=emp, day=d, defaults={'hours': hours, 'code': None})
                else:
                    CalendarEntry.objects.filter(month=m, employee=emp, day=d).delete()
        if m.status == Month.CALC or m.status == Month.REOPENED:
            m.status = Month.OPEN
            m.save(update_fields=['status'])
        AuditLog.objects.create(user=r.user, month=m, action='SAVE_CALENDAR')
        return redirect('calendar', pk=pk)
    return redirect('calendar', pk=pk)


@login_required
def notes_save(r, pk):
    m = get_object_or_404(Month, pk=pk)
    p = pof(r)
    if not p or not allowed(r, m, True) or p.role == 'FIN' or m.status == 'CLOSED':
        return HttpResponseForbidden()
    if r.method == 'POST':
        for e in Employee.objects.filter(department=m.department, active=True):
            EmployeeNote.objects.update_or_create(
                month=m,
                employee=e,
                defaults={
                    'quality': r.POST.get(f'quality_{e.id}', ''),
                    'bhp': r.POST.get(f'bhp_{e.id}', ''),
                    'notes': r.POST.get(f'notes_{e.id}', ''),
                },
            )
        if m.status == Month.CALC or m.status == Month.REOPENED:
            m.status = Month.OPEN
            m.save(update_fields=['status'])
        AuditLog.objects.create(user=r.user, month=m, action='SAVE_NOTES')
        return redirect('month', pk=pk)
    return redirect('month', pk=pk)


@login_required
def calculate(r, pk):
    m = get_object_or_404(Month, pk=pk)
    p = pof(r)
    if not p or not allowed(r, m, True) or p.role == 'FIN' or m.status == 'CLOSED':
        return HttpResponseForbidden()
    calculate_month(m)
    AuditLog.objects.create(user=r.user, month=m, action='CALCULATE')
    return redirect('month', pk=pk)


@login_required
def close_month(r, pk):
    m = get_object_or_404(Month, pk=pk)
    p = pof(r)
    if not p or not allowed(r, m, True) or p.role == 'FIN' or m.status == 'CLOSED':
        return HttpResponseForbidden()
    if r.method == 'POST':
        m.status = Month.CLOSED
        m.closed_at = timezone.now()
        m.save()
        AuditLog.objects.create(user=r.user, month=m, action='CLOSE')
        return redirect('month', pk=pk)
    return render(r, 'core/confirm.html', {'m': m, 'action': 'zamknąć miesiąc'})


@login_required
def reopen_month(r, pk):
    m = get_object_or_404(Month, pk=pk)
    p = pof(r)
    if not p or p.role != 'ADMIN':
        return HttpResponseForbidden()
    if r.method == 'POST':
        m.status = Month.REOPENED
        m.closed_at = None
        m.save()
        AuditLog.objects.create(user=r.user, month=m, action='REOPEN', details=r.POST.get('reason', ''))
        return redirect('month', pk=pk)
    return render(r, 'core/confirm.html', {'m': m, 'action': 'odblokować miesiąc', 'reopen': True})
