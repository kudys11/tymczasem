# System Premii – Django + PostgreSQL + Docker Compose

## Uruchomienie
W katalogu projektu:

```bash
docker compose up -d --build
```

Aplikacja będzie dostępna na:

**http://ADRES_OMV:8001**

PostgreSQL działa tylko wewnątrz sieci Compose na porcie **5432** i nie jest wystawiany na hosta.

### Pierwszy administrator
Po uruchomieniu:

```bash
docker compose exec web python manage.py createsuperuser
```

Następnie wejdź na `http://ADRES_OMV:8001/admin/`. Role/grupy są tworzone automatycznie przy pierwszym uruchomieniu. Administrator może tam utworzyć działy, użytkowników, profile, kody nieobecności oraz święta i dni wolne.

## Ważne
- `EXPORT.XLSX` jest opcjonalnym importem SAP zależnym od działu.
- Kalendarz jest prowadzony bezpośrednio w aplikacji: godziny lub kod nieobecności.
- `AbsenceCode` zastępuje legendę kodów: kod, opis i sposób rozliczenia.
- Jakość/BHP/Uwagi są opisowe i wprowadzane ręcznie.
- Zamknięty miesiąc jest chroniony przed edycją; ponowne otwarcie jest dostępne tylko dla Administratora.
- Finanse mają podgląd wszystkich działów bez funkcji edycji, liczenia, importu i zamykania.
- Operacje importu, wyliczeń, zamknięcia i odblokowania są zapisywane w audycie.
- Migracje Django są już dołączone — przy starcie używane jest `migrate --noinput`, bez `--run-syncdb`.
- PostgreSQL ma healthcheck, a kontener aplikacji czeka również na dostępność bazy.

## Reset testowej bazy
Jeżeli to jest środowisko testowe i chcesz zacząć od pustej bazy:

```bash
docker compose down -v
docker compose up -d --build
```

**Nie używaj `-v`, jeśli chcesz zachować dane.**

## Stan logiki premii
Ta paczka naprawia uruchamianie infrastruktury i pozostawia istniejący algorytm aplikacji: baza 600 zł oraz potrącenia wynikające z wpisów w kalendarzu. Szczegółowe reguły 1:1 z arkuszem Excel wymagają jeszcze osobnej walidacji przed użyciem produkcyjnym.


## Role i język

Przy każdym uruchomieniu wykonywane jest idempotentne `bootstrap_roles`. Tworzone są role/grupy:
- **Użytkownik działu**
- **Finanse**
- **Administrator**

Jeżeli istnieje superuser Django, automatycznie otrzymuje profil `Administrator` oraz grupę `Administrator`. Nie jest tworzony domyślny login i hasło.

Panel administracyjny Django jest ustawiony na język polski.


## Ostatnie funkcje
- Nawigacja między panelem, pracownikami, miesiącem i kalendarzem.
- Kalendarz pokazuje skróty dni tygodnia: Pn, Wt, Śr, Czw, Pt, Sob, Nd oraz oznacza święta, niedziele i soboty.
- Kody nieobecności są wybierane z listy w każdej komórce; osobno można wpisać godziny.
- Kod nieobecności może być oznaczony jako „dyskwalifikuje premię” w panelu administracyjnym. Wystąpienie takiego kodu daje 0 zł dla pracownika w trybie standardowym.
- Pracownik oznaczony jako „Portier — pełna premia” otrzymuje pełną premię bazową; tryb Portier ma pierwszeństwo przed dyskwalifikującym kodem.


## Święta i dni wolne

Święta i dodatkowe dni wolne są przechowywane w PostgreSQL w modelu „Święta i dni wolne”. Przy wejściu do kalendarza danego roku aplikacja automatycznie uzupełnia w PostgreSQL znane święta dla tego konkretnego roku. Nie ma sztywnej granicy roku 2036/2037. Administrator może w panelu „📅 Święta” dodawać, wyłączać i edytować kolejne dni wolne bez przebudowy obrazu Docker. Administrator może w panelu „📅 Święta” dodawać, wyłączać i edytować kolejne dni wolne bez przebudowy obrazu Docker.

Pole „Pomniejsza liczbę dni roboczych” określa, czy dany dzień wpływa na mianownik dni roboczych używany przez kalkulator. Zmiany kalendarza nie zmieniają zapisanych wyników zamkniętego miesiąca, dopóki miesiąc nie zostanie ponownie otwarty i przeliczony.


### Premia bazowa działu
Każdy dział ma własną edytowalną premię bazową. Ustawienie działu jest automatycznie używane jako wartość początkowa przy tworzeniu nowych miesięcy. Na otwartym miesiącu użytkownik działu lub administrator może zmienić premię bazową; zmiana aktualizuje również ustawienie działu dla kolejnych miesięcy. Zamknięte miesiące pozostają niezmienione.

### Kalendarz — szybkie uzupełnienie 8 godzin
W kalendarzu dostępny jest przycisk **„⏱️ Uzupełnij 8 h w dni robocze”**. Uzupełnia on 8,00 h we wszystkich pustych dniach roboczych wszystkich aktywnych pracowników. Istniejące godziny i kody nieobecności pozostają bez zmian. Operacja jest zapisywana w dzienniku audytu.

### Status miesiąca na panelu głównym
Na panelu głównym status każdego miesiąca jest pokazany kolorem i ikoną: 🟢 Otwarty, 🧮 Wyliczony, 🔒 Zamknięty oraz 🔓 Ponownie otwarty. Zmiana danych po wyliczeniu (np. kalendarza, opisów, importu SAP lub premii bazowej) cofa status do „Otwarty”, aby było jasne, że miesiąc wymaga ponownego przeliczenia.
