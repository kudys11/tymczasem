from decimal import Decimal, ROUND_HALF_UP
from datetime import date, timedelta
import calendar
from .models import CalendarDay, CalendarEntry, Employee, PremiumResult, Holiday


def easter_sunday(year):
    a = year % 19; b = year // 100; c = year % 100
    d = b // 4; e = b % 4; f = (b + 8) // 25; g = (b - f + 1) // 3
    h = (19*a + b - d - g + 15) % 30; i = c // 4; k = c % 4
    l = (32 + 2*e + 2*i - h - k) % 7; m = (a + 11*h + 22*l) // 451
    month = (h + l - 7*m + 114) // 31; day = ((h + l - 7*m + 114) % 31) + 1
    return date(year, month, day)


def polish_holidays(year):
    easter = easter_sunday(year)
    fixed = {
        date(year,1,1): 'Nowy Rok', date(year,1,6): 'Święto Trzech Króli',
        date(year,5,1): 'Święto Pracy', date(year,5,3): 'Święto Konstytucji 3 Maja',
        date(year,8,15): 'Wniebowzięcie Najświętszej Maryi Panny',
        date(year,11,1): 'Wszystkich Świętych', date(year,11,11): 'Narodowe Święto Niepodległości',
        date(year,12,25): 'Boże Narodzenie (1. dzień)', date(year,12,26): 'Boże Narodzenie (2. dzień)',
    }
    if year >= 2025:
        fixed[date(year,12,24)] = 'Wigilia Bożego Narodzenia'
    movable = {easter + timedelta(days=1): 'Poniedziałek Wielkanocny', easter + timedelta(days=49): 'Zielone Świątki', easter + timedelta(days=60): 'Boże Ciało'}
    return {**fixed, **movable}


WEEKDAYS = ['poniedziałek','wtorek','środa','czwartek','piątek','sobota','niedziela']
WEEKDAYS_SHORT = ['Pn','Wt','Śr','Czw','Pt','Sob','Nd']


def seed_default_holidays(year):
    """Uzupełnia bazę o ustawowe polskie święta znane aplikacji.

    Administrator może później dodać dodatkowy dzień wolny w panelu.
    Dane są w bazie, więc zmiana listy nie wymaga przebudowy kontenera.
    """
    for holiday_date, name in polish_holidays(year).items():
        Holiday.objects.get_or_create(
            date=holiday_date,
            defaults={
                'name': name,
                'kind': 'HOLIDAY',
                'affects_working_days': True,
                'active': True,
            },
        )


def sync_calendar_days(year, month):
    seed_default_holidays(year)
    holiday_qs = Holiday.objects.filter(
        date__year=year, date__month=month, active=True
    )
    holidays = {h.date: h for h in holiday_qs}
    result = []
    for n in range(1, calendar.monthrange(year, month)[1] + 1):
        d = date(year, month, n)
        holiday = holidays.get(d)
        is_sunday = d.weekday() == 6
        is_saturday = d.weekday() == 5
        is_working = (
            d.weekday() < 5
            and not (holiday and holiday.affects_working_days)
        )
        label = holiday.name if holiday else (
            'Niedziela' if is_sunday else ('Sobota' if is_saturday else '')
        )
        CalendarDay.objects.update_or_create(
            date=d,
            defaults={'is_working': is_working, 'label': label},
        )
        result.append({
            'day': n,
            'date': d,
            'weekday': WEEKDAYS[d.weekday()],
            'weekday_short': WEEKDAYS_SHORT[d.weekday()],
            'is_working': is_working,
            'is_sunday': is_sunday,
            'is_holiday': bool(holiday),
            'is_day_off': bool(holiday and holiday.kind == 'DAY_OFF'),
            'label': label,
        })
    return result


def working_days(year, month):
    sync_calendar_days(year, month)
    return CalendarDay.objects.filter(date__year=year, date__month=month, is_working=True).count()


def calculate_month(m):
    wd = working_days(m.year, m.month); caldays = calendar.monthrange(m.year, m.month)[1]
    PremiumResult.objects.filter(month=m).delete()
    employees = Employee.objects.filter(department=m.department, active=True)
    for e in employees:
        granted = m.base_premium
        dw = Decimal('0'); dc = Decimal('0'); disqualified = False
        detail = {'base': str(granted), 'working_days': wd, 'calendar_days': caldays, 'premium_mode': e.premium_mode, 'codes': [], 'disqualified': False}
        for ce in CalendarEntry.objects.filter(month=m, employee=e).select_related('code'):
            if not ce.code:
                continue
            if ce.code.disqualifies_premium:
                disqualified = True
            if ce.code.basis == 'WORKING': dw += Decimal('1')
            elif ce.code.basis == 'CALENDAR': dc += Decimal('1')
            detail['codes'].append({'date': str(ce.day), 'code': ce.code.code, 'basis': ce.code.basis, 'disqualifies_premium': ce.code.disqualifies_premium})
        detail['disqualified'] = disqualified
        if e.premium_mode == Employee.PREMIUM_PORTIER:
            deduction_working = Decimal('0'); deduction_calendar = Decimal('0'); payable = granted
            detail['reason'] = 'Portier — pełna premia bez umniejszeń.'
        elif disqualified:
            deduction_working = Decimal('0'); deduction_calendar = Decimal('0'); payable = Decimal('0.00')
            detail['reason'] = 'Wystąpił kod nieobecności dyskwalifikujący premię.'
        else:
            deduction_working = (granted/Decimal(wd)*dw) if wd else Decimal('0')
            deduction_calendar = granted/Decimal('30')*dc
            payable = max(Decimal('0'), granted-deduction_working-deduction_calendar).quantize(Decimal('0.01'), ROUND_HALF_UP)
        PremiumResult.objects.create(month=m, employee=e, granted=granted, deduction_working=deduction_working.quantize(Decimal('0.01'), ROUND_HALF_UP), deduction_calendar=deduction_calendar.quantize(Decimal('0.01'), ROUND_HALF_UP), payable=payable.quantize(Decimal('0.01'), ROUND_HALF_UP), calculation_details=detail)
    m.status = 'CALC'; m.save(update_fields=['status'])


SAP_COMPARE_FIELDS = [
    ('overtime', 'Nadgodz/Godz.ujem.'),
    ('vacation', 'Urlop wypoczynkowy'),
    ('sick', 'choroba zwykła'),
    ('unpaid_absence', 'Nieob. nieuspr. niepłatna'),
    ('other_absence', 'Pozost. nieobecn.'),
]

def calendar_sap_comparison(month):
    """Zwraca porównanie wartości SAP z kalendarzem dla pracowników miesiąca.

    Mapowania są konfigurowane przez Administratora. Dla każdego pola SAP można
    przypisać wiele kodów nieobecności. COUNT_DAYS liczy wpisy kodu, a SUM_HOURS
    sumuje godziny zapisane przy tych wpisach.
    """
    from .models import SAPCalendarMapping, SAPRecord

    rules = list(SAPCalendarMapping.objects.filter(active=True).select_related('code'))
    by_code = {}
    configured = {field: False for field, _ in SAP_COMPARE_FIELDS}
    for rule in rules:
        by_code.setdefault(rule.code_id, []).append(rule)
        configured[rule.sap_field] = True

    sap = {x.personnel_no: x for x in SAPRecord.objects.filter(month=month)}
    employees = list(Employee.objects.filter(department=month.department, active=True).order_by('sort_order', 'last_name', 'first_name', 'id'))
    entries = CalendarEntry.objects.filter(month=month, employee__in=employees).select_related('code')
    totals = {e.id: {field: Decimal('0') for field, _ in SAP_COMPARE_FIELDS} for e in employees}
    for ce in entries:
        if not ce.code:
            continue
        for rule in by_code.get(ce.code_id, []):
            if rule.aggregation == SAPCalendarMapping.SUM_HOURS:
                value = ce.hours or Decimal('0')
            else:
                value = Decimal('1')
            totals[ce.employee_id][rule.sap_field] += value

    result = {}
    for e in employees:
        sr = sap.get(e.personnel_no)
        values = {}
        for field, label in SAP_COMPARE_FIELDS:
            sap_value = Decimal(str(getattr(sr, field))) if sr else Decimal('0')
            cal_value = totals[e.id][field]
            diff = (cal_value - sap_value).quantize(Decimal('0.01'), ROUND_HALF_UP)
            values[field] = {
                'label': label, 'sap': sap_value, 'calendar': cal_value, 'difference': diff,
                'configured': configured[field],
                'ok': configured[field] and diff == Decimal('0.00'),
            }
        result[e.id] = values
    return result, configured
