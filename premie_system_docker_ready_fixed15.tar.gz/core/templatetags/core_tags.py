from django import template
register = template.Library()

@register.filter
def get_item(mapping, key):
    return mapping.get(key)

@register.filter
def get_item2(mapping, key):
    if mapping is None:
        return None
    return mapping.get(key)
