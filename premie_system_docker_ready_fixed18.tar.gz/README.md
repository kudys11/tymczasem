# System Premii — fixed17

Poprawki względem fixed16:

- Widok miesiąca ma kolejność sekcji: **💰 Wyniki premii** (dopiero po wyliczeniu) → **Porównanie SAP ↔ Kalendarz** → **Jakość / BHP / Uwagi** → **📋 Dane pracowników i SAP** jako ostatnia sekcja.
- W **💰 Wyniki premii** dodano wartości z kalendarza dla: Urlop wypoczynkowy, choroba zwykła, Nieob. nieuspr. niepłatna, Pozost. nieobecn.
- Przycisk **📊 Eksport Excel** znajduje się wyłącznie w sekcji **💰 Wyniki premii** i jest dostępny po wyliczeniu wyniku (status CALC/CLOSED). Eksport zawiera również wartości kalendarza.
- Po zmianie kalendarza wyniki są ukrywane do ponownego wyliczenia, aby nie pokazywać nieaktualnych wyników.
- **📋 Dane pracowników i SAP** ma sticky belkę **← Lewo / Prawo →** do poziomego przewijania szerokiej tabeli.
- Zachowano wcześniejszą poprawkę `TooManyFieldsSent` oraz nawigację poziomą kalendarza.

Wdrożenie jak dla poprzednich paczek: rozpakować projekt i wykonać `docker compose up -d --build`.
