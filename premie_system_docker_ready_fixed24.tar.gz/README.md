# System Premii — Docker

## Ewidencja czasu pracy

Każdy dział ma ustawienie **System ewidencji czasu**:
- `Kalendarz — wpisywanie liczby godzin` — dotychczasowy sposób,
- `Ewidencja czasu — początek / koniec + godziny nocne` — wpisywanie początku i końca pracy.

Ustawienie działu jest domyślne dla nowych miesięcy. Miesiąc przechowuje własny wybór, więc zmiana działu nie zmienia historycznych miesięcy. Administrator może również zmienić system dla otwartego miesiąca w Kalendarzu.

W trybie początku/końca:
- godziny nocne są liczone automatycznie jako `22:00–06:00`,
- przejście przez północ jest obsługiwane, np. `18:00–06:00` = `12,00 h` pracy, w tym `8,00 h` nocnych,
- nadgodziny/godziny ujemne = przepracowane − plan,
- saldo nadgodzin przechodzi chronologicznie na następny miesiąc,
- można wpisać `Wolne za nadgodziny (h)`, które zmniejsza dostępne dodatnie saldo,
- w kalendarzu widoczne są: przepracowane, nocne, nadgodziny/godziny ujemne, wykorzystane wolne oraz saldo końcowe.

`Nadgodziny/godziny ujemne` w porównaniu SAP ↔ Kalendarz są liczone bez mapowania, bezpośrednio z ewidencji czasu.
