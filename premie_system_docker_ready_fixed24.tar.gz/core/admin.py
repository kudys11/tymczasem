from django.contrib import admin
from .models import *

admin.site.site_header = 'System Premii — Administracja'
admin.site.site_title = 'System Premii'
admin.site.index_title = 'Panel administracyjny'


@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ('name', 'use_sap', 'time_tracking_mode', 'base_premium')
    list_filter = ('use_sap', 'time_tracking_mode')
    search_fields = ('name',)


@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'role', 'department')
    list_filter = ('role', 'department')
    search_fields = ('user__username', 'user__first_name', 'user__last_name')


@admin.register(AbsenceCode)
class AbsenceCodeAdmin(admin.ModelAdmin):
    list_display = ('code', 'description', 'basis', 'disqualifies_premium', 'active', 'sort_order')
    list_filter = ('basis', 'disqualifies_premium', 'active')
    search_fields = ('code', 'description')
    ordering = ('sort_order', 'code')


@admin.register(Holiday)
class HolidayAdmin(admin.ModelAdmin):
    list_display = ('date', 'name', 'kind', 'affects_working_days', 'active')
    list_filter = ('kind', 'affects_working_days', 'active')
    search_fields = ('name',)
    ordering = ('date',)


@admin.register(CalendarDay)
class CalendarDayAdmin(admin.ModelAdmin):
    list_display = ('date', 'is_working', 'label')
    list_filter = ('is_working',)
    search_fields = ('label',)


@admin.register(Month)
class MonthAdmin(admin.ModelAdmin):
    list_display = ('department', 'year', 'month', 'status', 'base_premium', 'created_at', 'closed_at')
    list_filter = ('status', 'department', 'year')


@admin.register(Employee)
class EmployeeAdmin(admin.ModelAdmin):
    list_display = ('personnel_no', 'last_name', 'first_name', 'department', 'premium_mode', 'active')
    list_filter = ('department', 'premium_mode', 'active')
    search_fields = ('personnel_no', 'last_name', 'first_name')


@admin.register(SAPRecord)
class SAPRecordAdmin(admin.ModelAdmin):
    list_display = ('month', 'personnel_no', 'last_name', 'first_name', 'subgroup', 'epc', 'efficiency', 'gk', 'overtime')
    list_filter = ('month', 'subgroup', 'epc')
    search_fields = ('personnel_no', 'last_name', 'first_name')


@admin.register(SAPCalendarMapping)
class SAPCalendarMappingAdmin(admin.ModelAdmin):
    list_display = ('sap_field', 'code', 'aggregation', 'active')
    list_filter = ('sap_field', 'aggregation', 'active')
    search_fields = ('code__code', 'code__description')
    list_select_related = ('code',)


@admin.register(CalendarEntry)
class CalendarEntryAdmin(admin.ModelAdmin):
    list_display = ('month', 'employee', 'day', 'hours', 'start_time', 'end_time', 'overtime_leave_hours', 'code')
    list_filter = ('month', 'code')
    search_fields = ('employee__personnel_no', 'employee__last_name')


@admin.register(EmployeeNote)
class EmployeeNoteAdmin(admin.ModelAdmin):
    list_display = ('month', 'employee')
    list_filter = ('month',)
    search_fields = ('employee__personnel_no', 'employee__last_name')


@admin.register(PremiumResult)
class PremiumResultAdmin(admin.ModelAdmin):
    list_display = ('month', 'employee', 'granted', 'deduction_working', 'deduction_calendar', 'payable')
    list_filter = ('month',)
    search_fields = ('employee__personnel_no', 'employee__last_name')


@admin.register(AuditLog)
class AuditLogAdmin(admin.ModelAdmin):
    list_display = ('created_at', 'user', 'month', 'action', 'details')
    list_filter = ('action', 'created_at')
    search_fields = ('user__username', 'action', 'details')
    readonly_fields = ('created_at',)

@admin.register(OvertimeBalance)
class OvertimeBalanceAdmin(admin.ModelAdmin):
    list_display = ('month', 'employee', 'carried_in', 'worked_hours', 'planned_hours', 'overtime', 'night_hours', 'overtime_leave_hours', 'carried_out')
    list_filter = ('month',)
    search_fields = ('employee__personnel_no', 'employee__last_name')
