# System Premii — Docker

## Ewidencja czasu pracy

Każdy dział ma ustawienie **System ewidencji czasu**:
- `Kalendarz — wpisywanie liczby godzin` — dotychczasowy sposób,
- `Ewidencja czasu — początek / koniec + godziny nocne` — wpisywanie początku i końca pracy.

Ustawienie działu jest domyślne dla nowych miesięcy. Miesiąc przechowuje własny wybór, więc zmiana działu nie zmienia historycznych miesięcy. Administrator może również zmienić system dla otwartego miesiąca w Kalendarzu.

W trybie początku/końca:
- godziny nocne są liczone automatycznie jako `22:00–06:00`,
- przejście przez północ jest obsługiwane, np. `18:00–06:00` = `12,00 h` pracy, w tym `8,00 h` nocnych,
- nadgodziny/godziny ujemne = przepracowane − plan,
- saldo nadgodzin przechodzi chronologicznie na następny miesiąc,
- można wpisać `Wolne za nadgodziny (h)`, które zmniejsza dostępne dodatnie saldo,
- w kalendarzu widoczne są: przepracowane, nocne, nadgodziny/godziny ujemne, wykorzystane wolne oraz saldo końcowe.

`Nadgodziny/godziny ujemne` w porównaniu SAP ↔ Kalendarz są liczone bez mapowania, bezpośrednio z ewidencji czasu.

## Brygady

Pracownik ma przypisaną **brygadę** (np. 1, 2, 3). Kalendarz jest sortowany najpierw po brygadzie, a następnie po pozycji pracownika w brygadzie. W Administracji numer brygady można również zmieniać bezpośrednio na liście pracowników.

W funkcji **Uzupełnij godziny** brygada jest podstawowym sposobem wyboru większej grupy pracowników. Można wybrać jedną lub kilka brygad, a opcjonalnie rozwinąć wybór pojedynczych osób. Dzięki temu przy dużej liczbie pracowników nie trzeba zaznaczać 100 nazwisk.

## Import SAP per dział

W **Administracja → Działy** ustawienie **Korzysta z importu SAP** decyduje, czy dany dział korzysta z importu SAP. Dla działu bez SAP nie jest pokazywany przycisk importu ani sekcje porównania SAP w miesiącu, a eksport nie tworzy arkuszy `SAP - źródło` i `SAP-Kalendarz`.
