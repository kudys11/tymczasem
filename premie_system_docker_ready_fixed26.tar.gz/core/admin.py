from django.contrib import admin
from .models import *

admin.site.site_header = 'System Premii — Administracja'
admin.site.site_title = 'System Premii'
admin.site.index_title = 'Panel administracyjny'


@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ('name', 'use_sap', 'time_tracking_mode', 'base_premium')
    list_filter = ('use_sap', 'time_tracking_mode')
    search_fields = ('name',)


@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'role', 'department')
    list_filter = ('role', 'department')
    search_fields = ('user__username', 'user__first_name', 'user__last_name')


@admin.register(AbsenceCode)
class AbsenceCodeAdmin(admin.ModelAdmin):
    list_display = ('code', 'description', 'basis', 'disqualifies_premium', 'active', 'sort_order')
    list_filter = ('basis', 'disqualifies_premium', 'active')
    search_fields = ('code', 'description')
    ordering = ('sort_order', 'code')


@admin.register(Holiday)
class HolidayAdmin(admin.ModelAdmin):
    list_display = ('date', 'name', 'kind', 'affects_working_days', 'active')
    list_filter = ('kind', 'affects_working_days', 'active')
    search_fields = ('name',)
    ordering = ('date',)


@admin.register(CalendarDay)
class CalendarDayAdmin(admin.ModelAdmin):
    list_display = ('date', 'is_working', 'label')
    list_filter = ('is_working',)
    search_fields = ('label',)
