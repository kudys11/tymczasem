from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden, HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from openpyxl import load_workbook
from decimal import Decimal
from datetime import date, datetime
import calendar
from .models import *
from .services import calculate_month, working_days, sync_calendar_days, calendar_sap_comparison, month_time_rows, rebuild_overtime_balances, entry_worked_hours_and_night


def pof(r):
    """Return the application profile, creating an ADMIN profile for superusers."""
    if not r.user.is_authenticated:
        return None
    p = getattr(r.user, 'profile', None)
    if p is None and r.user.is_superuser:
        p, _ = Profile.objects.get_or_create(
            user=r.user,
            defaults={'role': Profile.ROLE_ADMIN},
        )
        if p.role != Profile.ROLE_ADMIN or p.department_id is not None:
            p.role = Profile.ROLE_ADMIN
            p.department = None
            p.save(update_fields=['role', 'department'])
    return p


def allowed(r, m, write=False):
    p = pof(r)
    if not p:
        return False
    if p.role == 'ADMIN':
        return True
    if p.role == 'FIN':
        return not write
    return p.department_id == m.department_id


def login_view(r):
    if r.user.is_authenticated:
        return redirect('dashboard')
    if r.method == 'POST':
        u = authenticate(r, username=r.POST.get('username'), password=r.POST.get('password'))
        if u:
            login(r, u)
            return redirect('dashboard')
    return render(r, 'registration/login.html')


def logout_view(r):
    logout(r)
    return redirect('login')


@login_required
def dashboard(r):
    p = pof(r)
    if p is None:
        return HttpResponseForbidden('Brak przypisanej roli użytkownika. Administrator powinien utworzyć profil użytkownika.')

    departments = Department.objects.all().order_by('name')
    if p.role == 'DEPT':
        departments = departments.filter(pk=p.department_id)

    # Pierwszy panel pokazuje wybrany okres dla wszystkich dostępnych działów.
    available_months = Month.objects.select_related('department').filter(status__in=[Month.OPEN, Month.CALC, Month.REOPENED])
    if p.role == 'DEPT':
        available_months = available_months.filter(department=p.department)
    available_months = available_months.order_by('-year', '-month', 'department__name')

    selected_period = r.GET.get('period', '').strip()
    if not selected_period:
        first = available_months.first()
        selected_period = f'{first.year:04d}-{first.month:02d}' if first else f'{timezone.localdate().year:04d}-{timezone.localdate().month:02d}'

    try:
        sy, sm = [int(x) for x in selected_period.split('-', 1)]
        if not (1 <= sm <= 12 and 2000 <= sy <= 2100):
            raise ValueError
        selected_period = f'{sy:04d}-{sm:02d}'
    except (ValueError, TypeError):
        sy, sm = timezone.localdate().year, timezone.localdate().month
        selected_period = f'{sy:04d}-{sm:02d}'

    selected_qs = Month.objects.select_related('department').filter(year=sy, month=sm)
    if p.role == 'DEPT':
        selected_qs = selected_qs.filter(department=p.department)
    selected_map = {m.department_id: m for m in selected_qs}
    selected_departments = [
        {'department': dept, 'month': selected_map.get(dept.id)}
        for dept in departments
    ]

    # Wszystkie pozostałe miesiące otwarte/wyliczone, których nie pokazuje pierwszy panel.
    other_months = available_months.exclude(year=sy, month=sm)

    # Katalog zamkniętych miesięcy. Pusty zakres nie wykonuje zapytania.
    closed_from = r.GET.get('closed_from', '').strip()
    closed_to = r.GET.get('closed_to', '').strip()
    closed_months = Month.objects.none()
    if closed_from and closed_to:
        try:
            fy, fm = [int(x) for x in closed_from.split('-', 1)]
            ty, tm = [int(x) for x in closed_to.split('-', 1)]
            from_key = fy * 12 + fm
            to_key = ty * 12 + tm
            if 1 <= fm <= 12 and 1 <= tm <= 12 and from_key <= to_key:
                closed_months = Month.objects.select_related('department').filter(status=Month.CLOSED)
                if p.role == 'DEPT':
                    closed_months = closed_months.filter(department=p.department)
                closed_months = [m for m in closed_months if from_key <= m.year * 12 + m.month <= to_key]
                closed_months.sort(key=lambda m: (m.year, m.month, m.department.name), reverse=True)
        except (ValueError, TypeError):
            closed_months = []

    return render(r, 'core/dashboard.html', {
        'months': other_months,
        'profile': p,
        'departments': departments,
        'selected_departments': selected_departments,
        'selected_period': selected_period,
        'closed_from': closed_from,
        'closed_to': closed_to,
        'closed_months': closed_months,
    })


@login_required
def export_closed_month(r, pk):
    """Eksport zamkniętego miesiąca w układzie zbliżonym do arkusza źródłowego premii."""
    m = get_object_or_404(Month.objects.select_related('department'), pk=pk)
    if not allowed(r, m):
        return HttpResponseForbidden()

    # Eksport jest dostępny po wyliczeniu premii (niezależnie od tego, czy miesiąc
    # został już zamknięty). Dzięki temu przycisk może należeć wyłącznie do sekcji
    # „Wyniki premii”.
    if m.status not in (Month.CALC, Month.CLOSED) or not PremiumResult.objects.filter(month=m).exists():
        return HttpResponseForbidden()

    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
    from openpyxl.utils import get_column_letter

    results = list(PremiumResult.objects.filter(month=m).select_related('employee').order_by(
        'employee__sort_order', 'employee__last_name', 'employee__first_name'
    ))
    sap = {x.personnel_no: x for x in SAPRecord.objects.filter(month=m)}
    notes = {x.employee_id: x for x in EmployeeNote.objects.filter(month=m)}
    comparison, configured = calendar_sap_comparison(m) if m.department.use_sap else ({}, {})

    wb = Workbook()
    ws = wb.active
    ws.title = 'Premie'

    # Główny arkusz jest celowo płaski i odpowiada danym używanym w arkuszu źródłowym:
    # dane SAP + dane kalendarza/premii + ręczne opisy.
    headers = [
        'Raport wywołano', 'Okres rozliczeniowy', 'Zakład', 'Numer osobowy',
        'Imię', 'Nazwisko', 'Brygada', 'Data zatrudnienia', 'Podgrupa pracowników', 'EPC',
        'Efektywność w %', 'GK', 'Nadgodz/Godz.ujem.', 'Urlop wypoczynkowy',
        'choroba zwykła', 'Nieob. nieuspr. niepłatna', 'Pozost. nieobecn.',
        'Urlop wypoczynkowy — Kalendarz', 'choroba zwykła — Kalendarz',
        'Nieob. nieuspr. niepłatna — Kalendarz', 'Pozost. nieobecn. — Kalendarz',
        'Tryb', 'Premia bazowa', 'Potrącenie robocze', 'Potrącenie kalendarzowe',
        'Dyskwalifikacja', 'Do wypłaty', 'Jakość', 'BHP', 'Uwagi'
    ]
    ws.append(headers)
    for x in results:
        e = x.employee
        sr = sap.get(e.personnel_no)
        n = notes.get(e.id)
        details = x.calculation_details or {}
        cmp = comparison.get(e.id, {})
        cal_vac = cmp.get('vacation', {}).get('calendar', Decimal('0'))
        cal_sick = cmp.get('sick', {}).get('calendar', Decimal('0'))
        cal_unpaid = cmp.get('unpaid_absence', {}).get('calendar', Decimal('0'))
        cal_other = cmp.get('other_absence', {}).get('calendar', Decimal('0'))
        ws.append([
            sr.report_called if sr else '',
            sr.settlement_period if sr else f'{m.month:02d}/{m.year}',
            sr.plant if sr else m.department.name,
            e.personnel_no, e.first_name, e.last_name, e.brigade,
            sr.employment_date if sr else None,
            sr.subgroup if sr else '', sr.epc if sr else '',
            float(sr.efficiency) if sr else None,
            float(sr.gk) if sr else None,
            float(sr.overtime) if sr else None,
            float(sr.vacation) if sr else None,
            float(sr.sick) if sr else None,
            float(sr.unpaid_absence) if sr else None,
            float(sr.other_absence) if sr else None,
            float(cal_vac), float(cal_sick), float(cal_unpaid), float(cal_other),
            'Portier' if e.premium_mode == Employee.PREMIUM_PORTIER else 'Standardowe',
            float(x.granted), float(x.deduction_working), float(x.deduction_calendar),
            'TAK' if details.get('disqualified') else 'NIE', float(x.payable),
            n.quality if n else '', n.bhp if n else '', n.notes if n else '',
        ])

    # Kalendarz pozostaje osobnym arkuszem, aby eksport zachował pełny zapis każdego dnia.
    ws_cal = wb.create_sheet('Kalendarz')
    days = sync_calendar_days(m.year, m.month)
    employees = Employee.objects.filter(department=m.department).order_by('brigade', 'sort_order', 'last_name', 'first_name', 'id')
    entries = {(ce.employee_id, ce.day): ce for ce in CalendarEntry.objects.filter(month=m).select_related('code')}
    ws_cal.append(['Brygada', 'Nr osobowy', 'Nazwisko', 'Imię'] + [f"{d['day']:02d} {d['weekday_short']}" for d in days] + ['Przepracowane h', 'Nocne h', 'Nadgodz/Godz.ujem.', 'Wolne za nadgodziny h', 'Saldo na następny miesiąc'])
    balance_map = {b.employee_id: b for b in OvertimeBalance.objects.filter(month=m)}
    time_rows = month_time_rows(m)
    for emp in employees:
        row = [emp.brigade, emp.personnel_no, emp.last_name, emp.first_name]
        for d in days:
            ce = entries.get((emp.id, d['date']))
            if ce and ce.code:
                value = ce.code.code
            elif ce and m.time_tracking_mode == Department.TIME_CLOCK and ce.start_time and ce.end_time:
                value = f'{ce.start_time:%H:%M}-{ce.end_time:%H:%M}'
            elif ce and ce.hours is not None:
                value = float(ce.hours)
            else:
                value = ''
            if ce and ce.overtime_leave_hours is not None and value == '': value = f'WOLNE {ce.overtime_leave_hours} h'
            row.append(value)
        tr = time_rows.get(emp.id, {})
        bal = balance_map.get(emp.id)
        row += [float(tr.get('worked_hours', 0)), float(tr.get('night_hours', 0)), float(tr.get('overtime', 0)), float(bal.overtime_leave_hours if bal else 0), float(bal.carried_out if bal else tr.get('overtime', 0))]
        ws_cal.append(row)

    if m.department.use_sap:
        ws_sap = wb.create_sheet('SAP - źródło')
        sap_headers = [
            'Raport wywołano', 'Okres rozliczeniowy', 'Zakład', 'Numer osobowy', 'Imię', 'Nazwisko',
            'Data zatrudnienia', 'Podgrupa pracowników', 'EPC', 'Efektywność w %', 'GK',
            'Nadgodz/Godz.ujem.', 'Urlop wypoczynkowy', 'choroba zwykła',
            'Nieob. nieuspr. niepłatna', 'Pozost. nieobecn.'
        ]
        ws_sap.append(sap_headers)
        for sr in sorted(sap.values(), key=lambda x: (x.last_name, x.first_name, x.personnel_no)):
            ws_sap.append([
                sr.report_called, sr.settlement_period, sr.plant, sr.personnel_no, sr.first_name, sr.last_name,
                sr.employment_date, sr.subgroup, sr.epc, float(sr.efficiency), float(sr.gk), float(sr.overtime),
                float(sr.vacation), float(sr.sick), float(sr.unpaid_absence), float(sr.other_absence)
            ])

        # Osobny arkusz kontroli zgodności SAP z kalendarzem. Zachowuje zarówno
        # wartości źródłowe SAP, jak i wartości wyliczone z kodów kalendarza.
        ws_cmp = wb.create_sheet('SAP-Kalendarz')
        cmp_headers = ['Nr osobowy', 'Nazwisko', 'Imię']
        for field, label in [
            ('overtime', 'Nadgodz/Godz.ujem.'),
            ('vacation', 'Urlop wypoczynkowy'),
            ('sick', 'choroba zwykła'),
            ('unpaid_absence', 'Nieob. nieuspr. niepłatna'),
            ('other_absence', 'Pozost. nieobecn.'),
        ]:
            cmp_headers += [f'{label} — SAP', f'{label} — Kalendarz', f'{label} — Różnica']
        ws_cmp.append(cmp_headers)
        for emp in employees:
            c = comparison.get(emp.id, {})
            row = [emp.personnel_no, emp.last_name, emp.first_name]
            for field, label in [
                ('overtime', 'Nadgodz/Godz.ujem.'),
                ('vacation', 'Urlop wypoczynkowy'),
                ('sick', 'choroba zwykła'),
                ('unpaid_absence', 'Nieob. nieuspr. niepłatna'),
                ('other_absence', 'Pozost. nieobecn.'),
            ]:
                v = c.get(field, {})
                if v.get('configured'):
                    row += [float(v['sap']), float(v['calendar']), float(v['difference'])]
                else:
                    row += ['BRAK MAPOWANIA', '', '']
            ws_cmp.append(row)
        ws_cmp.append([])
        ws_cmp.append(['Legenda', 'Różnica = Kalendarz − SAP. 0,00 = zgodność.'])

    ws_notes = wb.create_sheet('Jakość-BHP-Uwagi')
    ws_notes.append(['Nr osobowy', 'Nazwisko', 'Imię', 'Jakość', 'BHP', 'Uwagi'])
    for n in sorted(notes.values(), key=lambda x: (x.employee.last_name, x.employee.first_name)):
        ws_notes.append([n.employee.personnel_no, n.employee.last_name, n.employee.first_name, n.quality, n.bhp, n.notes])

    # Metadane zamkniętego miesiąca — snapshot parametrów eksportu.
    ws_info = wb.create_sheet('Informacje')
    ws_info.append(['Parametr', 'Wartość'])
    ws_info.append(['Dział', m.department.name])
    ws_info.append(['Okres', f'{m.month:02d}/{m.year}'])
    ws_info.append(['Status', m.get_status_display()])
    ws_info.append(['Premia bazowa', float(m.base_premium)])
    ws_info.append(['System ewidencji czasu', m.get_time_tracking_mode_display()])
    ws_info.append(['Godziny nocne', '22:00–06:00'])
    ws_info.append(['Data zamknięcia', m.closed_at.strftime('%d.%m.%Y %H:%M') if m.closed_at else ''])
    ws_info.append(['Suma do wypłaty', float(sum((x.payable for x in results), Decimal('0')))])

    thin = Side(style='thin', color='D9E2EC')
    for sheet in wb.worksheets:
        sheet.freeze_panes = 'A2'
        sheet.auto_filter.ref = sheet.dimensions
        for cell in sheet[1]:
            cell.font = Font(bold=True)
            cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            cell.fill = PatternFill('solid', fgColor='DCE6F1')
            cell.border = Border(bottom=thin)
        for row in sheet.iter_rows():
            for cell in row:
                cell.alignment = Alignment(vertical='top', wrap_text=True)
        for col in sheet.columns:
            max_len = max(len(str(cell.value or '')) for cell in col)
            sheet.column_dimensions[get_column_letter(col[0].column)].width = min(max(max_len + 2, 11), 32)
        sheet.row_dimensions[1].height = 32

    AuditLog.objects.create(user=r.user, month=m, action='EXPORT_XLSX', details='Eksport zamkniętego miesiąca do XLSX — układ źródłowy premii')
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    safe_dept = ''.join(ch if ch.isalnum() or ch in ' _-' else '_' for ch in m.department.name).strip().replace(' ', '_')
    response['Content-Disposition'] = f'attachment; filename="Premia_{safe_dept}_{m.month:02d}_{m.year}.xlsx"'
    wb.save(response)
    return response


@login_required
def new_month(r):
    p = pof(r)
    if p is None or p.role not in ('ADMIN', 'DEPT'):
        return HttpResponseForbidden()
    dept = p.department if p.role == 'DEPT' else None
    if p.role == 'ADMIN' and r.method == 'GET':
        return render(r, 'core/new_month.html', {'departments': Department.objects.all(), 'profile': p})
    if r.method == 'POST':
        dept = get_object_or_404(Department, pk=r.POST.get('department')) if p.role == 'ADMIN' else p.department
        y = int(r.POST['year'])
        mo = int(r.POST['month'])
        m, created = Month.objects.get_or_create(
            department=dept, year=y, month=mo,
            defaults={'base_premium': dept.base_premium, 'time_tracking_mode': dept.time_tracking_mode},
        )
        return redirect('month', pk=m.pk)
    return render(r, 'core/new_month.html', {'departments': [dept], 'profile': p})



@login_required
def employees_view(r):
    """Zarządzanie pracownikami: użytkownik działu tylko swoim działem, admin wszystkimi."""
    p = pof(r)
    if not p or p.role == Profile.ROLE_FIN:
        return HttpResponseForbidden()
    if p.role == Profile.ROLE_ADMIN:
        departments = Department.objects.all()
        dept_id = r.GET.get('department') or r.POST.get('department')
        dept = get_object_or_404(Department, pk=dept_id) if dept_id else departments.first()
    else:
        departments = Department.objects.filter(pk=p.department_id)
        dept = p.department
    if dept is None:
        return HttpResponseForbidden('Użytkownik nie ma przypisanego działu.')
    employees = Employee.objects.filter(department=dept).order_by('brigade', 'sort_order', 'last_name', 'first_name', 'id')
    brigade_filter = r.GET.get('brigade', '').strip()
    if brigade_filter:
        try:
            employees = employees.filter(brigade=int(brigade_filter))
        except ValueError:
            brigade_filter = ''
    active_all = Employee.objects.filter(department=dept, active=True)
    brigades = sorted(set(active_all.values_list('brigade', flat=True)))
    brigade_counts = {b: active_all.filter(brigade=b).count() for b in brigades}
    return render(r, 'core/employees.html', {
        'profile': p, 'departments': departments, 'department': dept,
        'employees': employees,
        'active_count': active_all.count(),
        'brigade_counts': brigade_counts,
        'brigades': brigades, 'brigade_filter': brigade_filter,
    })


@login_required
def employee_add(r):
    p = pof(r)
    if not p or p.role == Profile.ROLE_FIN:
        return HttpResponseForbidden()
    if p.role == Profile.ROLE_ADMIN:
        dept = get_object_or_404(Department, pk=r.POST.get('department') or r.GET.get('department'))
    else:
        dept = p.department
    if dept is None:
        return HttpResponseForbidden('Użytkownik nie ma przypisanego działu.')
    if r.method == 'POST':
        personnel_no = r.POST.get('personnel_no', '').strip()
        first_name = r.POST.get('first_name', '').strip()
        last_name = r.POST.get('last_name', '').strip()
        premium_mode = r.POST.get('premium_mode', Employee.PREMIUM_STANDARD)
        if premium_mode not in dict(Employee.PREMIUM_MODES):
            premium_mode = Employee.PREMIUM_STANDARD
        try:
            brigade = max(1, int(r.POST.get('brigade', '1')))
        except (TypeError, ValueError):
            brigade = 1
        if not personnel_no or not first_name or not last_name:
            return render(r, 'core/employee_form.html', {'profile': p, 'department': dept, 'error': 'Numer osobowy, imię i nazwisko są wymagane.', 'brigade': brigade})
        if Employee.objects.filter(department=dept, personnel_no=personnel_no).exists():
            return render(r, 'core/employee_form.html', {'profile': p, 'department': dept, 'error': 'Pracownik o takim numerze osobowym już istnieje w tym dziale.', 'brigade': brigade})
        active_qs = list(Employee.objects.filter(department=dept, active=True, brigade=brigade).order_by('brigade', 'sort_order', 'last_name', 'first_name', 'id'))
        try:
            position = int(r.POST.get('position', str(len(active_qs) + 1)))
        except (TypeError, ValueError):
            position = len(active_qs) + 1
        position = max(1, min(position, len(active_qs) + 1))
        emp = Employee.objects.create(department=dept, personnel_no=personnel_no, first_name=first_name, last_name=last_name, brigade=brigade, premium_mode=premium_mode, sort_order=0)
        active_qs.insert(position - 1, emp)
        for pos, item in enumerate(active_qs, start=1):
            item.sort_order = pos
        Employee.objects.bulk_update(active_qs, ['sort_order'])
        AuditLog.objects.create(user=r.user, action='ADD_EMPLOYEE', details=f'Dział: {dept.name}; Brygada: {brigade}; Nr: {personnel_no}; Pracownik: {last_name} {first_name}; pozycja: {position}')
        return redirect(f'/employees/?department={dept.id}')
    active_count = Employee.objects.filter(department=dept, active=True, brigade=1).count()
    return render(r, 'core/employee_form.html', {'profile': p, 'department': dept, 'active_count': active_count, 'brigade': 1})


@login_required
def employee_edit(r, pk):
    p = pof(r)
    if not p or p.role == Profile.ROLE_FIN:
        return HttpResponseForbidden()
    emp = get_object_or_404(Employee.objects.select_related('department'), pk=pk)
    if p.role != Profile.ROLE_ADMIN and emp.department_id != p.department_id:
        return HttpResponseForbidden()
    if r.method == 'POST':
        personnel_no = r.POST.get('personnel_no', '').strip()
        first_name = r.POST.get('first_name', '').strip()
        last_name = r.POST.get('last_name', '').strip()
        premium_mode = r.POST.get('premium_mode', Employee.PREMIUM_STANDARD)
        if premium_mode not in dict(Employee.PREMIUM_MODES):
            premium_mode = Employee.PREMIUM_STANDARD
        try:
            new_brigade = max(1, int(r.POST.get('brigade', str(emp.brigade))))
        except (TypeError, ValueError):
            new_brigade = emp.brigade
        if not personnel_no or not first_name or not last_name:
            return render(r, 'core/employee_form.html', {'profile': p, 'department': emp.department, 'employee': emp, 'error': 'Numer osobowy, imię i nazwisko są wymagane.'})
        if Employee.objects.filter(department=emp.department, personnel_no=personnel_no).exclude(pk=emp.pk).exists():
            return render(r, 'core/employee_form.html', {'profile': p, 'department': emp.department, 'employee': emp, 'error': 'Pracownik o takim numerze osobowym już istnieje w tym dziale.'})
        old_brigade = emp.brigade
        emp.personnel_no, emp.first_name, emp.last_name, emp.premium_mode, emp.brigade = personnel_no, first_name, last_name, premium_mode, new_brigade
        emp.save(update_fields=['personnel_no', 'first_name', 'last_name', 'premium_mode', 'brigade'])
        # Po zmianie brygady utrzymuj ciągłą pozycję w obu grupach.
        for brigade in {old_brigade, new_brigade}:
            group = list(Employee.objects.filter(department=emp.department, active=True, brigade=brigade).order_by('sort_order', 'last_name', 'first_name', 'id'))
            for pos, item in enumerate(group, start=1):
                item.sort_order = pos
            Employee.objects.bulk_update(group, ['sort_order'])
        AuditLog.objects.create(user=r.user, action='EDIT_EMPLOYEE', details=f'Pracownik ID {emp.id}; Brygada: {old_brigade} -> {new_brigade}; Nr: {personnel_no}; {last_name} {first_name}')
        return redirect(f'/employees/?department={emp.department_id}')
    return render(r, 'core/employee_form.html', {'profile': p, 'department': emp.department, 'employee': emp, 'active_count': Employee.objects.filter(department=emp.department, active=True, brigade=emp.brigade).count()})


@login_required
def employee_toggle(r, pk):
    p = pof(r)
    if not p or p.role == Profile.ROLE_FIN or r.method != 'POST':
        return HttpResponseForbidden()
    emp = get_object_or_404(Employee.objects.select_related('department'), pk=pk)
    if p.role != Profile.ROLE_ADMIN and emp.department_id != p.department_id:
        return HttpResponseForbidden()
    emp.active = not emp.active
    emp.save(update_fields=['active'])
    AuditLog.objects.create(user=r.user, action='ACTIVATE_EMPLOYEE' if emp.active else 'DEACTIVATE_EMPLOYEE', details=f'Pracownik ID {emp.id}; {emp}')
    return redirect(f'/employees/?department={emp.department_id}')


@login_required
def employee_move(r, pk, direction):
    p = pof(r)
    if not p or p.role == Profile.ROLE_FIN or r.method != 'POST':
        return HttpResponseForbidden()
    emp = get_object_or_404(Employee, pk=pk)
    if p.role != Profile.ROLE_ADMIN and emp.department_id != p.department_id:
        return HttpResponseForbidden()
    qs = list(Employee.objects.filter(department=emp.department, active=True, brigade=emp.brigade).order_by('sort_order', 'last_name', 'first_name', 'id'))
    try:
        i = [x.id for x in qs].index(emp.id)
    except ValueError:
        return redirect(f'/employees/?department={emp.department_id}')
    j = i - 1 if direction == 'up' else i + 1
    if j < 0 or j >= len(qs):
        return redirect(f'/employees/?department={emp.department_id}')
    qs[i].sort_order, qs[j].sort_order = qs[j].sort_order, qs[i].sort_order
    Employee.objects.bulk_update([qs[i], qs[j]], ['sort_order'])
    ordered = list(Employee.objects.filter(department=emp.department, active=True, brigade=emp.brigade).order_by('sort_order', 'last_name', 'first_name', 'id'))
    for pos, item in enumerate(ordered, start=1):
        item.sort_order = pos
    Employee.objects.bulk_update(ordered, ['sort_order'])
    AuditLog.objects.create(user=r.user, action='SORT_EMPLOYEES', details=f'Dział: {emp.department.name}; Brygada: {emp.brigade}; {emp}; kierunek: {direction}')
    return redirect(f'/employees/?department={emp.department_id}')

@login_required
def employee_move_to(r, pk):
    p = pof(r)
    if not p or p.role == Profile.ROLE_FIN or r.method != 'POST':
        return HttpResponseForbidden()
    emp = get_object_or_404(Employee.objects.select_related('department'), pk=pk)
    if p.role != Profile.ROLE_ADMIN and emp.department_id != p.department_id:
        return HttpResponseForbidden()
    try:
        target = int(r.POST.get('position', ''))
    except (TypeError, ValueError):
        return redirect(f'/employees/?department={emp.department_id}')
    qs = list(Employee.objects.filter(department=emp.department, active=True, brigade=emp.brigade).order_by('sort_order', 'last_name', 'first_name', 'id'))
    if emp not in qs:
        return redirect(f'/employees/?department={emp.department_id}')
    target = max(1, min(target, len(qs)))
    current = qs.index(emp) + 1
    if current != target:
        item = qs.pop(current - 1)
        qs.insert(target - 1, item)
        for pos, obj in enumerate(qs, start=1):
            obj.sort_order = pos
        Employee.objects.bulk_update(qs, ['sort_order'])
        AuditLog.objects.create(user=r.user, action='SORT_EMPLOYEES', details=f'Dział: {emp.department.name}; Brygada: {emp.brigade}; {emp}; pozycja: {current} -> {target}')
    return redirect(f'/employees/?department={emp.department_id}')


@login_required
def month_detail(r, pk):
    m = get_object_or_404(Month.objects.select_related('department'), pk=pk)
    if not allowed(r, m):
        return HttpResponseForbidden()
    results = PremiumResult.objects.filter(month=m).select_related('employee').order_by('employee__brigade', 'employee__sort_order', 'employee__last_name', 'employee__first_name')
    employees = Employee.objects.filter(department=m.department, active=True).order_by('brigade', 'sort_order', 'last_name', 'first_name', 'id')
    notes = {n.employee_id: n for n in EmployeeNote.objects.filter(month=m)}
    sap_records = {x.personnel_no: x for x in SAPRecord.objects.filter(month=m)} if m.department.use_sap else {}
    results_map = {x.employee_id: x for x in results}
    total = sum((x.payable for x in results), Decimal('0'))
    sap_comparison, sap_comparison_configured = calendar_sap_comparison(m) if m.department.use_sap else ({}, {})
    return render(r, 'core/month.html', {
        'm': m, 'results': results, 'employees': employees, 'notes': notes,
        'sap_records': sap_records, 'results_map': results_map, 'total': total, 'profile': pof(r),
        'sap_comparison': sap_comparison, 'sap_comparison_configured': sap_comparison_configured,
        'has_premium_results': results.exists() and m.status in (Month.CALC, Month.CLOSED),
    })


@login_required
def update_base_premium(r, pk):
    m = get_object_or_404(Month.objects.select_related('department'), pk=pk)
    if not allowed(r, m, True) or r.method != 'POST' or m.status == 'CLOSED':
        return HttpResponseForbidden()
    try:
        value = Decimal(str(r.POST.get('base_premium', '')).replace(',', '.'))
        if value < 0 or value > Decimal('99999999.99'):
            raise ValueError
    except (ValueError, TypeError, ArithmeticError):
        return redirect('month', pk=m.pk)
    old = m.base_premium
    m.base_premium = value.quantize(Decimal('0.01'))
    m.save(update_fields=['base_premium'])
    # Ustawienie działu jest domyślną premią dla kolejnych nowych miesięcy.
    m.department.base_premium = m.base_premium
    m.department.save(update_fields=['base_premium'])
    if m.status == Month.CALC or m.status == Month.REOPENED:
        m.status = Month.OPEN
        m.save(update_fields=['status'])
    AuditLog.objects.create(
        user=r.user, month=m, action='UPDATE_BASE_PREMIUM',
        details=f'Premia bazowa: {old} zł -> {m.base_premium} zł; Dział: {m.department.name}'
    )
    return redirect('month', pk=m.pk)


@login_required
def import_sap(r, pk):
    m = get_object_or_404(Month, pk=pk)
    p = pof(r)
    if not p or not allowed(r, m, True) or p.role == 'FIN' or m.status == 'CLOSED' or not m.department.use_sap:
        return HttpResponseForbidden()
    if r.method == 'POST' and 'file' in r.FILES:
        ws = load_workbook(r.FILES['file'], data_only=True, read_only=True).active
        headers = list(next(ws.iter_rows(values_only=True)))
        idx = {str(v).strip(): i for i, v in enumerate(headers) if v is not None}
        required = {'Numer osobowy', 'Nadgodz/Godz.ujem.', 'Urlop wypoczynkowy', 'choroba zwykła', 'Nieob. nieuspr. niepłatna', 'Pozost. nieobecn.'}
        missing = sorted(required - set(idx))
        if missing:
            messages.error(r, 'Import SAP przerwany. Brak kolumn: ' + ', '.join(missing))
            return redirect('import_sap', pk=pk)

        # Import nigdy nie tworzy pracowników. SAP może uzupełnić wyłącznie osoby
        # istniejące w bazie i przypisane do działu tego miesiąca.
        employees_by_no = {str(e.personnel_no).strip(): e for e in Employee.objects.filter(department=m.department)}
        SAPRecord.objects.filter(month=m).delete()

        def val(row, name, default=''):
            i = idx.get(name)
            return row[i] if i is not None and i < len(row) else default

        def personnel_key(raw):
            if raw in (None, ''):
                return ''
            if isinstance(raw, Decimal) and raw == raw.to_integral_value():
                return str(int(raw))
            if isinstance(raw, float) and raw.is_integer():
                return str(int(raw))
            text = str(raw).strip()
            if text.endswith('.0') and text[:-2].isdigit():
                return text[:-2]
            return text

        def dec(row, name):
            raw = val(row, name, 0)
            if raw in (None, ''):
                return Decimal('0')
            try:
                text = str(raw).strip().replace(',', '.')
                if text.endswith('%'):
                    text = text[:-1].strip()
                return Decimal(text)
            except Exception:
                return Decimal('0')

        def as_date(raw):
            if raw in (None, ''):
                return None
            if isinstance(raw, datetime):
                return raw.date()
            if isinstance(raw, date):
                return raw
            for fmt in ('%d.%m.%Y', '%Y-%m-%d', '%d/%m/%Y'):
                try:
                    return date.fromisoformat(str(raw)) if fmt == '%Y-%m-%d' else datetime.strptime(str(raw), fmt).date()
                except Exception:
                    pass
            return None

        imported = 0
        skipped = 0
        for row in ws.iter_rows(values_only=True):
            no = personnel_key(val(row, 'Numer osobowy', None))
            if not no:
                continue
            emp = employees_by_no.get(no)
            if emp is None:
                skipped += 1
                continue
            first = str(val(row, 'Imię', '') or '')
            last = str(val(row, 'Nazwisko', '') or '')
            SAPRecord.objects.create(
                month=m, report_called=str(val(row, 'Raport wywołano', '') or ''),
                settlement_period=str(val(row, 'Okres rozliczeniowy', '') or ''),
                plant=str(val(row, 'Zakład', '') or ''), personnel_no=no,
                first_name=first or emp.first_name, last_name=last or emp.last_name,
                employment_date=as_date(val(row, 'Data zatrudnienia', None)),
                subgroup=str(val(row, 'Podgrupa pracowników', '') or ''),
                epc=str(val(row, 'EPC', '') or ''),
                efficiency=dec(row, 'Efektywność w %'), gk=dec(row, 'GK'),
                overtime=dec(row, 'Nadgodz/Godz.ujem.'),
                vacation=dec(row, 'Urlop wypoczynkowy'), sick=dec(row, 'choroba zwykła'),
                unpaid_absence=dec(row, 'Nieob. nieuspr. niepłatna'),
                other_absence=dec(row, 'Pozost. nieobecn.'),
            )
            imported += 1

        if m.status == Month.CALC or m.status == Month.REOPENED:
            m.status = Month.OPEN
            m.save(update_fields=['status'])
        AuditLog.objects.create(
            user=r.user, month=m, action='IMPORT_SAP',
            details=f'Import XLSX. Uzupełniono: {imported}. Pominięto numery nieprzypisane do działu: {skipped}.',
        )
        messages.success(r, f'Import SAP zakończony. Uzupełniono {imported} pracowników; pominięto {skipped} numerów spoza działu.')
        return redirect('month', pk=pk)
    return render(r, 'core/import.html', {'m': m})


@login_required
def calendar_view(r, pk):
    m = get_object_or_404(Month.objects.select_related('department'), pk=pk)
    if not allowed(r, m):
        return HttpResponseForbidden()
    employees = Employee.objects.filter(department=m.department, active=True).order_by('brigade', 'sort_order', 'last_name', 'first_name', 'id')
    days = sync_calendar_days(m.year, m.month)
    codes = AbsenceCode.objects.filter(active=True).order_by('sort_order', 'code')
    entries = {}
    for ce in CalendarEntry.objects.filter(month=m).select_related('code'):
        entries.setdefault(ce.employee_id, {})[ce.day.day] = ce
    rebuild_overtime_balances(m.department)
    balances = {x.employee_id: x for x in OvertimeBalance.objects.filter(month=m)}
    rows = month_time_rows(m)
    calendar_summary = {}
    for e in employees:
        row = rows.get(e.id, {})
        bal = balances.get(e.id)
        calendar_summary[e.id] = {
            **row,
            'carried_in': bal.carried_in if bal else Decimal('0'),
            'overtime_leave_hours': bal.overtime_leave_hours if bal else row.get('overtime_leave_hours', Decimal('0')),
            'carried_out': bal.carried_out if bal else row.get('overtime', Decimal('0')),
        }
    p = pof(r)
    return render(r, 'core/calendar.html', {
        'm': m, 'employees': employees, 'days': days, 'codes': codes, 'entries': entries,
        'calendar_summary': calendar_summary,
        'week_numbers': sorted({d['date'].isocalendar().week for d in days}),
        'brigades': sorted(set(employees.values_list('brigade', flat=True))),
        'can_edit': p and p.role != 'FIN' and m.status != 'CLOSED', 'profile': p,
        'time_modes': Department.TIME_TRACKING_CHOICES,
    })

@login_required
def calendar_fill_8h(r, pk):
    """Masowe uzupełnianie pustych dni wybranych pracowników i dni tygodnia."""
    m = get_object_or_404(Month.objects.select_related('department'), pk=pk)
    p = pof(r)
    if not p or not allowed(r, m, True) or p.role == 'FIN' or m.status == 'CLOSED' or r.method != 'POST':
        return HttpResponseForbidden()

    employees_qs = Employee.objects.filter(department=m.department, active=True).order_by(
        'brigade', 'sort_order', 'last_name', 'first_name', 'id'
    )
    employee_ids = r.POST.getlist('employee_ids')
    brigade_ids = r.POST.getlist('brigade_ids')
    try:
        selected_ids = {int(x) for x in employee_ids}
    except ValueError:
        selected_ids = set()
    try:
        selected_brigades = {int(x) for x in brigade_ids if int(x) >= 1}
    except ValueError:
        selected_brigades = set()
    if selected_brigades:
        selected_ids |= set(employees_qs.filter(brigade__in=selected_brigades).values_list('id', flat=True))
    employees = employees_qs.filter(id__in=selected_ids) if selected_ids else employees_qs

    weekdays_raw = r.POST.getlist('weekdays')
    weeks_raw = r.POST.getlist('weeks')
    try:
        weekdays = {int(x) for x in weekdays_raw if 0 <= int(x) <= 6}
    except ValueError:
        weekdays = set()
    if not weekdays:
        return redirect('calendar', pk=pk)
    try:
        weeks = {int(x) for x in weeks_raw if 1 <= int(x) <= 53}
    except ValueError:
        weeks = set()

    start_raw = r.POST.get('fill_start', '08:00').strip()
    end_raw = r.POST.get('fill_end', '16:00').strip()
    try:
        start_time = datetime.strptime(start_raw, '%H:%M').time()
        end_time = datetime.strptime(end_raw, '%H:%M').time()
    except ValueError:
        messages.error(r, 'Nieprawidłowe godziny. Użyj formatu HH:MM.')
        return redirect('calendar', pk=pk)

    # Oblicz długość zmiany, także gdy przechodzi przez północ.
    start_minutes = start_time.hour * 60 + start_time.minute
    end_minutes = end_time.hour * 60 + end_time.minute
    duration_minutes = end_minutes - start_minutes
    if duration_minutes <= 0:
        duration_minutes += 24 * 60
    if duration_minutes <= 0 or duration_minutes > 24 * 60:
        messages.error(r, 'Nieprawidłowy zakres godzin.')
        return redirect('calendar', pk=pk)
    duration = (Decimal(duration_minutes) / Decimal(60)).quantize(Decimal('0.01'))

    days = sync_calendar_days(m.year, m.month)
    selected_dates = [
        d['date'] for d in days
        if d['is_working']
        and d['date'].weekday() in weekdays
        and (not weeks or d['date'].isocalendar().week in weeks)
    ]
    existing = set(
        CalendarEntry.objects.filter(
            month=m, employee__in=employees, day__in=selected_dates
        ).values_list('employee_id', 'day')
    )

    created = 0
    for emp in employees:
        for day in selected_dates:
            if (emp.id, day) in existing:
                continue
            if m.time_tracking_mode == Department.TIME_CLOCK:
                CalendarEntry.objects.create(
                    month=m, employee=emp, day=day,
                    start_time=start_time, end_time=end_time
                )
            else:
                CalendarEntry.objects.create(
                    month=m, employee=emp, day=day, hours=duration
                )
            created += 1

    rebuild_overtime_balances(m.department)
    if m.status in (Month.CALC, Month.REOPENED):
        m.status = Month.OPEN
        m.save(update_fields=['status'])
    AuditLog.objects.create(
        user=r.user, month=m, action='FILL_8H',
        details=(
            f'Masowe uzupełnienie pustych dni roboczych: {start_raw}–{end_raw}; '
            f'dni tygodnia={sorted(weekdays)}; tygodnie={sorted(weeks) if weeks else "wszystkie"}; brygady={sorted(selected_brigades) if selected_brigades else "brak"}; pracowników={employees.count()}; nowych wpisów={created}; '
            f'tryb={m.get_time_tracking_mode_display()}'
        )
    )
    messages.success(r, f'Uzupełniono {created} pustych dni dla {employees.count()} pracowników.')
    return redirect('calendar', pk=pk)

@login_required
def calendar_save(r, pk):
    m = get_object_or_404(Month, pk=pk)
    p = pof(r)
    if not p or not allowed(r, m, True) or p.role == 'FIN' or m.status == 'CLOSED':
        return HttpResponseForbidden()
    if r.method != 'POST':
        return redirect('calendar', pk=pk)
    employee_ids = set(); cell_keys = set()
    for key in r.POST.keys():
        if key.startswith(('h_', 'c_', 's_', 'e_', 'l_')):
            parts = key.split('_')
            if len(parts) == 3 and parts[1].isdigit() and parts[2].isdigit():
                employee_ids.add(int(parts[1])); cell_keys.add((int(parts[1]), int(parts[2])))
    employees = {e.id: e for e in Employee.objects.filter(department=m.department, active=True, id__in=employee_ids)}
    max_day = calendar.monthrange(m.year, m.month)[1]
    for eid, day_no in sorted(cell_keys):
        if eid not in employees or not (1 <= day_no <= max_day): continue
        emp = employees[eid]; d = date(m.year, m.month, day_no)
        cval = r.POST.get(f'c_{eid}_{day_no}', '').strip()
        lval = r.POST.get(f'l_{eid}_{day_no}', '').strip()
        if m.time_tracking_mode == Department.TIME_CLOCK:
            sval = r.POST.get(f's_{eid}_{day_no}', '').strip(); eval = r.POST.get(f'e_{eid}_{day_no}', '').strip()
            defaults = {'start_time': None, 'end_time': None, 'hours': None, 'code': None, 'overtime_leave_hours': None}
            if cval:
                code = get_object_or_404(AbsenceCode, code=cval, active=True)
                defaults['code'] = code
            elif sval or eval:
                try:
                    if not sval or not eval: raise ValueError
                    defaults['start_time'] = datetime.strptime(sval, '%H:%M').time()
                    defaults['end_time'] = datetime.strptime(eval, '%H:%M').time()
                except ValueError:
                    continue
            try:
                if lval: defaults['overtime_leave_hours'] = Decimal(lval.replace(',', '.'))
            except Exception:
                continue
            if defaults['code'] is None and defaults['start_time'] is None and defaults['overtime_leave_hours'] is None:
                CalendarEntry.objects.filter(month=m, employee=emp, day=d).delete()
            else:
                CalendarEntry.objects.update_or_create(month=m, employee=emp, day=d, defaults=defaults)
        else:
            hval = r.POST.get(f'h_{eid}_{day_no}', '').strip()
            defaults = {'hours': None, 'code': None, 'overtime_leave_hours': None, 'start_time': None, 'end_time': None}
            if cval:
                code = get_object_or_404(AbsenceCode, code=cval, active=True); defaults['code'] = code
            elif hval:
                try: defaults['hours'] = Decimal(hval.replace(',', '.'))
                except Exception: continue
            if lval:
                try: defaults['overtime_leave_hours'] = Decimal(lval.replace(',', '.'))
                except Exception: continue
            if defaults['code'] is None and defaults['hours'] is None and defaults['overtime_leave_hours'] is None:
                CalendarEntry.objects.filter(month=m, employee=emp, day=d).delete()
            else:
                CalendarEntry.objects.update_or_create(month=m, employee=emp, day=d, defaults=defaults)
    if cell_keys:
        rebuild_overtime_balances(m.department)
        if m.status in (Month.CALC, Month.REOPENED): m.status = Month.OPEN; m.save(update_fields=['status'])
        AuditLog.objects.create(user=r.user, month=m, action='SAVE_CALENDAR', details=f'Zapisano {len(cell_keys)} zmienionych komórek.')
    return redirect('calendar', pk=pk)

@login_required
def update_time_tracking_mode(r, pk):
    m = get_object_or_404(Month.objects.select_related('department'), pk=pk)
    p = pof(r)
    if not p or p.role != Profile.ROLE_ADMIN or m.status == Month.CLOSED or r.method != 'POST':
        return HttpResponseForbidden()
    mode = r.POST.get('time_tracking_mode')
    if mode not in dict(Department.TIME_TRACKING_CHOICES):
        return redirect('month', pk=pk)
    old = m.time_tracking_mode; m.time_tracking_mode = mode; m.save(update_fields=['time_tracking_mode'])
    AuditLog.objects.create(user=r.user, month=m, action='CHANGE_TIME_TRACKING_MODE', details=f'{old} -> {mode}')
    return redirect('month', pk=pk)

@login_required
def notes_save(r, pk):
    m = get_object_or_404(Month, pk=pk)
    p = pof(r)
    if not p or not allowed(r, m, True) or p.role == 'FIN' or m.status == 'CLOSED':
        return HttpResponseForbidden()
    if r.method == 'POST':
        for e in Employee.objects.filter(department=m.department, active=True):
            EmployeeNote.objects.update_or_create(
                month=m,
                employee=e,
                defaults={
                    'quality': r.POST.get(f'quality_{e.id}', ''),
                    'bhp': r.POST.get(f'bhp_{e.id}', ''),
                    'notes': r.POST.get(f'notes_{e.id}', ''),
                },
            )
        if m.status == Month.CALC or m.status == Month.REOPENED:
            m.status = Month.OPEN
            m.save(update_fields=['status'])
        AuditLog.objects.create(user=r.user, month=m, action='SAVE_NOTES')
        return redirect('month', pk=pk)
    return redirect('month', pk=pk)


@login_required
def calculate(r, pk):
    m = get_object_or_404(Month, pk=pk)
    p = pof(r)
    if not p or not allowed(r, m, True) or p.role == 'FIN' or m.status == 'CLOSED':
        return HttpResponseForbidden()
    calculate_month(m)
    AuditLog.objects.create(user=r.user, month=m, action='CALCULATE')
    return redirect('month', pk=pk)


@login_required
def close_month(r, pk):
    m = get_object_or_404(Month, pk=pk)
    p = pof(r)
    if not p or not allowed(r, m, True) or p.role == 'FIN' or m.status == 'CLOSED':
        return HttpResponseForbidden()
    if r.method == 'POST':
        m.status = Month.CLOSED
        m.closed_at = timezone.now()
        m.save()
        AuditLog.objects.create(user=r.user, month=m, action='CLOSE')
        return redirect('month', pk=pk)
    return render(r, 'core/confirm.html', {'m': m, 'action': 'zamknąć miesiąc'})


@login_required
def reopen_month(r, pk):
    m = get_object_or_404(Month, pk=pk)
    p = pof(r)
    if not p or p.role != 'ADMIN':
        return HttpResponseForbidden()
    if r.method == 'POST':
        m.status = Month.REOPENED
        m.closed_at = None
        m.save()
        AuditLog.objects.create(user=r.user, month=m, action='REOPEN', details=r.POST.get('reason', ''))
        return redirect('month', pk=pk)
    return render(r, 'core/confirm.html', {'m': m, 'action': 'odblokować miesiąc', 'reopen': True})
