from django.contrib import admin
from .models import (
    Month, Employee, SAPRecord, CalendarEntry, OvertimeBalance,
    EmployeeNote, PremiumResult, AuditLog,
)


@admin.register(Month)
class MonthAdmin(admin.ModelAdmin):
    list_display = ('department', 'year', 'month', 'status', 'base_premium', 'time_tracking_mode', 'created_at', 'closed_at')
    list_filter = ('status', 'department', 'year')
    search_fields = ('department__name',)


@admin.register(Employee)
class EmployeeAdmin(admin.ModelAdmin):
    list_display = ('personnel_no', 'last_name', 'first_name', 'department', 'brigade', 'premium_mode', 'active')
    list_filter = ('department', 'brigade', 'premium_mode', 'active')
    search_fields = ('personnel_no', 'last_name', 'first_name')
    list_editable = ('brigade',)
    ordering = ('department', 'brigade', 'sort_order', 'last_name', 'first_name')


@admin.register(SAPRecord)
class SAPRecordAdmin(admin.ModelAdmin):
    list_display = ('month', 'personnel_no', 'last_name', 'first_name', 'subgroup', 'epc', 'efficiency', 'gk', 'overtime')
    list_filter = ('month', 'subgroup', 'epc')
    search_fields = ('personnel_no', 'last_name', 'first_name')


@admin.register(CalendarEntry)
class CalendarEntryAdmin(admin.ModelAdmin):
    list_display = ('month', 'employee', 'day', 'hours', 'start_time', 'end_time', 'overtime_leave_hours', 'code')
    list_filter = ('month', 'code')
    search_fields = ('employee__personnel_no', 'employee__last_name')
    date_hierarchy = 'day'


@admin.register(OvertimeBalance)
class OvertimeBalanceAdmin(admin.ModelAdmin):
    list_display = ('month', 'employee', 'carried_in', 'worked_hours', 'planned_hours', 'overtime', 'night_hours', 'overtime_leave_hours', 'carried_out')
    list_filter = ('month',)
    search_fields = ('employee__personnel_no', 'employee__last_name')


@admin.register(EmployeeNote)
class EmployeeNoteAdmin(admin.ModelAdmin):
    list_display = ('month', 'employee')
    list_filter = ('month',)
    search_fields = ('employee__personnel_no', 'employee__last_name')


@admin.register(PremiumResult)
class PremiumResultAdmin(admin.ModelAdmin):
    list_display = ('month', 'employee', 'granted', 'deduction_working', 'deduction_calendar', 'payable')
    list_filter = ('month',)
    search_fields = ('employee__personnel_no', 'employee__last_name')


@admin.register(AuditLog)
class AuditLogAdmin(admin.ModelAdmin):
    list_display = ('created_at', 'user', 'month', 'action', 'details')
    list_filter = ('action', 'created_at')
    search_fields = ('user__username', 'action', 'details')
    readonly_fields = ('created_at',)
