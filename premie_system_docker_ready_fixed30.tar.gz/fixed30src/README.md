# Premie — fixed30

Poprawka startu kontenera względem fixed29.

Naprawiono import `Workbook` w `core/views.py`: `Workbook` jest importowany z `openpyxl`, a nie z `openpyxl.utils`. Poprzedni błędny import powodował `ImportError` i restartowanie kontenera web.

Po wdrożeniu nie jest wymagana migracja bazy. Należy przebudować i odtworzyć kontener `web`.
