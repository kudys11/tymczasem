# System Premii — fixed31

Wersja zawiera:
- logo POLIPOL na stronach aplikacji i w Django Admin,
- logo wyśrodkowane na górnym pasku aplikacji,
- branding/logo w górnym pasku Django Admin oraz na logowaniu administracyjnym,
- dotychczasowe funkcje z fixed30.

## Pierwsze uruchomienie na nowym serwerze

1. Zainstaluj Docker Engine i Docker Compose.
2. Utwórz katalog aplikacji, np. `/opt/premie`.
3. Rozpakuj archiwum i przejdź do katalogu zawierającego `docker-compose.yml`.
4. Przed uruchomieniem zmień `DJANGO_SECRET_KEY` na losowy, długi klucz oraz ustaw `DJANGO_DEBUG: "0"`.
5. Jeżeli używana jest domena `premie.pikur.eu`, pozostaw `CSRF_TRUSTED_ORIGINS: "https://premie.pikur.eu"`.
6. Uruchom `docker compose up -d --build`.
7. Sprawdź `docker compose ps` oraz `docker compose logs -f web`.
8. Utwórz pierwszego administratora: `docker compose exec web python manage.py createsuperuser`.
9. Wejdź na `/admin/` i skonfiguruj dział, kody nieobecności, święta, pracowników i pozostałe dane.

## Dane PostgreSQL

Dane są przechowywane w wolumenie Docker `premie_db`. Przy zwykłej aktualizacji nie używać `docker compose down -v`, ponieważ usuwa to wolumen bazy.

## Aktualizacja

Po podmianie kodu:

```bash
docker compose build web
docker compose up -d --force-recreate web
```

Migracje Django są wykonywane automatycznie przez `entrypoint.sh`.
