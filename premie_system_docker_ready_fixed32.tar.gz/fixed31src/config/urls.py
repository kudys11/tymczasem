from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static
from django.urls import path, include

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", include("core.urls")),
]

# Aplikacja działa na Django runserver również przy DEBUG=0.
# Udostępniamy zebrane pliki statyczne, aby logo i CSS były dostępne
# bez dodatkowego serwera statycznego/reverse proxy.
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
