# System Premii — fixed31

Wersja zawiera:
- logo POLIPOL na stronach aplikacji i w Django Admin,
- logo wyśrodkowane na górnym pasku aplikacji,
- branding/logo w górnym pasku Django Admin oraz na logowaniu administracyjnym,
- dotychczasowe funkcje z fixed30.

## Pierwsze uruchomienie na nowym serwerze

1. Zainstaluj Docker Engine i Docker Compose.
2. Utwórz katalog aplikacji, np. `/opt/premie`.
3. Rozpakuj archiwum i przejdź do katalogu zawierającego `docker-compose.yml`.
4. Przed uruchomieniem zmień `DJANGO_SECRET_KEY` na losowy, długi klucz oraz ustaw `DJANGO_DEBUG: "0"`.
5. `CSRF_TRUSTED_ORIGINS` pozostaw puste, jeśli użytkownicy korzystają z tej samej domeny/IP, pod którym otwierają aplikację. Możesz opcjonalnie podać kilka originów oddzielonych przecinkami, jeśli aplikacja jest osadzana/proxyowana pod dodatkowymi adresami.
6. Uruchom `docker compose up -d --build`.
7. Sprawdź `docker compose ps` oraz `docker compose logs -f web`.
8. Utwórz pierwszego administratora: `docker compose exec web python manage.py createsuperuser`.
9. Wejdź na `/admin/` i skonfiguruj dział, kody nieobecności, święta, pracowników i pozostałe dane.

## Dane PostgreSQL

Dane są przechowywane w wolumenie Docker `premie_db`. Przy zwykłej aktualizacji nie używać `docker compose down -v`, ponieważ usuwa to wolumen bazy.

## Aktualizacja

Po podmianie kodu:

```bash
docker compose build web
docker compose up -d --force-recreate web
```

Migracje Django są wykonywane automatycznie przez `entrypoint.sh`.


## Dostęp przez IP, domenę, HTTP i HTTPS
Aplikacja nie jest przywiązana do konkretnej domeny ani protokołu. `ALLOWED_HOSTS` jest ustawione tak, aby aplikacja mogła działać pod adresem IP lub nazwą DNS. `CSRF_TRUSTED_ORIGINS` jest domyślnie puste i może zostać ustawione tylko wtedy, gdy potrzebne są dodatkowe zaufane originy. Brak ustawienia wymusza zwykłą ochronę CSRF dla bieżącego hosta, zamiast wiązać instalację z jedną domeną.

Przykładowe adresy użytkownika mogą być:
- `http://192.168.1.50:8001`
- `http://premie.local:8001`
- `https://192.168.1.50/` (przez reverse proxy)
- `https://premie.example.pl/` (przez reverse proxy)

W przypadku reverse proxy należy zachować nagłówek `X-Forwarded-Proto`, ponieważ Django używa go do rozpoznania HTTPS.
