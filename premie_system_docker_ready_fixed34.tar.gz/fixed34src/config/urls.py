from django.contrib import admin
from django.conf import settings
from django.urls import path, include
from django.views.static import serve as static_serve

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", include("core.urls")),
]

# Wdrożenie korzysta z Django runserver również przy DEBUG=0.
# django.conf.urls.static.static() jest aktywne tylko przy DEBUG=True,
# dlatego statyczne pliki udostępniamy jawnie. Dzięki temu logo i CSS
# działają także w produkcyjnej konfiguracji DEBUG=0.
urlpatterns += [
    path("static/<path:path>", static_serve, {"document_root": settings.STATIC_ROOT}),
]
