from django.contrib import admin
from django import forms
from types import MethodType
from .models import *

admin.site.site_header = 'System Premii — Administracja'
admin.site.site_title = 'System Premii'
admin.site.index_title = 'Panel administracyjny'

# Modele operacyjne są prezentowane wyłącznie w osobnej grupie
# „Dane operacyjne” (aplikacja proxy `operations`).
# Usuwamy ewentualne stare rejestracje modeli z `core`, aby administracja
# nie generowała linków typu /admin/core/employee/ prowadzących do 404.
_OPERATIONAL_CORE_MODELS = (
    Month, Employee, SAPRecord, CalendarEntry, OvertimeBalance,
    EmployeeNote, PremiumResult, AuditLog, CalendarDay,
)
for _model in _OPERATIONAL_CORE_MODELS:
    try:
        admin.site.unregister(_model)
    except admin.sites.NotRegistered:
        pass


class AuthProfile(Profile):
    class Meta:
        proxy = True
        app_label = 'auth'
        verbose_name = 'Profil użytkownika'
        verbose_name_plural = 'Profile użytkowników'
        ordering = ['user__username']


@admin.register(AuthProfile)
class AuthProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'role', 'department')
    list_filter = ('role', 'department')
    search_fields = ('user__username', 'user__first_name', 'user__last_name')


def _ordered_app_list(self, request, app_label=None):
    app_list = _ORIGINAL_GET_APP_LIST(request, app_label)
    if app_label:
        return app_list
    order = {'System premii': 10, 'Uwierzytelnienie i autoryzacja': 20, 'Dane operacyjne': 30}
    return sorted(app_list, key=lambda app: (order.get(app['name'], 100), app['name'].lower()))


_ORIGINAL_GET_APP_LIST = admin.site.get_app_list
admin.site.get_app_list = MethodType(_ordered_app_list, admin.site)


class DepartmentAdminForm(forms.ModelForm):
    use_sap = forms.ChoiceField(
        label='Korzysta z importu SAP',
        choices=[('1', 'Tak'), ('0', 'Nie')],
        widget=forms.Select,
    )

    class Meta:
        model = Department
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.initial['use_sap'] = '1' if self.instance.use_sap else '0'

    def clean_use_sap(self):
        return self.cleaned_data['use_sap'] == '1'


@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    form = DepartmentAdminForm
    list_display = ('name', 'sap_status', 'time_tracking_mode', 'base_premium')
    list_filter = ('use_sap', 'time_tracking_mode')
    search_fields = ('name',)

    @admin.display(description='Korzysta z importu SAP', boolean=True, ordering='use_sap')
    def sap_status(self, obj):
        return obj.use_sap


@admin.register(AbsenceCode)
class AbsenceCodeAdmin(admin.ModelAdmin):
    list_display = ('code', 'description', 'basis', 'disqualifies_premium', 'active', 'sort_order')
    list_filter = ('basis', 'disqualifies_premium', 'active')
    search_fields = ('code', 'description')
    ordering = ('sort_order', 'code')


@admin.register(SAPCalendarMapping)
class SAPCalendarMappingAdmin(admin.ModelAdmin):
    list_display = ('sap_field', 'code', 'aggregation', 'active')
    list_filter = ('sap_field', 'aggregation', 'active')
    search_fields = ('code__code', 'code__description')
    list_editable = ('active',)
    ordering = ('sap_field', 'code__sort_order', 'code__code')


@admin.register(Holiday)
class HolidayAdmin(admin.ModelAdmin):
    list_display = ('date', 'name', 'kind', 'affects_working_days', 'active')
    list_filter = ('kind', 'affects_working_days', 'active')
    search_fields = ('name',)
    ordering = ('date',)
