def app_profile(request):
    if not request.user.is_authenticated:
        return {'app_profile': None}
    try:
        from .views import pof
        return {'app_profile': pof(request)}
    except Exception:
        return {'app_profile': None}
