from django.core.management.base import BaseCommand
from django.contrib.auth.models import Group, User
from core.models import Profile
from core.services import seed_default_holidays

ROLE_GROUPS = {
    'Użytkownik działu': Profile.ROLE_DEPT,
    'Finanse': Profile.ROLE_FIN,
    'Administrator': Profile.ROLE_ADMIN,
}


class Command(BaseCommand):
    help = 'Tworzy domyślne role systemowe i profile administratorów.'

    def handle(self, *args, **options):
        for name in ROLE_GROUPS:
            Group.objects.get_or_create(name=name)

        from datetime import date
        for year in range(date.today().year - 1, date.today().year + 11):
            seed_default_holidays(year)

        for user in User.objects.filter(is_superuser=True):
            profile, _ = Profile.objects.get_or_create(user=user, defaults={'role': Profile.ROLE_ADMIN})
            if profile.role != Profile.ROLE_ADMIN or profile.department_id is not None:
                profile.role = Profile.ROLE_ADMIN
                profile.department = None
                profile.save(update_fields=['role', 'department'])
            admin_group = Group.objects.get(name='Administrator')
            user.groups.add(admin_group)

        self.stdout.write(self.style.SUCCESS('Role i kalendarz świąt gotowe.'))
