# Generated manually for the initial Premie system schema.
from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    initial = True
    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]
    operations = [
        migrations.CreateModel(
            name='Department',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('name', models.CharField(max_length=120, unique=True)),
                ('use_sap', models.BooleanField(default=True)),
            ],
        ),
        migrations.CreateModel(
            name='AbsenceCode',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('code', models.CharField(max_length=20, unique=True)),
                ('description', models.CharField(max_length=255)),
                ('basis', models.CharField(choices=[('WORKING', 'Dni robocze'), ('CALENDAR', 'Dni kalendarzowe'), ('NONE', 'Nie potrącać')], default='WORKING', max_length=15)),
                ('active', models.BooleanField(default=True)),
                ('sort_order', models.PositiveIntegerField(default=0)),
            ],
        ),
        migrations.CreateModel(
            name='CalendarDay',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('date', models.DateField(unique=True)),
                ('is_working', models.BooleanField(default=True)),
                ('label', models.CharField(blank=True, max_length=100)),
            ],
        ),
        migrations.CreateModel(
            name='Profile',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('role', models.CharField(choices=[('DEPT', 'Dział'), ('FIN', 'Finanse'), ('ADMIN', 'Administrator')], default='DEPT', max_length=10)),
                ('department', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to='core.department')),
                ('user', models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.CreateModel(
            name='Month',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('year', models.PositiveIntegerField()),
                ('month', models.PositiveSmallIntegerField()),
                ('base_premium', models.DecimalField(decimal_places=2, default=600, max_digits=10)),
                ('status', models.CharField(choices=[('OPEN', 'Otwarty'), ('CALC', 'Wyliczony'), ('CLOSED', 'Zamknięty'), ('REOPENED', 'Ponownie otwarty')], default='OPEN', max_length=10)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('closed_at', models.DateTimeField(blank=True, null=True)),
                ('department', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='core.department')),
            ],
        ),
        migrations.CreateModel(
            name='Employee',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('personnel_no', models.CharField(max_length=40)),
                ('first_name', models.CharField(max_length=120)),
                ('last_name', models.CharField(max_length=120)),
                ('active', models.BooleanField(default=True)),
                ('department', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='core.department')),
            ],
        ),
        migrations.CreateModel(
            name='SAPRecord',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('personnel_no', models.CharField(max_length=40)),
                ('first_name', models.CharField(blank=True, max_length=120)),
                ('last_name', models.CharField(blank=True, max_length=120)),
                ('employment_date', models.DateField(blank=True, null=True)),
                ('subgroup', models.CharField(blank=True, max_length=100)),
                ('epc', models.CharField(blank=True, max_length=100)),
                ('efficiency', models.DecimalField(decimal_places=4, default=0, max_digits=10)),
                ('gk', models.DecimalField(decimal_places=4, default=0, max_digits=10)),
                ('overtime', models.DecimalField(decimal_places=2, default=0, max_digits=10)),
                ('month', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='core.month')),
            ],
        ),
        migrations.CreateModel(
            name='CalendarEntry',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('day', models.DateField()),
                ('hours', models.DecimalField(blank=True, decimal_places=2, max_digits=5, null=True)),
                ('code', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, to='core.absencecode')),
                ('employee', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='core.employee')),
                ('month', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='core.month')),
            ],
        ),
        migrations.CreateModel(
            name='EmployeeNote',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('quality', models.TextField(blank=True)),
                ('bhp', models.TextField(blank=True)),
                ('notes', models.TextField(blank=True)),
                ('employee', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='core.employee')),
                ('month', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='core.month')),
            ],
        ),
        migrations.CreateModel(
            name='PremiumResult',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('granted', models.DecimalField(decimal_places=2, max_digits=10)),
                ('deduction_working', models.DecimalField(decimal_places=2, default=0, max_digits=10)),
                ('deduction_calendar', models.DecimalField(decimal_places=2, default=0, max_digits=10)),
                ('payable', models.DecimalField(decimal_places=2, max_digits=10)),
                ('calculation_details', models.JSONField(default=dict)),
                ('employee', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='core.employee')),
                ('month', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='core.month')),
            ],
        ),
        migrations.CreateModel(
            name='AuditLog',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('action', models.CharField(max_length=80)),
                ('details', models.TextField(blank=True)),
                ('month', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to='core.month')),
                ('user', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.AddConstraint(
            model_name='month',
            constraint=models.UniqueConstraint(fields=('department', 'year', 'month'), name='uniq_dept_month'),
        ),
        migrations.AddConstraint(
            model_name='employee',
            constraint=models.UniqueConstraint(fields=('department', 'personnel_no'), name='uniq_emp_dept_no'),
        ),
        migrations.AddConstraint(
            model_name='saprecord',
            constraint=models.UniqueConstraint(fields=('month', 'personnel_no'), name='uniq_sap_month_person'),
        ),
        migrations.AddConstraint(
            model_name='calendarentry',
            constraint=models.UniqueConstraint(fields=('month', 'employee', 'day'), name='uniq_cal_entry'),
        ),
        migrations.AddConstraint(
            model_name='employeenote',
            constraint=models.UniqueConstraint(fields=('month', 'employee'), name='uniq_notes'),
        ),
        migrations.AddConstraint(
            model_name='premiumresult',
            constraint=models.UniqueConstraint(fields=('month', 'employee'), name='uniq_result'),
        ),
    ]
