from django.db import migrations


class Migration(migrations.Migration):
    dependencies = [('core', '0001_initial')]
    operations = [
        migrations.AlterModelOptions(name='department', options={'ordering': ['name'], 'verbose_name': 'Dział', 'verbose_name_plural': 'Działy'}),
        migrations.AlterModelOptions(name='profile', options={'ordering': ['user__username'], 'verbose_name': 'Profil użytkownika', 'verbose_name_plural': 'Profile użytkowników'}),
        migrations.AlterModelOptions(name='absencecode', options={'ordering': ['sort_order', 'code'], 'verbose_name': 'Kod nieobecności', 'verbose_name_plural': 'Kody nieobecności'}),
        migrations.AlterModelOptions(name='calendarday', options={'ordering': ['date'], 'verbose_name': 'Dzień kalendarza', 'verbose_name_plural': 'Dni kalendarza'}),
        migrations.AlterModelOptions(name='month', options={'ordering': ['-year', '-month'], 'verbose_name': 'Miesiąc', 'verbose_name_plural': 'Miesiące'}),
        migrations.AlterModelOptions(name='employee', options={'ordering': ['last_name', 'first_name'], 'verbose_name': 'Pracownik', 'verbose_name_plural': 'Pracownicy'}),
        migrations.AlterModelOptions(name='saprecord', options={'ordering': ['month', 'last_name', 'first_name'], 'verbose_name': 'Rekord SAP', 'verbose_name_plural': 'Rekordy SAP'}),
        migrations.AlterModelOptions(name='calendarentry', options={'ordering': ['month', 'employee', 'day'], 'verbose_name': 'Wpis kalendarza', 'verbose_name_plural': 'Wpisy kalendarza'}),
        migrations.AlterModelOptions(name='employeenote', options={'verbose_name': 'Opis pracownika', 'verbose_name_plural': 'Opisy pracowników'}),
        migrations.AlterModelOptions(name='premiumresult', options={'ordering': ['month', 'employee'], 'verbose_name': 'Wynik premii', 'verbose_name_plural': 'Wyniki premii'}),
        migrations.AlterModelOptions(name='auditlog', options={'ordering': ['-created_at'], 'verbose_name': 'Dziennik audytu', 'verbose_name_plural': 'Dziennik audytu'}),
    ]
