from django.db import migrations, models


def initialize_sort_order(apps, schema_editor):
    Employee = apps.get_model('core', 'Employee')
    Department = apps.get_model('core', 'Department')
    for dept in Department.objects.all().order_by('id'):
        employees = Employee.objects.filter(department_id=dept.id).order_by('last_name', 'first_name', 'id')
        for i, employee in enumerate(employees, start=1):
            employee.sort_order = i
            employee.save(update_fields=['sort_order'])


class Migration(migrations.Migration):
    dependencies = [('core', '0002_polish_admin_names')]
    operations = [
        migrations.AddField(
            model_name='employee',
            name='sort_order',
            field=models.PositiveIntegerField(default=0),
        ),
        migrations.RunPython(initialize_sort_order, migrations.RunPython.noop),
        migrations.AlterModelOptions(
            name='employee',
            options={
                'ordering': ['sort_order', 'last_name', 'first_name', 'id'],
                'verbose_name': 'Pracownik',
                'verbose_name_plural': 'Pracownicy',
            },
        ),
    ]
