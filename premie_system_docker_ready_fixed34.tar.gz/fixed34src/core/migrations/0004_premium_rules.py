from django.db import migrations, models

class Migration(migrations.Migration):
    dependencies = [('core', '0003_employee_sort_order')]
    operations = [
        migrations.AddField(model_name='absencecode', name='disqualifies_premium', field=models.BooleanField(default=False)),
        migrations.AddField(model_name='employee', name='premium_mode', field=models.CharField(choices=[('STANDARD', 'Standardowe naliczanie'), ('PORTIER', 'Portier — pełna premia')], default='STANDARD', max_length=10)),
    ]
