from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [('core', '0004_premium_rules')]

    operations = [
        migrations.CreateModel(
            name='Holiday',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('date', models.DateField(unique=True)),
                ('name', models.CharField(max_length=150)),
                ('kind', models.CharField(choices=[('HOLIDAY', 'Święto'), ('DAY_OFF', 'Dzień wolny')], default='HOLIDAY', max_length=20)),
                ('affects_working_days', models.BooleanField(default=True, verbose_name='Pomniejsza liczbę dni roboczych')),
                ('active', models.BooleanField(default=True)),
            ],
            options={
                'verbose_name': 'Święto / dzień wolny',
                'verbose_name_plural': 'Święta i dni wolne',
                'ordering': ['date'],
            },
        ),
    ]
