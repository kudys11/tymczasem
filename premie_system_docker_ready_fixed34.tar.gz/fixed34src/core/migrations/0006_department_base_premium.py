from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [("core", "0005_holiday")]
    operations = [
        migrations.AddField(
            model_name="department",
            name="base_premium",
            field=models.DecimalField(decimal_places=2, default=600, max_digits=10, verbose_name="Premia bazowa"),
        ),
    ]
