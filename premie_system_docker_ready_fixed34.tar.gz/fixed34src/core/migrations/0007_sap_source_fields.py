from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [("core", "0006_department_base_premium")]

    operations = [
        migrations.AddField(model_name="saprecord", name="report_called", field=models.CharField(blank=True, max_length=100)),
        migrations.AddField(model_name="saprecord", name="settlement_period", field=models.CharField(blank=True, max_length=100)),
        migrations.AddField(model_name="saprecord", name="plant", field=models.CharField(blank=True, max_length=100)),
        migrations.AddField(model_name="saprecord", name="vacation", field=models.DecimalField(decimal_places=2, default=0, max_digits=10)),
        migrations.AddField(model_name="saprecord", name="sick", field=models.DecimalField(decimal_places=2, default=0, max_digits=10)),
        migrations.AddField(model_name="saprecord", name="unpaid_absence", field=models.DecimalField(decimal_places=2, default=0, max_digits=10)),
        migrations.AddField(model_name="saprecord", name="other_absence", field=models.DecimalField(decimal_places=2, default=0, max_digits=10)),
    ]
