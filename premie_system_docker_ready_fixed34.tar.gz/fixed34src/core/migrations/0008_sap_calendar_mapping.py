from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    dependencies = [("core", "0007_sap_source_fields")]

    operations = [
        migrations.CreateModel(
            name="SAPCalendarMapping",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("sap_field", models.CharField(choices=[("overtime", "Nadgodz/Godz.ujem."), ("vacation", "Urlop wypoczynkowy"), ("sick", "choroba zwykła"), ("unpaid_absence", "Nieob. nieuspr. niepłatna"), ("other_absence", "Pozost. nieobecn.")], max_length=30)),
                ("aggregation", models.CharField(choices=[("COUNT_DAYS", "Liczba dni"), ("SUM_HOURS", "Suma godzin")], default="COUNT_DAYS", max_length=20)),
                ("active", models.BooleanField(default=True)),
                ("code", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="sap_calendar_mappings", to="core.absencecode")),
            ],
            options={"verbose_name": "Mapowanie SAP ↔ kalendarz", "verbose_name_plural": "Mapowania SAP ↔ kalendarz", "ordering": ["sap_field", "code__sort_order", "code__code"]},
        ),
        migrations.AddConstraint(
            model_name="sapcalendarmapping",
            constraint=models.UniqueConstraint(fields=("sap_field", "code", "aggregation"), name="uniq_sap_cal_mapping"),
        ),
    ]
