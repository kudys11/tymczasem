from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [("core", "0008_sap_calendar_mapping")]
    operations = [
        migrations.AddField(
            model_name="department", name="time_tracking_mode",
            field=models.CharField(choices=[("HOURS", "Kalendarz — wpisywanie liczby godzin"), ("CLOCK", "Ewidencja czasu — początek / koniec + godziny nocne")], default="HOURS", max_length=10, verbose_name="System ewidencji czasu"),
        ),
        migrations.AddField(
            model_name="month", name="time_tracking_mode",
            field=models.CharField(choices=[("HOURS", "Kalendarz — wpisywanie liczby godzin"), ("CLOCK", "Ewidencja czasu — początek / koniec + godziny nocne")], default="HOURS", max_length=10, verbose_name="System ewidencji czasu"),
        ),
        migrations.AddField(model_name="calendarentry", name="start_time", field=models.TimeField(blank=True, null=True, verbose_name="Początek pracy")),
        migrations.AddField(model_name="calendarentry", name="end_time", field=models.TimeField(blank=True, null=True, verbose_name="Koniec pracy")),
        migrations.AddField(model_name="calendarentry", name="overtime_leave_hours", field=models.DecimalField(blank=True, default=None, max_digits=5, decimal_places=2, null=True, verbose_name="Wolne za nadgodziny (h)")),
        migrations.CreateModel(
            name="OvertimeBalance",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("carried_in", models.DecimalField(decimal_places=2, default=0, max_digits=8, verbose_name="Saldo z poprzedniego miesiąca")),
                ("worked_hours", models.DecimalField(decimal_places=2, default=0, max_digits=8)),
                ("planned_hours", models.DecimalField(decimal_places=2, default=0, max_digits=8)),
                ("overtime", models.DecimalField(decimal_places=2, default=0, max_digits=8, verbose_name="Nadgodziny / godziny ujemne")),
                ("night_hours", models.DecimalField(decimal_places=2, default=0, max_digits=8, verbose_name="Godziny nocne")),
                ("overtime_leave_hours", models.DecimalField(decimal_places=2, default=0, max_digits=8, verbose_name="Wolne za nadgodziny")),
                ("carried_out", models.DecimalField(decimal_places=2, default=0, max_digits=8, verbose_name="Saldo na następny miesiąc")),
                ("employee", models.ForeignKey(on_delete=models.deletion.CASCADE, to="core.employee")),
                ("month", models.ForeignKey(on_delete=models.deletion.CASCADE, to="core.month")),
            ],
            options={"verbose_name":"Saldo nadgodzin", "verbose_name_plural":"Salda nadgodzin", "ordering":["month", "employee"]},
        ),
        migrations.AddConstraint(model_name="overtimebalance", constraint=models.UniqueConstraint(fields=("month", "employee"), name="uniq_overtime_balance")),
    ]
