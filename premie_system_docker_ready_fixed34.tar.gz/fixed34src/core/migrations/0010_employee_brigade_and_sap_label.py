from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [("core", "0009_time_tracking")]

    operations = [
        migrations.AddField(
            model_name="employee",
            name="brigade",
            field=models.PositiveSmallIntegerField(default=1, verbose_name="Brygada"),
        ),
        migrations.AlterField(
            model_name="department",
            name="use_sap",
            field=models.BooleanField(default=True, verbose_name="Korzysta z importu SAP"),
        ),
    ]
