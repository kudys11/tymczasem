from django import template
register = template.Library()

@register.filter
def get_item(mapping, key):
    if mapping is None:
        return {}
    value = mapping.get(key)
    return {} if value is None else value

@register.filter
def get_item2(mapping, key):
    if mapping is None:
        return {}
    value = mapping.get(key)
    return {} if value is None else value
