#!/bin/sh
set -eu

python - <<'PY'
import os, socket, time
host = os.getenv('POSTGRES_HOST', 'db')
port = int(os.getenv('POSTGRES_PORT', '5432'))
for attempt in range(60):
    try:
        with socket.create_connection((host, port), timeout=2):
            print('PostgreSQL is reachable.')
            break
    except OSError:
        print(f'Waiting for PostgreSQL ({attempt + 1}/60)...')
        time.sleep(2)
else:
    raise SystemExit('PostgreSQL did not become reachable in time.')
PY

python manage.py migrate --noinput
python manage.py bootstrap_roles
python manage.py check
python manage.py collectstatic --noinput
exec python manage.py runserver 0.0.0.0:8000
