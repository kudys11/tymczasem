from django.db import migrations


class Migration(migrations.Migration):
    initial = True
    dependencies = [
        ('core', '0010_employee_brigade_and_sap_label'),
    ]
    operations = [
        migrations.CreateModel(
            name='Month',
            fields=[],
            options={'proxy': True, 'verbose_name': 'Miesiąc', 'verbose_name_plural': 'Miesiące'},
            bases=('core.month',),
        ),
        migrations.CreateModel(
            name='Employee',
            fields=[],
            options={'proxy': True, 'verbose_name': 'Pracownik', 'verbose_name_plural': 'Pracownicy'},
            bases=('core.employee',),
        ),
        migrations.CreateModel(
            name='SAPRecord',
            fields=[],
            options={'proxy': True, 'verbose_name': 'Rekord SAP', 'verbose_name_plural': 'Rekordy SAP'},
            bases=('core.saprecord',),
        ),
        migrations.CreateModel(
            name='CalendarEntry',
            fields=[],
            options={'proxy': True, 'verbose_name': 'Wpis kalendarza', 'verbose_name_plural': 'Wpisy kalendarza'},
            bases=('core.calendarentry',),
        ),
        migrations.CreateModel(
            name='OvertimeBalance',
            fields=[],
            options={'proxy': True, 'verbose_name': 'Saldo nadgodzin', 'verbose_name_plural': 'Salda nadgodzin'},
            bases=('core.overtimebalance',),
        ),
        migrations.CreateModel(
            name='EmployeeNote',
            fields=[],
            options={'proxy': True, 'verbose_name': 'Opis pracownika', 'verbose_name_plural': 'Opisy pracowników'},
            bases=('core.employeenote',),
        ),
        migrations.CreateModel(
            name='PremiumResult',
            fields=[],
            options={'proxy': True, 'verbose_name': 'Wynik premii', 'verbose_name_plural': 'Wyniki premii'},
            bases=('core.premiumresult',),
        ),
        migrations.CreateModel(
            name='AuditLog',
            fields=[],
            options={'proxy': True, 'verbose_name': 'Dziennik audytu', 'verbose_name_plural': 'Dzienniki audytu'},
            bases=('core.auditlog',),
        ),
    ]
