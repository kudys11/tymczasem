from core.models import (
    Month as CoreMonth,
    Employee as CoreEmployee,
    SAPRecord as CoreSAPRecord,
    CalendarEntry as CoreCalendarEntry,
    OvertimeBalance as CoreOvertimeBalance,
    EmployeeNote as CoreEmployeeNote,
    CalendarDay as CoreCalendarDay,
    PremiumResult as CorePremiumResult,
    AuditLog as CoreAuditLog,
)


class Month(CoreMonth):
    class Meta:
        proxy = True
        app_label = 'operations'
        verbose_name = 'Miesiąc'
        verbose_name_plural = 'Miesiące'


class Employee(CoreEmployee):
    class Meta:
        proxy = True
        app_label = 'operations'
        verbose_name = 'Pracownik'
        verbose_name_plural = 'Pracownicy'


class SAPRecord(CoreSAPRecord):
    class Meta:
        proxy = True
        app_label = 'operations'
        verbose_name = 'Rekord SAP'
        verbose_name_plural = 'Rekordy SAP'


class CalendarEntry(CoreCalendarEntry):
    class Meta:
        proxy = True
        app_label = 'operations'
        verbose_name = 'Wpis kalendarza'
        verbose_name_plural = 'Wpisy kalendarza'


class OvertimeBalance(CoreOvertimeBalance):
    class Meta:
        proxy = True
        app_label = 'operations'
        verbose_name = 'Saldo nadgodzin'
        verbose_name_plural = 'Salda nadgodzin'


class EmployeeNote(CoreEmployeeNote):
    class Meta:
        proxy = True
        app_label = 'operations'
        verbose_name = 'Opis pracownika'
        verbose_name_plural = 'Opisy pracowników'


class PremiumResult(CorePremiumResult):
    class Meta:
        proxy = True
        app_label = 'operations'
        verbose_name = 'Wynik premii'
        verbose_name_plural = 'Wyniki premii'


class AuditLog(CoreAuditLog):
    class Meta:
        proxy = True
        app_label = 'operations'
        verbose_name = 'Dziennik audytu'
        verbose_name_plural = 'Dzienniki audytu'


class CalendarDay(CoreCalendarDay):
    class Meta:
        proxy = True
        app_label = 'operations'
        verbose_name = 'Dzień kalendarza'
        verbose_name_plural = 'Dni kalendarza'
        ordering = ['date']
