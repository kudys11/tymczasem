# System Premii — fixed35

Poprawka statycznych plików i logo POLIPOL.

- rootowy katalog `static/` jest wpisany do `STATICFILES_DIRS`, więc `collectstatic` kopiuje logo do `staticfiles/`;
- `/static/<path>` ma fallback do katalogu źródłowego `static/`, dzięki czemu logo działa również jeśli `STATIC_ROOT` nie został jeszcze zapełniony;
- konfiguracja nie zależy od konkretnej domeny ani protokołu HTTP/HTTPS.
