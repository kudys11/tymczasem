# System Premii — fixed35

Poprawka statycznych plików i logo POLIPOL.

- rootowy katalog `static/` jest wpisany do `STATICFILES_DIRS`, więc `collectstatic` kopiuje logo do `staticfiles/`;
- `/static/<path>` ma fallback do katalogu źródłowego `static/`, dzięki czemu logo działa również jeśli `STATIC_ROOT` nie został jeszcze zapełniony;
- konfiguracja nie zależy od konkretnej domeny ani protokołu HTTP/HTTPS.

## Logo
The POLIPOL logo uses a versioned static filename (`polipol-logo-v2.png`) so browsers/reverse proxies cannot continue serving a previously cached `polipol-logo.png` under the same URL.
