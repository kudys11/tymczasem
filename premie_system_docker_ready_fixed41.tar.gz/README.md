# System Premii — fixed35

Poprawka statycznych plików i logo POLIPOL.

- rootowy katalog `static/` jest wpisany do `STATICFILES_DIRS`, więc `collectstatic` kopiuje logo do `staticfiles/`;
- `/static/<path>` ma fallback do katalogu źródłowego `static/`, dzięki czemu logo działa również jeśli `STATIC_ROOT` nie został jeszcze zapełniony;
- konfiguracja nie zależy od konkretnej domeny ani protokołu HTTP/HTTPS.


fixed38: dodano Department.use_premiums i snapshot Month.use_premiums; dział może prowadzić samą ewidencję czasu bez systemu premiowego. Zaktualizowano logo POLIPOL do polipol-logo-v3.png.

fixed38: Department.use_premiums / Month.use_premiums pozwala prowadzić samą ewidencję czasu bez systemu premiowego; ustawienie działu jest snapshotowane przy tworzeniu miesiąca. Zaktualizowano logo do polipol-logo-v3.png.
