# System Premii — fixed44

Poprawka wydruku raportu nadgodzin:
- nagłówek z logo jest przypięty do górnej części każdej strony wydruku,
- logo nie jest już pozycjonowane ujemnym `top`,
- zwiększono bezpieczny margines górny strony,
- numer strony jest przypięty do dołu strony,
- układ pozostaje A4 poziomo.

Brak zmian w bazie danych.
