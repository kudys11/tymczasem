from django.db import models
from django.contrib.auth.models import User


class Department(models.Model):
    TIME_HOURS = 'HOURS'
    TIME_CLOCK = 'CLOCK'
    TIME_TRACKING_CHOICES = [
        (TIME_HOURS, 'Kalendarz — wpisywanie liczby godzin'),
        (TIME_CLOCK, 'Ewidencja czasu — początek / koniec + godziny nocne'),
    ]
    name = models.CharField(max_length=120, unique=True)
    use_sap = models.BooleanField(default=True, verbose_name='Korzysta z importu SAP')
    use_premiums = models.BooleanField(default=True, verbose_name='Obsługuje system premiowy')
    time_tracking_mode = models.CharField(max_length=10, choices=TIME_TRACKING_CHOICES, default=TIME_HOURS, verbose_name='System ewidencji czasu')
    base_premium = models.DecimalField(max_digits=10, decimal_places=2, default=600, verbose_name='Premia bazowa')

    class Meta:
        verbose_name = 'Dział'
        verbose_name_plural = 'Działy'
        ordering = ['name']

    def __str__(self):
        return self.name


class Profile(models.Model):
    ROLE_DEPT = 'DEPT'
    ROLE_FIN = 'FIN'
    ROLE_ADMIN = 'ADMIN'
    ROLES = [(ROLE_DEPT, 'Użytkownik działu'), (ROLE_FIN, 'Finanse'), (ROLE_ADMIN, 'Administrator')]

    user = models.OneToOneField(User, on_delete=models.CASCADE)
    role = models.CharField(max_length=10, choices=ROLES, default=ROLE_DEPT)
    department = models.ForeignKey(Department, null=True, blank=True, on_delete=models.SET_NULL)

    class Meta:
        verbose_name = 'Profil użytkownika'
        verbose_name_plural = 'Profile użytkowników'
        ordering = ['user__username']

    def __str__(self):
        return self.user.username


class AbsenceCode(models.Model):
    code = models.CharField(max_length=20, unique=True)
    description = models.CharField(max_length=255)
    basis = models.CharField(max_length=15, choices=[('WORKING', 'Dni robocze'), ('CALENDAR', 'Dni kalendarzowe'), ('NONE', 'Nie potrącać')], default='WORKING')
    active = models.BooleanField(default=True)
    sort_order = models.PositiveIntegerField(default=0)
    disqualifies_premium = models.BooleanField(default=False)

    class Meta:
        verbose_name = 'Kod nieobecności'
        verbose_name_plural = 'Kody nieobecności'
        ordering = ['sort_order', 'code']

    def __str__(self):
        return f'{self.code} – {self.description}'


class CalendarDay(models.Model):
    date = models.DateField(unique=True)
    is_working = models.BooleanField(default=True)
    label = models.CharField(max_length=100, blank=True)

    class Meta:
        verbose_name = 'Dzień kalendarza'
        verbose_name_plural = 'Dni kalendarza'
        ordering = ['date']

    def __str__(self):
        return str(self.date)


class Holiday(models.Model):
    date = models.DateField(unique=True)
    name = models.CharField(max_length=150)
    kind = models.CharField(
        max_length=20,
        choices=[('HOLIDAY', 'Święto'), ('DAY_OFF', 'Dzień wolny')],
        default='HOLIDAY',
    )
    affects_working_days = models.BooleanField(
        default=True,
        verbose_name='Pomniejsza liczbę dni roboczych',
    )
    active = models.BooleanField(default=True)

    class Meta:
        verbose_name = 'Święto / dzień wolny'
        verbose_name_plural = 'Święta i dni wolne'
        ordering = ['date']

    def __str__(self):
        return f'{self.date:%d.%m.%Y} — {self.name}'


class Month(models.Model):
    OPEN = 'OPEN'
    CALC = 'CALC'
    CLOSED = 'CLOSED'
    REOPENED = 'REOPENED'
    STATUS = [(OPEN, 'Otwarty'), (CALC, 'Wyliczony'), (CLOSED, 'Zamknięty'), (REOPENED, 'Ponownie otwarty')]

    department = models.ForeignKey(Department, on_delete=models.CASCADE)
    year = models.PositiveIntegerField()
    month = models.PositiveSmallIntegerField()
    base_premium = models.DecimalField(max_digits=10, decimal_places=2, default=600)
    use_premiums = models.BooleanField(default=True, verbose_name='Obsługuje system premiowy')
    time_tracking_mode = models.CharField(max_length=10, choices=Department.TIME_TRACKING_CHOICES, default=Department.TIME_HOURS, verbose_name='System ewidencji czasu')
    status = models.CharField(max_length=10, choices=STATUS, default=OPEN)
    created_at = models.DateTimeField(auto_now_add=True)
    closed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        verbose_name = 'Miesiąc'
        verbose_name_plural = 'Miesiące'
        constraints = [models.UniqueConstraint(fields=['department', 'year', 'month'], name='uniq_dept_month')]
        ordering = ['-year', '-month']

    def __str__(self):
        return f'{self.department} {self.month:02d}/{self.year}'


class Employee(models.Model):
    department = models.ForeignKey(Department, on_delete=models.CASCADE)
    personnel_no = models.CharField(max_length=40)
    first_name = models.CharField(max_length=120)
    last_name = models.CharField(max_length=120)
    active = models.BooleanField(default=True)
    sort_order = models.PositiveIntegerField(default=0)
    brigade = models.PositiveSmallIntegerField(default=1, verbose_name='Brygada')
    PREMIUM_STANDARD = 'STANDARD'
    PREMIUM_PORTIER = 'PORTIER'
    PREMIUM_MODES = [(PREMIUM_STANDARD, 'Standardowe naliczanie'), (PREMIUM_PORTIER, 'Portier — pełna premia')]
    premium_mode = models.CharField(max_length=10, choices=PREMIUM_MODES, default=PREMIUM_STANDARD)

    class Meta:
        verbose_name = 'Pracownik'
        verbose_name_plural = 'Pracownicy'
        constraints = [models.UniqueConstraint(fields=['department', 'personnel_no'], name='uniq_emp_dept_no')]
        ordering = ['brigade', 'sort_order', 'last_name', 'first_name', 'id']

    def __str__(self):
        return f'{self.last_name} {self.first_name}'


class SAPRecord(models.Model):
    month = models.ForeignKey(Month, on_delete=models.CASCADE)
    report_called = models.CharField(max_length=100, blank=True)
    settlement_period = models.CharField(max_length=100, blank=True)
    plant = models.CharField(max_length=100, blank=True)
    personnel_no = models.CharField(max_length=40)
    first_name = models.CharField(max_length=120, blank=True)
    last_name = models.CharField(max_length=120, blank=True)
    employment_date = models.DateField(null=True, blank=True)
    subgroup = models.CharField(max_length=100, blank=True)
    epc = models.CharField(max_length=100, blank=True)
    efficiency = models.DecimalField(max_digits=10, decimal_places=4, default=0)
    gk = models.DecimalField(max_digits=10, decimal_places=4, default=0)
    overtime = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    vacation = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    sick = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    unpaid_absence = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    other_absence = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    class Meta:
        verbose_name = 'Rekord SAP'
        verbose_name_plural = 'Rekordy SAP'
        constraints = [models.UniqueConstraint(fields=['month', 'personnel_no'], name='uniq_sap_month_person')]
        ordering = ['month', 'last_name', 'first_name']


class SAPCalendarMapping(models.Model):
    FIELD_OVERTIME = 'overtime'
    FIELD_VACATION = 'vacation'
    FIELD_SICK = 'sick'
    FIELD_UNPAID = 'unpaid_absence'
    FIELD_OTHER = 'other_absence'
    FIELD_CHOICES = [
        (FIELD_OVERTIME, 'Nadgodz/Godz.ujem.'),
        (FIELD_VACATION, 'Urlop wypoczynkowy'),
        (FIELD_SICK, 'choroba zwykła'),
        (FIELD_UNPAID, 'Nieob. nieuspr. niepłatna'),
        (FIELD_OTHER, 'Pozost. nieobecn.'),
    ]
    COUNT_DAYS = 'COUNT_DAYS'
    SUM_HOURS = 'SUM_HOURS'
    AGGREGATION_CHOICES = [
        (COUNT_DAYS, 'Liczba dni'),
        (SUM_HOURS, 'Suma godzin'),
    ]
    sap_field = models.CharField(max_length=30, choices=FIELD_CHOICES)
    code = models.ForeignKey(AbsenceCode, on_delete=models.CASCADE, related_name='sap_calendar_mappings')
    aggregation = models.CharField(max_length=20, choices=AGGREGATION_CHOICES, default=COUNT_DAYS)
    active = models.BooleanField(default=True)

    class Meta:
        verbose_name = 'Mapowanie SAP ↔ kalendarz'
        verbose_name_plural = 'Mapowania SAP ↔ kalendarz'
        ordering = ['sap_field', 'code__sort_order', 'code__code']
        constraints = [models.UniqueConstraint(fields=['sap_field', 'code', 'aggregation'], name='uniq_sap_cal_mapping')]

    def __str__(self):
        return f'{self.get_sap_field_display()} ← {self.code.code} ({self.get_aggregation_display()})'


class CalendarEntry(models.Model):
    month = models.ForeignKey(Month, on_delete=models.CASCADE)
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    day = models.DateField()
    hours = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)
    start_time = models.TimeField(null=True, blank=True, verbose_name='Początek pracy')
    end_time = models.TimeField(null=True, blank=True, verbose_name='Koniec pracy')
    overtime_leave_hours = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True, default=None, verbose_name='Wolne za nadgodziny (h)')
    code = models.ForeignKey(AbsenceCode, null=True, blank=True, on_delete=models.PROTECT)

    class Meta:
        verbose_name = 'Wpis kalendarza'
        verbose_name_plural = 'Wpisy kalendarza'
        constraints = [models.UniqueConstraint(fields=['month', 'employee', 'day'], name='uniq_cal_entry')]
        ordering = ['month', 'employee', 'day']


class OvertimeBalance(models.Model):
    month = models.ForeignKey(Month, on_delete=models.CASCADE)
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    carried_in = models.DecimalField(max_digits=8, decimal_places=2, default=0, verbose_name='Saldo z poprzedniego miesiąca')
    worked_hours = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    planned_hours = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    overtime = models.DecimalField(max_digits=8, decimal_places=2, default=0, verbose_name='Nadgodziny / godziny ujemne')
    night_hours = models.DecimalField(max_digits=8, decimal_places=2, default=0, verbose_name='Godziny nocne')
    overtime_leave_hours = models.DecimalField(max_digits=8, decimal_places=2, default=0, verbose_name='Wolne za nadgodziny')
    carried_out = models.DecimalField(max_digits=8, decimal_places=2, default=0, verbose_name='Saldo na następny miesiąc')

    class Meta:
        verbose_name = 'Saldo nadgodzin'
        verbose_name_plural = 'Salda nadgodzin'
        constraints = [models.UniqueConstraint(fields=['month', 'employee'], name='uniq_overtime_balance')]
        ordering = ['month', 'employee']


class EmployeeNote(models.Model):
    month = models.ForeignKey(Month, on_delete=models.CASCADE)
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    quality = models.TextField(blank=True)
    bhp = models.TextField(blank=True)
    notes = models.TextField(blank=True)

    class Meta:
        verbose_name = 'Opis pracownika'
        verbose_name_plural = 'Opisy pracowników'
        constraints = [models.UniqueConstraint(fields=['month', 'employee'], name='uniq_notes')]


class PremiumResult(models.Model):
    month = models.ForeignKey(Month, on_delete=models.CASCADE)
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    granted = models.DecimalField(max_digits=10, decimal_places=2)
    deduction_working = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    deduction_calendar = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    payable = models.DecimalField(max_digits=10, decimal_places=2)
    calculation_details = models.JSONField(default=dict)

    class Meta:
        verbose_name = 'Wynik premii'
        verbose_name_plural = 'Wyniki premii'
        constraints = [models.UniqueConstraint(fields=['month', 'employee'], name='uniq_result')]
        ordering = ['month', 'employee']


class AuditLog(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    user = models.ForeignKey(User, null=True, on_delete=models.SET_NULL)
    month = models.ForeignKey(Month, null=True, on_delete=models.SET_NULL)
    action = models.CharField(max_length=80)
    details = models.TextField(blank=True)

    class Meta:
        verbose_name = 'Dziennik audytu'
        verbose_name_plural = 'Dziennik audytu'
        ordering = ['-created_at']
