from django.contrib import admin
from django.contrib import messages
from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.admin import UserAdmin
from django.http import HttpResponseRedirect
from django.template.response import TemplateResponse
from django.urls import reverse
from django.core.exceptions import ValidationError
from types import MethodType
from .models import *

admin.site.site_header = 'System Premii — Administracja'
admin.site.site_title = 'System Premii'
admin.site.index_title = 'Panel administracyjny'



User = get_user_model()

def get_security_settings():
    # Keep account creation/reset functional even if the singleton row was
    # removed manually from the database.
    settings, _ = SecuritySettings.objects.get_or_create(
        pk=1, defaults={'default_password': 'Start123!'}
    )
    return settings


class SecuritySettingsAdminForm(forms.ModelForm):
    class Meta:
        model = SecuritySettings
        fields = '__all__'
        widgets = {'default_password': forms.PasswordInput(render_value=True)}

    def clean_default_password(self):
        password = self.cleaned_data.get('default_password', '')
        if len(password) < 6:
            raise ValidationError('Domyślne hasło musi mieć minimum 6 znaków.')
        if not any(ch.isdigit() for ch in password):
            raise ValidationError('Domyślne hasło musi zawierać co najmniej jedną cyfrę.')
        if not any(not ch.isalnum() for ch in password):
            raise ValidationError('Domyślne hasło musi zawierać co najmniej jeden znak specjalny.')
        return password


@admin.register(SecuritySettings)
class SecuritySettingsAdmin(admin.ModelAdmin):
    form = SecuritySettingsAdminForm
    fieldsets = ((None, {'fields': ('default_password',), 'description': 'To hasło jest ustawiane nowym użytkownikom oraz przy operacji „Resetuj hasło do domyślnego”. Użytkownik musi zmienić je przy pierwszym logowaniu.'}),)

    def has_add_permission(self, request):
        return not SecuritySettings.objects.exists()

    def has_delete_permission(self, request, obj=None):
        return False


class UserAddForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name', 'email', 'is_active', 'is_staff', 'is_superuser')
        help_texts = {'username': 'Login użytkownika.'}

    def clean_username(self):
        username = self.cleaned_data['username'].strip()
        if not username:
            raise forms.ValidationError('Login jest wymagany.')
        return username


class PremieUserAdmin(UserAdmin):
    add_form = UserAddForm
    add_fieldsets = (
        (None, {'fields': ('username', 'first_name', 'last_name', 'email')}),
        ('Uprawnienia', {'fields': ('is_active', 'is_staff', 'is_superuser')}),
        ('Hasło', {'description': 'Nowy użytkownik otrzyma skonfigurowane domyślne hasło i przy pierwszym logowaniu zostanie poproszony o ustawienie własnego.'}),
    )
    actions = ('reset_to_default_password',)
    list_display = ('username', 'first_name', 'last_name', 'is_active', 'password_change_required', 'is_staff', 'is_superuser')
    search_fields = ('username', 'first_name', 'last_name', 'email')

    @admin.display(description='Wymaga zmiany hasła', boolean=True)
    def password_change_required(self, obj):
        profile = getattr(obj, 'profile', None)
        return bool(profile and profile.must_change_password)

    def save_model(self, request, obj, form, change):
        if not change:
            settings = get_security_settings()
            obj.set_password(settings.default_password)
        super().save_model(request, obj, form, change)
        profile, _ = Profile.objects.get_or_create(user=obj, defaults={'role': Profile.ROLE_DEPT})
        if not change and not profile.must_change_password:
            profile.must_change_password = True
            profile.save(update_fields=['must_change_password'])

    def change_password(self, request, object_id, form_url='', extra_context=None):
        """Replace Django's manual password editor with the configured reset flow.

        The admin's "Zmień hasło" action is the place users naturally expect to
        reset an account. It therefore applies the configured default password
        and marks the profile so the user must choose a personal password at the
        next login.
        """
        user = self.get_object(request, object_id)
        if user is None:
            from django.http import Http404
            raise Http404('Nie znaleziono użytkownika.')
        if not self.has_change_permission(request, user):
            from django.core.exceptions import PermissionDenied
            raise PermissionDenied

        settings = get_security_settings()
        if request.method == 'POST':
            user.set_password(settings.default_password)
            user.save(update_fields=['password'])
            profile, _ = Profile.objects.get_or_create(
                user=user, defaults={'role': Profile.ROLE_DEPT}
            )
            profile.must_change_password = True
            profile.save(update_fields=['must_change_password'])
            self.message_user(
                request,
                f'Hasło użytkownika {user.username} zostało zresetowane do domyślnego. ' +
                'Przy następnym logowaniu użytkownik musi ustawić własne hasło.',
                level=messages.SUCCESS,
            )
            return HttpResponseRedirect(
                reverse('admin:auth_user_changelist')
            )

        context = {
            **self.admin_site.each_context(request),
            'title': f'Resetuj hasło: {user.username}',
            'subtitle': user.username,
            'user_obj': user,
            'default_password': settings.default_password,
            'opts': self.model._meta,
            'has_view_permission': self.has_view_permission(request, user),
            'has_change_permission': self.has_change_permission(request, user),
            'original': user,
            'form_url': form_url,
        }
        if extra_context:
            context.update(extra_context)
        request.current_app = self.admin_site.name
        return TemplateResponse(
            request,
            'admin/auth/user/change_password.html',
            context,
        )

    @admin.action(description='Resetuj hasło do domyślnego')
    def reset_to_default_password(self, request, queryset):
        settings = get_security_settings()
        count = 0
        for user in queryset:
            user.set_password(settings.default_password)
            user.save(update_fields=['password'])
            profile, _ = Profile.objects.get_or_create(user=user, defaults={'role': Profile.ROLE_DEPT})
            profile.must_change_password = True
            profile.save(update_fields=['must_change_password'])
            count += 1
        self.message_user(request, f'Zresetowano hasło dla {count} użytkowników. Przy następnym logowaniu będą musieli ustawić własne hasło.')


try:
    admin.site.unregister(User)
except admin.sites.NotRegistered:
    pass
admin.site.register(User, PremieUserAdmin)

# Modele operacyjne są prezentowane wyłącznie w osobnej grupie
# „Dane operacyjne” (aplikacja proxy `operations`).
# Usuwamy ewentualne stare rejestracje modeli z `core`, aby administracja
# nie generowała linków typu /admin/core/employee/ prowadzących do 404.
_OPERATIONAL_CORE_MODELS = (
    Month, Employee, SAPRecord, CalendarEntry, OvertimeBalance,
    EmployeeNote, PremiumResult, AuditLog, CalendarDay,
)
for _model in _OPERATIONAL_CORE_MODELS:
    try:
        admin.site.unregister(_model)
    except admin.sites.NotRegistered:
        pass


class AuthProfile(Profile):
    class Meta:
        proxy = True
        app_label = 'auth'
        verbose_name = 'Profil użytkownika'
        verbose_name_plural = 'Profile użytkowników'
        ordering = ['user__username']


@admin.register(AuthProfile)
class AuthProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'role', 'department')
    list_filter = ('role', 'department')
    search_fields = ('user__username', 'user__first_name', 'user__last_name')


def _ordered_app_list(self, request, app_label=None):
    app_list = _ORIGINAL_GET_APP_LIST(request, app_label)
    if app_label:
        return app_list
    order = {'System premii': 10, 'Uwierzytelnienie i autoryzacja': 20, 'Dane operacyjne': 30}
    return sorted(app_list, key=lambda app: (order.get(app['name'], 100), app['name'].lower()))


_ORIGINAL_GET_APP_LIST = admin.site.get_app_list
admin.site.get_app_list = MethodType(_ordered_app_list, admin.site)


class DepartmentAdminForm(forms.ModelForm):
    use_sap = forms.ChoiceField(
        label='Korzysta z importu SAP',
        choices=[('1', 'Tak'), ('0', 'Nie')],
        widget=forms.Select,
    )
    use_premiums = forms.ChoiceField(
        label='Obsługuje system premiowy',
        choices=[('1', 'Tak'), ('0', 'Nie')],
        widget=forms.Select,
    )

    class Meta:
        model = Department
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.initial['use_sap'] = '1' if self.instance.use_sap else '0'
        self.initial['use_premiums'] = '1' if self.instance.use_premiums else '0'

    def clean_use_sap(self):
        return self.cleaned_data['use_sap'] == '1'

    def clean_use_premiums(self):
        return self.cleaned_data['use_premiums'] == '1'


@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    form = DepartmentAdminForm
    list_display = ('name', 'premium_status', 'sap_status', 'time_tracking_mode', 'base_premium')
    list_filter = ('use_premiums', 'use_sap', 'time_tracking_mode')
    search_fields = ('name',)

    @admin.display(description='Obsługuje system premiowy', boolean=True, ordering='use_premiums')
    def premium_status(self, obj):
        return obj.use_premiums

    @admin.display(description='Korzysta z importu SAP', boolean=True, ordering='use_sap')
    def sap_status(self, obj):
        return obj.use_sap


@admin.register(AbsenceCode)
class AbsenceCodeAdmin(admin.ModelAdmin):
    list_display = ('code', 'description', 'basis', 'disqualifies_premium', 'active', 'sort_order')
    list_filter = ('basis', 'disqualifies_premium', 'active')
    search_fields = ('code', 'description')
    ordering = ('sort_order', 'code')


@admin.register(SAPCalendarMapping)
class SAPCalendarMappingAdmin(admin.ModelAdmin):
    list_display = ('sap_field', 'code', 'aggregation', 'active')
    list_filter = ('sap_field', 'aggregation', 'active')
    search_fields = ('code__code', 'code__description')
    list_editable = ('active',)
    ordering = ('sap_field', 'code__sort_order', 'code__code')


@admin.register(Holiday)
class HolidayAdmin(admin.ModelAdmin):
    list_display = ('date', 'name', 'kind', 'affects_working_days', 'active')
    list_filter = ('kind', 'affects_working_days', 'active')
    search_fields = ('name',)
    ordering = ('date',)
