# System Premii — fixed44

Poprawka wydruku raportu nadgodzin:
- nagłówek z logo jest przypięty do górnej części każdej strony wydruku,
- logo nie jest już pozycjonowane ujemnym `top`,
- zwiększono bezpieczny margines górny strony,
- numer strony jest przypięty do dołu strony,
- układ pozostaje A4 poziomo.

Brak zmian w bazie danych.

## fixed46 — zmiany
- Umniejszenie premii bazowej: pole kwotowe w Jakość / BHP / Uwagi; uzasadnienie pozostaje w polu Uwagi i jest pokazywane po wyliczeniu.
- Brygada pracownika jest opcjonalnym tekstem do 20 znaków (np. 1, 2, A, B); może być pusta. Pusta brygada jest dostępna w filtrze i masowym ustawianiu godzin jako „Brak brygady”.
- Godziny nocne obejmują pełny przedział 22:00–06:00, w tym 00:00–06:00 dla zmiany zaczynającej się np. o 04:00.
