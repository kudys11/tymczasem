from django.contrib import admin
from django.conf import settings
from django.urls import path, include
from django.views.static import serve as static_serve

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", include("core.urls")),
]

# Wdrożenie korzysta z Django runserver również przy DEBUG=0.
# django.conf.urls.static.static() jest aktywne tylko przy DEBUG=True,
# dlatego statyczne pliki udostępniamy jawnie. Dzięki temu logo i CSS
# działają także w produkcyjnej konfiguracji DEBUG=0.

def serve_static(request, path):
    """Serve collected static files, with a source-tree fallback.

    The application is intentionally self-contained and may be run with
    DEBUG=0 behind either HTTP or HTTPS.  The fallback also makes the app
    resilient if collectstatic has not yet populated STATIC_ROOT.
    """
    from pathlib import Path
    collected = Path(settings.STATIC_ROOT) / path
    if collected.is_file():
        return static_serve(request, path, document_root=settings.STATIC_ROOT)
    source = Path(settings.BASE_DIR) / "static" / path
    if source.is_file():
        return static_serve(request, path, document_root=Path(settings.BASE_DIR) / "static")
    return static_serve(request, path, document_root=settings.STATIC_ROOT)

urlpatterns += [
    path("static/<path:path>", serve_static),
]
