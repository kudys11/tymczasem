from django import forms
from django.contrib.auth.forms import PasswordChangeForm


class FirstPasswordChangeForm(PasswordChangeForm):
    def clean_new_password1(self):
        password = self.cleaned_data.get('new_password1', '')
        if len(password) < 6:
            raise forms.ValidationError('Hasło musi mieć minimum 6 znaków.')
        if not any(ch.isdigit() for ch in password):
            raise forms.ValidationError('Hasło musi zawierać co najmniej jedną cyfrę.')
        if not any(not ch.isalnum() for ch in password):
            raise forms.ValidationError('Hasło musi zawierać co najmniej jeden znak specjalny.')
        return password
