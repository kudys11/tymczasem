from django.shortcuts import redirect
from django.urls import reverse


class ForcePasswordChangeMiddleware:
    """Blocks application access until a newly/reset user's password is changed."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        user = getattr(request, 'user', None)
        if user is not None and user.is_authenticated:
            profile = getattr(user, 'profile', None)
            allowed_paths = {reverse('change_password'), reverse('logout')}
            if profile and profile.must_change_password and request.path not in allowed_paths:
                return redirect('change_password')
        return self.get_response(request)
