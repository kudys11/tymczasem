from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [("core", "0010_employee_brigade_and_sap_label")]

    operations = [
        migrations.AddField(
            model_name="department",
            name="use_premiums",
            field=models.BooleanField(default=True, verbose_name="Obsługuje system premiowy"),
        ),
        migrations.AddField(
            model_name="month",
            name="use_premiums",
            field=models.BooleanField(default=True, verbose_name="Obsługuje system premiowy"),
        ),
    ]
