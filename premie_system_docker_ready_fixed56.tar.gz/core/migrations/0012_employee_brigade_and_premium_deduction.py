from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [('core', '0011_department_month_use_premiums')]

    operations = [
        migrations.AlterField(
            model_name='employee',
            name='brigade',
            field=models.CharField(blank=True, default='', max_length=20, verbose_name='Brygada'),
        ),
        migrations.AddField(
            model_name='employeenote',
            name='premium_deduction',
            field=models.DecimalField(decimal_places=2, default=0, max_digits=10, verbose_name='Umniejszenie premii bazowej (zł)'),
        ),
    ]
