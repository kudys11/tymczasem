from django.db import migrations, models


def create_default_settings(apps, schema_editor):
    SecuritySettings = apps.get_model('core', 'SecuritySettings')
    SecuritySettings.objects.get_or_create(pk=1, defaults={'default_password': 'Start123!'})


class Migration(migrations.Migration):
    dependencies = [('core', '0012_employee_brigade_and_premium_deduction')]

    operations = [
        migrations.CreateModel(
            name='SecuritySettings',
            fields=[
                ('id', models.PositiveSmallIntegerField(default=1, primary_key=True, serialize=False)),
                ('default_password', models.CharField(default='Start123!', max_length=128, verbose_name='Domyślne hasło nowych / resetowanych użytkowników')),
            ],
            options={
                'verbose_name': 'Ustawienia bezpieczeństwa',
                'verbose_name_plural': 'Ustawienia bezpieczeństwa',
            },
        ),
        migrations.AddField(
            model_name='profile',
            name='must_change_password',
            field=models.BooleanField(default=False, verbose_name='Wymuś zmianę hasła przy logowaniu'),
        ),
        migrations.RunPython(create_default_settings, migrations.RunPython.noop),
    ]
