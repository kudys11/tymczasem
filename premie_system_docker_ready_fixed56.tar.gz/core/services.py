from decimal import Decimal, ROUND_HALF_UP
from datetime import date, timedelta
import calendar
from .models import CalendarDay, CalendarEntry, Employee, EmployeeNote, PremiumResult, Holiday


def easter_sunday(year):
    a = year % 19; b = year // 100; c = year % 100
    d = b // 4; e = b % 4; f = (b + 8) // 25; g = (b - f + 1) // 3
    h = (19*a + b - d - g + 15) % 30; i = c // 4; k = c % 4
    l = (32 + 2*e + 2*i - h - k) % 7; m = (a + 11*h + 22*l) // 451
    month = (h + l - 7*m + 114) // 31; day = ((h + l - 7*m + 114) % 31) + 1
    return date(year, month, day)


def polish_holidays(year):
    easter = easter_sunday(year)
    fixed = {
        date(year,1,1): 'Nowy Rok', date(year,1,6): 'Święto Trzech Króli',
        date(year,5,1): 'Święto Pracy', date(year,5,3): 'Święto Konstytucji 3 Maja',
        date(year,8,15): 'Wniebowzięcie Najświętszej Maryi Panny',
        date(year,11,1): 'Wszystkich Świętych', date(year,11,11): 'Narodowe Święto Niepodległości',
        date(year,12,25): 'Boże Narodzenie (1. dzień)', date(year,12,26): 'Boże Narodzenie (2. dzień)',
    }
    if year >= 2025:
        fixed[date(year,12,24)] = 'Wigilia Bożego Narodzenia'
    movable = {easter + timedelta(days=1): 'Poniedziałek Wielkanocny', easter + timedelta(days=49): 'Zielone Świątki', easter + timedelta(days=60): 'Boże Ciało'}
    return {**fixed, **movable}


WEEKDAYS = ['poniedziałek','wtorek','środa','czwartek','piątek','sobota','niedziela']
WEEKDAYS_SHORT = ['Pn','Wt','Śr','Czw','Pt','Sob','Nd']


def seed_default_holidays(year):
    """Uzupełnia bazę o ustawowe polskie święta znane aplikacji.

    Administrator może później dodać dodatkowy dzień wolny w panelu.
    Dane są w bazie, więc zmiana listy nie wymaga przebudowy kontenera.
    """
    for holiday_date, name in polish_holidays(year).items():
        Holiday.objects.get_or_create(
            date=holiday_date,
            defaults={
                'name': name,
                'kind': 'HOLIDAY',
                'affects_working_days': True,
                'active': True,
            },
        )


def sync_calendar_days(year, month):
    seed_default_holidays(year)
    holiday_qs = Holiday.objects.filter(
        date__year=year, date__month=month, active=True
    )
    holidays = {h.date: h for h in holiday_qs}
    result = []
    for n in range(1, calendar.monthrange(year, month)[1] + 1):
        d = date(year, month, n)
        holiday = holidays.get(d)
        is_sunday = d.weekday() == 6
        is_saturday = d.weekday() == 5
        is_working = (
            d.weekday() < 5
            and not (holiday and holiday.affects_working_days)
        )
        label = holiday.name if holiday else (
            'Niedziela' if is_sunday else ('Sobota' if is_saturday else '')
        )
        CalendarDay.objects.update_or_create(
            date=d,
            defaults={'is_working': is_working, 'label': label},
        )
        result.append({
            'day': n,
            'date': d,
            'weekday': WEEKDAYS[d.weekday()],
            'weekday_short': WEEKDAYS_SHORT[d.weekday()],
            'is_working': is_working,
            'is_sunday': is_sunday,
            'is_holiday': bool(holiday),
            'is_day_off': bool(holiday and holiday.kind == 'DAY_OFF'),
            'label': label,
        })
    return result


def working_days(year, month):
    sync_calendar_days(year, month)
    return CalendarDay.objects.filter(date__year=year, date__month=month, is_working=True).count()


def calculate_month(m):
    wd = working_days(m.year, m.month); caldays = calendar.monthrange(m.year, m.month)[1]
    PremiumResult.objects.filter(month=m).delete()
    employees = Employee.objects.filter(department=m.department, active=True)
    for e in employees:
        granted = m.base_premium
        note = EmployeeNote.objects.filter(month=m, employee=e).first()
        manual_deduction = (note.premium_deduction if note else Decimal('0')).quantize(Decimal('0.01'), ROUND_HALF_UP)
        manual_deduction = max(Decimal('0'), manual_deduction)
        dw = Decimal('0'); dc = Decimal('0'); disqualified = False
        detail = {'base': str(granted), 'working_days': wd, 'calendar_days': caldays, 'premium_mode': e.premium_mode, 'codes': [], 'disqualified': False, 'manual_deduction': str(manual_deduction), 'manual_deduction_note': note.notes if note else ''}
        for ce in CalendarEntry.objects.filter(month=m, employee=e).select_related('code'):
            if not ce.code:
                continue
            if ce.code.disqualifies_premium:
                disqualified = True
            if ce.code.basis == 'WORKING': dw += Decimal('1')
            elif ce.code.basis == 'CALENDAR': dc += Decimal('1')
            detail['codes'].append({'date': str(ce.day), 'code': ce.code.code, 'basis': ce.code.basis, 'disqualifies_premium': ce.code.disqualifies_premium})
        detail['disqualified'] = disqualified
        if e.premium_mode == Employee.PREMIUM_PORTIER:
            deduction_working = Decimal('0'); deduction_calendar = Decimal('0'); payable = granted
            detail['reason'] = 'Portier — pełna premia bez umniejszeń.'
        elif disqualified:
            deduction_working = Decimal('0'); deduction_calendar = Decimal('0'); payable = Decimal('0.00')
            detail['reason'] = 'Wystąpił kod nieobecności dyskwalifikujący premię.'
        else:
            deduction_working = (granted/Decimal(wd)*dw) if wd else Decimal('0')
            deduction_calendar = granted/Decimal('30')*dc
            payable = max(Decimal('0'), granted-deduction_working-deduction_calendar-manual_deduction).quantize(Decimal('0.01'), ROUND_HALF_UP)
        if e.premium_mode == Employee.PREMIUM_PORTIER:
            manual_deduction = Decimal('0')
            detail['manual_deduction'] = '0.00'
            detail['manual_deduction_note'] = ''
        elif disqualified:
            manual_deduction = Decimal('0')
            detail['manual_deduction'] = '0.00'
            detail['manual_deduction_note'] = ''
        detail['manual_deduction'] = str(manual_deduction.quantize(Decimal('0.01'), ROUND_HALF_UP))
        PremiumResult.objects.create(month=m, employee=e, granted=granted, deduction_working=deduction_working.quantize(Decimal('0.01'), ROUND_HALF_UP), deduction_calendar=deduction_calendar.quantize(Decimal('0.01'), ROUND_HALF_UP), payable=payable.quantize(Decimal('0.01'), ROUND_HALF_UP), calculation_details=detail)
    rebuild_overtime_balances(m.department)
    m.status = 'CALC'; m.save(update_fields=['status'])


SAP_COMPARE_FIELDS = [
    ('overtime', 'Nadgodz/Godz.ujem.'),
    ('vacation', 'Urlop wypoczynkowy'),
    ('sick', 'choroba zwykła'),
    ('unpaid_absence', 'Nieob. nieuspr. niepłatna'),
    ('other_absence', 'Pozost. nieobecn.'),
]

def calendar_sap_comparison(month):
    """Porównanie SAP z kalendarzem; overtime pochodzi z ewidencji czasu."""
    from .models import SAPCalendarMapping, SAPRecord
    rules = list(SAPCalendarMapping.objects.filter(active=True).select_related('code'))
    by_code = {}
    configured = {field: False for field, _ in SAP_COMPARE_FIELDS}
    for rule in rules:
        by_code.setdefault(rule.code_id, []).append(rule)
        configured[rule.sap_field] = True
    sap = {x.personnel_no: x for x in SAPRecord.objects.filter(month=month)}
    employees = list(Employee.objects.filter(department=month.department, active=True).order_by('brigade', 'sort_order', 'last_name', 'first_name', 'id'))
    totals = {e.id: {field: Decimal('0') for field, _ in SAP_COMPARE_FIELDS} for e in employees}
    entries = CalendarEntry.objects.filter(month=month, employee__in=employees).select_related('code')
    for ce in entries:
        if not ce.code:
            continue
        for rule in by_code.get(ce.code_id, []):
            value = ce.hours or Decimal('0') if rule.aggregation == SAPCalendarMapping.SUM_HOURS else Decimal('1')
            totals[ce.employee_id][rule.sap_field] += value
    time_rows = month_time_rows(month)
    configured['overtime'] = True
    result = {}
    for e in employees:
        sr = sap.get(e.personnel_no)
        totals[e.id]['overtime'] = time_rows.get(e.id, {}).get('overtime', Decimal('0'))
        values = {}
        for field, label in SAP_COMPARE_FIELDS:
            sap_value = Decimal(str(getattr(sr, field))) if sr else Decimal('0')
            cal_value = totals[e.id][field]
            diff = (cal_value - sap_value).quantize(Decimal('0.01'), ROUND_HALF_UP)
            values[field] = {'label': label, 'sap': sap_value, 'calendar': cal_value, 'difference': diff, 'configured': configured[field], 'ok': configured[field] and diff == Decimal('0.00')}
        result[e.id] = values
    return result, configured

# --- Ewidencja czasu pracy ---
from datetime import datetime, time
from django.db.models import Min
from .models import Department, Month, OvertimeBalance

NIGHT_START = time(22, 0)
NIGHT_END = time(6, 0)


def _duration_minutes(start, end):
    if start is None or end is None:
        return 0
    a = start.hour * 60 + start.minute + start.second / 60
    b = end.hour * 60 + end.minute + end.second / 60
    if b <= a:
        b += 24 * 60
    return b - a


def _overlap_minutes(a, b, c, d):
    """Overlap of [a,b] and [c,d], on a single 24h axis."""
    return max(0, min(b, d) - max(a, c))


def shift_minutes_and_night(start, end):
    """Returns total and night minutes for a shift; night is always 22:00–06:00."""
    total = _duration_minutes(start, end)
    if not total:
        return 0, 0
    a = start.hour * 60 + start.minute + start.second / 60
    b = end.hour * 60 + end.minute + end.second / 60
    if b <= a:
        b += 1440
    # Noc obejmuje każdą minutę w przedziale 22:00–06:00, także 00:00–06:00
    # dla zmiany rozpoczynającej się np. o 04:00. Dla zmiany przez północ
    # oś czasu jest przesuwana o 24 h.
    night_windows = [(0, 6*60), (22*60, 24*60), (24*60, 30*60)]
    night = sum(_overlap_minutes(a, b, c, d) for c, d in night_windows)
    # A shift longer than 24h is not expected, but night must not exceed total.
    night = min(night, total)
    return round(total), round(night)


def entry_worked_hours_and_night(ce):
    if ce.start_time is not None and ce.end_time is not None:
        total, night = shift_minutes_and_night(ce.start_time, ce.end_time)
        return Decimal(total) / Decimal(60), Decimal(night) / Decimal(60)
    if ce.hours is not None:
        return ce.hours, Decimal('0')
    return Decimal('0'), Decimal('0')


def month_time_rows(m):
    """Calculate time data for all active employees in a month."""
    days = sync_calendar_days(m.year, m.month)
    working = sum(1 for d in days if d['is_working'])
    entries = CalendarEntry.objects.filter(month=m).select_related('code')
    by_emp = {}
    for ce in entries:
        by_emp.setdefault(ce.employee_id, []).append(ce)
    result = {}
    for e in Employee.objects.filter(department=m.department, active=True):
        worked = Decimal('0'); night = Decimal('0'); absence_days = Decimal('0'); leave = Decimal('0')
        for ce in by_emp.get(e.id, []):
            wh, nh = entry_worked_hours_and_night(ce)
            worked += wh; night += nh
            if ce.code and ce.code.basis == 'WORKING':
                absence_days += Decimal('1')
            if ce.overtime_leave_hours is not None:
                leave += max(Decimal('0'), ce.overtime_leave_hours)
        planned = max(Decimal('0'), Decimal(working * 8) - absence_days * Decimal('8'))
        overtime = (worked - planned).quantize(Decimal('0.01'), ROUND_HALF_UP)
        result[e.id] = {
            'worked_hours': worked.quantize(Decimal('0.01'), ROUND_HALF_UP),
            'night_hours': night.quantize(Decimal('0.01'), ROUND_HALF_UP),
            'planned_hours': planned.quantize(Decimal('0.01'), ROUND_HALF_UP),
            'overtime': overtime,
            'overtime_leave_hours': leave.quantize(Decimal('0.01'), ROUND_HALF_UP),
        }
    return result


def rebuild_overtime_balances(department):
    """Rebuilds the overtime ledger chronologically so balances carry to next months."""
    months = list(Month.objects.filter(department=department).order_by('year', 'month', 'id'))
    employees = list(Employee.objects.filter(department=department))
    previous = {e.id: Decimal('0') for e in employees}
    for m in months:
        rows = month_time_rows(m)
        for e in employees:
            row = rows.get(e.id, {'worked_hours': Decimal('0'), 'planned_hours': Decimal('0'), 'overtime': Decimal('0'), 'night_hours': Decimal('0'), 'overtime_leave_hours': Decimal('0')})
            carry = previous.get(e.id, Decimal('0'))
            # „Wolne za nadgodziny” jest czasem wolnym finansowanym z banku
            # nadgodzin. Nie może jednocześnie powodować podwójnego minusa:
            # np. 08:00–14:00 + 2 h wolnego przy planie 8 h oznacza 0 h
            # bieżącego niedoboru i zużycie 2 h z poprzedniego salda.
            # Bieżący ujemny bilans pozostawiamy w polu `overtime` jako informację
            # o faktycznie przepracowanym czasie, natomiast saldo banku liczymy
            # z uwzględnieniem wykorzystanego wolnego.
            requested_leave = max(Decimal('0'), row['overtime_leave_hours'])
            raw_overtime = row['overtime']
            # Wolne pokrywa najpierw bieżący niedobór godzin, ale jednocześnie
            # jest pobierane z banku nadgodzin. Dzięki temu 08:00–14:00 + 2 h
            # wolnego przy planie 8 h daje 0 h bieżącego salda, a z poprzednich
            # 3 h pozostaje 1 h. Nie odejmujemy tych samych 2 h dwa razy od
            # salda miesięcznego.
            covered_deficit = min(requested_leave, max(Decimal('0'), -raw_overtime))
            effective_overtime = raw_overtime + covered_deficit
            bank_available = max(Decimal('0'), carry + max(Decimal('0'), raw_overtime))
            bank_used = min(requested_leave, bank_available)
            closing = (carry + effective_overtime - bank_used).quantize(Decimal('0.01'), ROUND_HALF_UP)
            OvertimeBalance.objects.update_or_create(
                month=m, employee=e,
                defaults={
                    'carried_in': carry.quantize(Decimal('0.01'), ROUND_HALF_UP),
                    'worked_hours': row['worked_hours'], 'planned_hours': row['planned_hours'],
                    'overtime': row['overtime'], 'night_hours': row['night_hours'],
                    'overtime_leave_hours': bank_used.quantize(Decimal('0.01'), ROUND_HALF_UP), 'carried_out': closing,
                }
            )
            previous[e.id] = closing
    return rows if months else {}
