# Sprawozdanie Roczne FINAL 2.8.6c

Uruchom:

```bash
cd /opt/_docker-compose/wspolnota
unzip sprawozdanie_roczne_final_2_8_6c_v4.zip
chmod +x wdroz_sprawozdanie_roczne_final_2_8_6c.sh
./wdroz_sprawozdanie_roczne_final_2_8_6c.sh
```
