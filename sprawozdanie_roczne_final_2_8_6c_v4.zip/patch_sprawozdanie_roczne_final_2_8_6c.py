from pathlib import Path

p = Path("apps/audit/admin_annual_report.py")
txt = p.read_text(encoding="utf-8")

if "from django.utils import timezone" not in txt:
    txt = txt.replace(
        "from django.urls import path\n",
        "from django.urls import path\nfrom django.utils import timezone\n",
        1,
    )

# Dodatkowe wyliczenia windykacji
if "debt_effectiveness" not in txt:
    old = '''        if debt_open_cases:
            oldest = min(debt_open_cases, key=lambda x: x.created_at)
            debt_oldest_open_days = max(
                (report_date - oldest.created_at.date()).days,
                0
            )
'''
    new = old + '''        debt_completed_cases = [x for x in debt_cases if x.status in ("paid", "closed")]
        debt_effectiveness = "—"
        if debt_cases and debt_completed_cases:
            debt_effectiveness = f"{round(len(debt_completed_cases) * 100 / len(debt_cases), 1)}%"

        debt_avg_amount = Decimal("0.00")
        debt_max_amount = Decimal("0.00")
        if debt_cases:
            debt_avg_amount = sum((_dec(x.arrears_amount) for x in debt_cases), Decimal("0.00")) / len(debt_cases)
            debt_max_amount = max((_dec(x.arrears_amount) for x in debt_cases), default=Decimal("0.00"))
'''
    if old in txt:
        txt = txt.replace(old, new, 1)

    old = '''    except Exception:
        pass

    windykacja_section_html = f"""
'''
    new = '''    except Exception:
        debt_completed_cases = []
        debt_effectiveness = "—"
        debt_avg_amount = Decimal("0.00")
        debt_max_amount = Decimal("0.00")
        pass

    windykacja_section_html = f"""
'''
    if old in txt:
        txt = txt.replace(old, new, 1)

# Rozbudowa sekcji windykacja
if "Skuteczność windykacji" not in txt:
    txt = txt.replace(
'''          <tr><th>Kwota w windykacji</th><td class="minus">-{_money(debt_open_amount)}</td></tr>
          <tr><th>Najstarsza otwarta sprawa</th><td>{debt_oldest_open_days} dni</td></tr>
''',
'''          <tr><th>Kwota w windykacji</th><td class="minus">-{_money(debt_open_amount)}</td></tr>
          <tr><th>Najstarsza otwarta sprawa</th><td>{debt_oldest_open_days} dni</td></tr>
          <tr><th>Skuteczność windykacji</th><td>{debt_effectiveness}</td></tr>
          <tr><th>Średnia wartość sprawy</th><td>{_money(debt_avg_amount)}</td></tr>
          <tr><th>Najwyższa zaległość w sprawie</th><td class="minus">-{_money(debt_max_amount)}</td></tr>
''',
        1,
    )

# Ocena kondycji
if "condition_section_html" not in txt:
    marker = "    conclusions = [\n"
    insert = '''    # Ocena kondycji wspólnoty — 2.8.6c FINAL
    total_arrears_value = _dec(data.get("total_arrears"))
    bank_value = _dec(data.get("bank_total_estimated"))

    if bank_value > 0 and not invoice_overdue:
        liquidity_label = "Dobra"
        liquidity_class = "plus"
    elif bank_value >= 0:
        liquidity_label = "Umiarkowana"
        liquidity_class = "neutral"
    else:
        liquidity_label = "Wymaga uwagi"
        liquidity_class = "minus"

    if total_arrears_value == 0:
        finance_label = "Dobra"
        finance_class = "plus"
    elif total_arrears_value < Decimal("1000"):
        finance_label = "Umiarkowana"
        finance_class = "neutral"
    else:
        finance_label = "Wymaga kontroli"
        finance_class = "minus"

    if debt_open_cases:
        debt_label = "Aktywna"
        debt_class = "minus" if debt_overdue_cases else "neutral"
    else:
        debt_label = "Brak aktywnych spraw"
        debt_class = "plus"

    risk_points = 0
    if invoice_overdue:
        risk_points += 2
    if debt_overdue_cases:
        risk_points += 2
    if alert_counts["critical"]:
        risk_points += 2
    if total_arrears_value > 0:
        risk_points += 1

    if risk_points >= 4:
        risk_label = "Podwyższony"
        risk_class = "minus"
    elif risk_points >= 2:
        risk_label = "Umiarkowany"
        risk_class = "neutral"
    else:
        risk_label = "Niski"
        risk_class = "plus"

    condition_section_html = f"""
      <div class="section">
        <h2>9. Ocena kondycji wspólnoty</h2>
        <table>
          <tr><th>Kondycja finansowa</th><td class="{finance_class}">{finance_label}</td></tr>
          <tr><th>Płynność</th><td class="{liquidity_class}">{liquidity_label}</td></tr>
          <tr><th>Windykacja</th><td class="{debt_class}">{debt_label}</td></tr>
          <tr><th>Poziom ryzyka</th><td class="{risk_class}">{risk_label}</td></tr>
        </table>
      </div>
    """

'''
    if marker in txt:
        txt = txt.replace(marker, insert + marker, 1)

# Style
if ".cover{{" not in txt:
    txt = txt.replace(
'''        .conclusions li{{margin-bottom:8px}}
''',
'''        .conclusions li{{margin-bottom:8px}}
        .cover{{border:1px solid #dfe5ec;border-radius:12px;padding:32px;margin:16px 0 22px 0;text-align:center;background:#f8fafc}}
        .cover .title{{font-size:34px;font-weight:800;letter-spacing:.5px;margin-bottom:8px}}
        .cover .subtitle{{font-size:20px;color:#334155;margin-bottom:16px}}
        .cover .year{{font-size:18px;color:#64748b}}
        .report-footer{{border-top:1px solid #cbd5e1;margin-top:20px;padding-top:12px;color:#64748b;font-size:12px;text-align:center}}
''',
        1,
    )

# Kafelki KPI
old_grid = '''      <div class="grid">
        <div class="card">Lokale<strong>{data.get("apartments_count", 0)}</strong></div>
        <div class="card">Właściciele<strong>{data.get("owners_count", 0)}</strong></div>
        <div class="card">Saldo właścicieli<strong class="{_class(data.get("owners_balance_total"))}">{_signed(data.get("owners_balance_total"))}</strong></div>
        <div class="card">Środki na rachunkach<strong class="{_class(data.get("bank_total_estimated"))}">{_signed(data.get("bank_total_estimated"))}</strong></div>
      </div>
'''
new_grid = '''      <div class="grid">
        <div class="card">Lokale<strong>{data.get("apartments_count", 0)}</strong></div>
        <div class="card">Właściciele<strong>{data.get("owners_count", 0)}</strong></div>
        <div class="card">Saldo właścicieli<strong class="{_class(data.get("owners_balance_total"))}">{_signed(data.get("owners_balance_total"))}</strong></div>
        <div class="card">Środki na rachunkach<strong class="{_class(data.get("bank_total_estimated"))}">{_signed(data.get("bank_total_estimated"))}</strong></div>
        <div class="card">Sprawy windykacyjne<strong>{len(debt_cases)}</strong></div>
        <div class="card">Kwota w windykacji<strong class="minus">-{_money(debt_open_amount)}</strong></div>
        <div class="card">Alerty<strong>{alert_counts["critical"] + alert_counts["warning"] + alert_counts["info"]}</strong></div>
        <div class="card">Przeterminowane sprawy<strong class="minus">{len(debt_overdue_cases)}</strong></div>
      </div>
'''
if old_grid in txt:
    txt = txt.replace(old_grid, new_grid, 1)

# Okładka
if "SPRAWOZDANIE ROCZNE" not in txt:
    txt = txt.replace(
'''      </div>

      <div class="grid">
''',
'''      </div>

      <div class="cover">
        <div class="title">SPRAWOZDANIE ROCZNE</div>
        <div class="subtitle">{community.name}</div>
        <div class="year">Rok obrachunkowy {report_date.year} · stan na dzień {report_date}</div>
      </div>

      <div class="grid">
''',
        1,
    )

# Kolejność sekcji i stopka
old_order = '''      <div class="section conclusions">
        <h2>8. Wnioski końcowe</h2>
        <ul>{conclusions_html}</ul>
      </div>
      {windykacja_section_html}\\n    </body>
'''
new_order = '''      {windykacja_section_html}

      {condition_section_html}

      <div class="section conclusions">
        <h2>10. Wnioski końcowe</h2>
        <ul>{conclusions_html}</ul>
      </div>

      <div class="report-footer">
        Raport wygenerowany automatycznie przez System Zarządzania Wspólnotą<br>
        Wersja raportu: 2.8.6 FINAL · Data wygenerowania: {timezone.localtime().strftime("%Y-%m-%d %H:%M")}
      </div>
    </body>
'''
if old_order in txt:
    txt = txt.replace(old_order, new_order, 1)
else:
    txt = txt.replace('{windykacja_section_html}\\n    </body>', '{windykacja_section_html}\n\n      {condition_section_html}\n\n      <div class="report-footer">Raport wygenerowany automatycznie przez System Zarządzania Wspólnotą<br>Wersja raportu: 2.8.6 FINAL · Data wygenerowania: {timezone.localtime().strftime("%Y-%m-%d %H:%M")}</div>\n    </body>', 1)

p.write_text(txt, encoding="utf-8")
print("OK: Sprawozdanie Roczne FINAL 2.8.6c naniesione.")
