#!/usr/bin/env bash
set -euo pipefail

cd /opt/_docker-compose/wspolnota
mkdir -p _backup_sprawozdanie_2_8_6c
cp -f apps/audit/admin_annual_report.py _backup_sprawozdanie_2_8_6c/admin_annual_report.py.bak || true

python3 patch_sprawozdanie_roczne_final_2_8_6c.py

docker compose down
docker compose build --no-cache
docker compose up -d
sleep 15
docker compose exec web python manage.py check
docker compose exec web grep -n "SPRAWOZDANIE ROCZNE\|Ocena kondycji\|10. Wnioski\|Wersja raportu: 2.8.6 FINAL" /app/apps/audit/admin_annual_report.py

echo "GOTOWE: Sprawozdanie Roczne FINAL 2.8.6c."
