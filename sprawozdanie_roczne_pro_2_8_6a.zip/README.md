# Sprawozdanie Roczne PRO 2.8.6a

Dodaje do sprawozdania rocznego:
- sekcję Windykacja,
- liczbę spraw,
- sprawy otwarte,
- sprawy przeterminowane,
- sprawy spłacone i zamknięte,
- kwotę w windykacji,
- najstarszą otwartą sprawę,
- automatyczne wnioski zarządcze,
- link do Dashboardu windykacji.

Uruchom:

```bash
cd /opt/_docker-compose/wspolnota
unzip sprawozdanie_roczne_pro_2_8_6a.zip
chmod +x wdroz_sprawozdanie_roczne_pro_2_8_6a.sh
./wdroz_sprawozdanie_roczne_pro_2_8_6a.sh
```
