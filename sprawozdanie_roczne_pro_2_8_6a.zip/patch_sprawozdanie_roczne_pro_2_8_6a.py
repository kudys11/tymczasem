from pathlib import Path

p = Path("apps/audit/admin_annual_report.py")
txt = p.read_text(encoding="utf-8")

calc_marker = "    conclusions = ["
calc_insert = """
    # Windykacja — sekcja PRO 2.8.6a
    debt_cases = []
    debt_open_cases = []
    debt_overdue_cases = []
    debt_paid_cases = []
    debt_closed_cases = []
    debt_open_amount = Decimal("0.00")
    debt_oldest_open_days = 0

    try:
        from apps.audit.models import DebtCollectionCase

        debt_cases = list(
            DebtCollectionCase.objects
            .select_related("apartment", "person")
            .all()
        )

        debt_open_cases = [
            x for x in debt_cases
            if x.status in ("new", "demand_generated", "sent", "partially_paid")
        ]
        debt_paid_cases = [x for x in debt_cases if x.status == "paid"]
        debt_closed_cases = [x for x in debt_cases if x.status == "closed"]
        debt_overdue_cases = [
            x for x in debt_open_cases
            if x.payment_deadline and x.payment_deadline < report_date
        ]

        debt_open_amount = sum(
            (_dec(x.arrears_amount) for x in debt_open_cases),
            Decimal("0.00")
        )

        if debt_open_cases:
            oldest = min(debt_open_cases, key=lambda x: x.created_at)
            debt_oldest_open_days = max(
                (report_date - oldest.created_at.date()).days,
                0
            )
    except Exception:
        pass

    windykacja_section_html = f\"\"\"
      <div class="section">
        <h2>5. Windykacja</h2>
        <table>
          <tr><th>Liczba spraw windykacyjnych</th><td>{len(debt_cases)}</td></tr>
          <tr><th>Sprawy otwarte</th><td class="minus">{len(debt_open_cases)}</td></tr>
          <tr><th>Sprawy przeterminowane</th><td class="minus">{len(debt_overdue_cases)}</td></tr>
          <tr><th>Sprawy spłacone</th><td class="plus">{len(debt_paid_cases)}</td></tr>
          <tr><th>Sprawy zamknięte</th><td class="plus">{len(debt_closed_cases)}</td></tr>
          <tr><th>Kwota w windykacji</th><td class="minus">-{_money(debt_open_amount)}</td></tr>
          <tr><th>Najstarsza otwarta sprawa</th><td>{debt_oldest_open_days} dni</td></tr>
        </table>
      </div>
    \"\"\"

"""

if "Windykacja — sekcja PRO 2.8.6a" not in txt:
    if calc_marker not in txt:
        raise SystemExit("BŁĄD: nie znaleziono miejsca przed conclusions.")
    txt = txt.replace(calc_marker, calc_insert + calc_marker, 1)
    print("OK: dodano obliczenia windykacji.")
else:
    print("OK: obliczenia windykacji już istnieją.")

concl_marker = '    conclusions_html = "".join(f"<li>{x}</li>" for x in conclusions)'
concl_insert = """
    if debt_open_cases:
        conclusions.append(
            f"W toku pozostaje {len(debt_open_cases)} spraw windykacyjnych na kwotę {_money(debt_open_amount)}."
        )
    else:
        conclusions.append("Na dzień raportu nie występują otwarte sprawy windykacyjne.")

    if debt_overdue_cases:
        conclusions.append(
            f"Występują przeterminowane sprawy windykacyjne: {len(debt_overdue_cases)}."
        )

    if debt_paid_cases or debt_closed_cases:
        conclusions.append(
            f"Zakończono {len(debt_paid_cases) + len(debt_closed_cases)} spraw windykacyjnych."
        )

"""
if "Na dzień raportu nie występują otwarte sprawy windykacyjne" not in txt:
    if concl_marker not in txt:
        raise SystemExit("BŁĄD: nie znaleziono conclusions_html.")
    txt = txt.replace(concl_marker, concl_insert + concl_marker, 1)
    print("OK: dodano wnioski windykacyjne.")
else:
    print("OK: wnioski windykacyjne już istnieją.")

if "{windykacja_section_html}" not in txt:
    markers = [
        '<div class="section">\\n        <h2>7. Wnioski',
        '<div class="section">\\n        <h2>6. Wnioski',
        '<div class="section">\\n        <h2>Wnioski',
        '<div class="section">\\n        <h2>Podsumowanie',
    ]
    done = False
    for m in markers:
        if m in txt:
            txt = txt.replace(m, "{windykacja_section_html}\\n\\n      " + m, 1)
            done = True
            print("OK: sekcja Windykacja wstawiona przed wnioskami.")
            break
    if not done:
        txt = txt.replace("    </body>", "      {windykacja_section_html}\\n    </body>", 1)
        print("OK: sekcja Windykacja wstawiona fallback przed końcem body.")
else:
    print("OK: sekcja Windykacja już jest w HTML.")

if "/admin/raporty/windykacja-final/" not in txt:
    marker = '<a href="/admin/raporty/rozliczenia-mediow/?date={report_date}" target="_blank" rel="noopener">Rozliczenia mediów ↗</a>'
    if marker in txt:
        txt = txt.replace(
            marker,
            marker + '\\n        <a href="/admin/raporty/windykacja-final/?date={report_date}" target="_blank" rel="noopener">Dashboard windykacji ↗</a>',
            1
        )
        print("OK: dodano link Dashboard windykacji.")
    else:
        print("UWAGA: nie znaleziono miejsca na link Dashboard windykacji.")
else:
    print("OK: link Dashboard windykacji już istnieje.")

p.write_text(txt, encoding="utf-8")
print("OK: Sprawozdanie Roczne PRO 2.8.6a naniesione.")
