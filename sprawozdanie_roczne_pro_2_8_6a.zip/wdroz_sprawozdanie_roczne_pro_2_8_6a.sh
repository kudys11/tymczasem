#!/usr/bin/env bash
set -euo pipefail

cd /opt/_docker-compose/wspolnota

echo "== Backup =="
mkdir -p _backup_sprawozdanie_2_8_6a
cp -f apps/audit/admin_annual_report.py _backup_sprawozdanie_2_8_6a/admin_annual_report.py.bak || true

echo "== Patch =="
python3 patch_sprawozdanie_roczne_pro_2_8_6a.py

echo "== Rebuild =="
docker compose down
docker compose build --no-cache
docker compose up -d

echo "== Czekam na start =="
sleep 15

echo "== Check =="
docker compose exec web python manage.py check

echo "== Kontrola =="
docker compose exec web grep -n "Windykacja — sekcja PRO 2.8.6a\|5. Windykacja\|Dashboard windykacji" /app/apps/audit/admin_annual_report.py

echo "GOTOWE: Sprawozdanie Roczne PRO 2.8.6a."
