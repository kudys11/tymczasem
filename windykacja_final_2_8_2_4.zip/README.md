# Windykacja final 2.8.2-2.8.4

Uruchom:

```bash
cd /opt/_docker-compose/wspolnota
unzip windykacja_final_2_8_2_4.zip
chmod +x wdroz_2_8_2_4_windykacja_final.sh
./wdroz_2_8_2_4_windykacja_final.sh
```

Widok:
`/admin/raporty/rejestr-windykacji/`
