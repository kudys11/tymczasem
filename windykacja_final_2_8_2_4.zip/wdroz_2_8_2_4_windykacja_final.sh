#!/usr/bin/env bash
set -euo pipefail

cd /opt/_docker-compose/wspolnota

mkdir -p _backup_windykacja_2_8_2_4
cp -f apps/audit/admin.py _backup_windykacja_2_8_2_4/admin.py.bak || true
cp -f apps/audit/admin_reports_center.py _backup_windykacja_2_8_2_4/admin_reports_center.py.bak || true
cp -f apps/audit/admin_debt_collection_register.py _backup_windykacja_2_8_2_4/admin_debt_collection_register.py.bak 2>/dev/null || true

cat > apps/audit/admin_debt_collection_register.py <<'PY'
from datetime import date, datetime
from decimal import Decimal

from django.contrib import admin
from django.http import HttpResponse
from django.urls import path
from django.utils import timezone


OPEN_STATUSES = ("new", "demand_generated", "sent", "partially_paid")
CLOSED_STATUSES = ("paid", "closed", "cancelled")


def _parse_date(request):
    today = date.today()
    raw = request.GET.get("date") or f"{today.year}-12-31"
    try:
        return datetime.strptime(raw, "%Y-%m-%d").date()
    except ValueError:
        return today


def _money(value):
    return f"{Decimal(value or 0):.2f} zł".replace(".", ",")


def _abs_money(value):
    return f"{abs(Decimal(value or 0)):.2f} zł".replace(".", ",")


def _is_overdue(case, today=None):
    today = today or timezone.localdate()
    return bool(case.status not in CLOSED_STATUSES and case.payment_deadline and case.payment_deadline < today)


def _history_html(notes):
    notes = (notes or "").strip()
    if not notes:
        return '<span class="muted">Brak wpisów</span>'
    lines = [x.strip() for x in notes.splitlines() if x.strip()]
    items = "".join(f"<li>{line}</li>" for line in lines[-12:])
    return f"<details><summary>Historia</summary><ul class='history'>{items}</ul></details>"


def _status_badge(case):
    cls = {
        "new": "info",
        "demand_generated": "warn",
        "sent": "warn",
        "partially_paid": "warn",
        "paid": "ok",
        "closed": "ok",
        "cancelled": "mutedb",
    }.get(case.status, "info")
    overdue = '<span class="badge bad">Po terminie</span>' if _is_overdue(case) else ""
    return f'<span class="badge {cls}">{case.get_status_display()}</span> {overdue}'


def _priority_badge(case):
    cls = {"critical": "bad", "high": "warn", "standard": "info"}.get(case.priority, "info")
    return f'<span class="badge {cls}">{case.get_priority_display()}</span>'


def debt_collection_register_view(request):
    report_date = _parse_date(request)
    status_filter = request.GET.get("status") or "open"
    priority_filter = request.GET.get("priority") or "all"
    overdue_only = request.GET.get("overdue") == "1"
    today = timezone.localdate()

    try:
        from apps.audit.models import DebtCollectionCase
        qs = DebtCollectionCase.objects.select_related("community", "apartment", "person").order_by("-created_at", "-id")

        if status_filter == "open":
            qs = qs.exclude(status__in=CLOSED_STATUSES)
        elif status_filter == "overdue":
            qs = qs.exclude(status__in=CLOSED_STATUSES).filter(payment_deadline__lt=today)
        elif status_filter != "all":
            qs = qs.filter(status=status_filter)

        if priority_filter != "all":
            qs = qs.filter(priority=priority_filter)

        if overdue_only:
            qs = qs.exclude(status__in=CLOSED_STATUSES).filter(payment_deadline__lt=today)

        rows = list(qs)
        all_cases = list(DebtCollectionCase.objects.all())
    except Exception:
        rows = []
        all_cases = []

    open_cases = [x for x in all_cases if x.status in OPEN_STATUSES]
    overdue_cases = [x for x in open_cases if _is_overdue(x, today)]
    paid_cases = [x for x in all_cases if x.status == "paid"]
    closed_cases = [x for x in all_cases if x.status in ("closed", "paid")]
    open_amount = sum((x.arrears_amount for x in open_cases), Decimal("0.00"))
    all_amount = sum((x.arrears_amount for x in all_cases), Decimal("0.00"))

    effectiveness = 0
    if all_cases:
        effectiveness = round((len(paid_cases) + len([x for x in all_cases if x.status == "closed"])) * 100 / len(all_cases), 1)

    avg_close_days = "-"
    closed_with_dates = [x for x in all_cases if x.closed_at and x.created_at]
    if closed_with_dates:
        days = [(x.closed_at.date() - x.created_at.date()).days for x in closed_with_dates]
        avg_close_days = f"{round(sum(days) / len(days), 1)} dni"

    oldest_open_days = 0
    if open_cases:
        oldest = min(open_cases, key=lambda x: x.created_at)
        oldest_open_days = max((today - oldest.created_at.date()).days, 0)

    def selected(current, value):
        return "selected" if current == value else ""

    body = ""
    for index, x in enumerate(rows, 1):
        body += f"""
        <tr>
          <td>{index}</td>
          <td><strong>{x.case_number or '-'}</strong></td>
          <td>{x.apartment}</td>
          <td>{x.person or '-'}</td>
          <td class="minus">-{_abs_money(x.arrears_amount)}</td>
          <td>{_priority_badge(x)}</td>
          <td>{_status_badge(x)}</td>
          <td>{x.created_at.date() if x.created_at else '-'}</td>
          <td>{x.demand_sent_date or '-'}</td>
          <td>{x.payment_deadline or '-'}</td>
          <td>{_history_html(x.notes)}</td>
          <td class="actions-cell">
            <a href="/admin/audit/debtcollectioncase/{x.id}/change/" target="_blank" rel="noopener">Edycja ↗</a>
            <a href="/admin/raporty/kartoteka-lokalu/{x.apartment_id}/?date={x.report_date}" target="_blank" rel="noopener">Kartoteka ↗</a>
            <a href="/admin/raporty/wezwanie-do-zaplaty/{x.apartment_id}/?date={x.report_date}" target="_blank" rel="noopener">Wezwanie ↗</a>
            <a href="/admin/raporty/sprawy-windykacyjne/?status={x.status}" target="_blank" rel="noopener">Workflow ↗</a>
          </td>
        </tr>
        """

    if not body:
        body = "<tr><td colspan='12'>Brak spraw windykacyjnych dla wybranych filtrów.</td></tr>"

    html = f"""
    <!doctype html>
    <html lang="pl">
    <head>
      <meta charset="utf-8">
      <title>Rejestr windykacji</title>
      <style>
        body{{font-family:Arial,sans-serif;padding:18px;color:#0f172a;background:#fff}}
        .topbar{{display:flex;justify-content:space-between;gap:16px;align-items:flex-start}}
        h1{{margin:0 0 4px 0;font-size:32px}} h2{{margin-top:22px}}
        .muted{{color:#64748b}}
        .date-box{{border:1px solid #dfe5ec;padding:12px;border-radius:8px;background:#f8fafc}}
        .filters{{display:flex;gap:8px;flex-wrap:wrap;align-items:end}}
        .filters label{{display:flex;flex-direction:column;font-size:12px;color:#64748b}}
        input,select{{padding:8px 10px}} button{{padding:9px 14px;cursor:pointer}}
        .links{{display:flex;gap:8px;flex-wrap:wrap;margin:14px 0}}
        .links a, td a{{display:inline-block;border:1px solid #cbd5e1;padding:7px 10px;border-radius:6px;text-decoration:none;color:#0f172a;background:#fff}}
        .grid{{display:grid;grid-template-columns:repeat(6,minmax(150px,1fr));gap:12px;margin:16px 0}}
        .card{{border:1px solid #dfe5ec;border-radius:10px;padding:14px;background:#fff;box-shadow:0 1px 2px rgba(15,23,42,.04)}}
        .card strong{{display:block;font-size:22px;margin-top:6px}}
        table{{width:100%;border-collapse:collapse;margin-top:12px}}
        th,td{{border:1px solid #dfe5ec;padding:8px 10px;text-align:left;vertical-align:top}}
        th{{background:#f1f5f9}}
        .minus{{color:#dc2626;font-weight:700}} .plus{{color:#0a8f3c;font-weight:700}}
        .badge{{display:inline-block;border-radius:999px;padding:4px 9px;font-weight:700;font-size:12px;margin:1px}}
        .bad{{background:#fef2f2;color:#dc2626;border:1px solid #fecaca}}
        .warn{{background:#fffbeb;color:#ca8a04;border:1px solid #fde68a}}
        .ok{{background:#ecfdf5;color:#0a8f3c;border:1px solid #bbf7d0}}
        .info{{background:#eff6ff;color:#2563eb;border:1px solid #bfdbfe}}
        .mutedb{{background:#f1f5f9;color:#64748b;border:1px solid #cbd5e1}}
        .history{{margin:8px 0 0 16px;padding:0;color:#334155;font-size:12px}}
        .actions-cell a{{margin:2px;font-size:12px}}
        .note{{color:#64748b;margin-top:12px;font-size:13px}}
        @media (max-width:1200px){{.grid{{grid-template-columns:repeat(3,1fr)}} .topbar{{display:block}} .date-box{{margin-top:12px}}}}
        @media print{{.date-box,.links,td a{{display:none}} @page{{size:A4 landscape;margin:8mm}} body{{font-size:8px;padding:0}} h1{{font-size:18px}} th,td{{padding:3px 4px}} .grid{{grid-template-columns:repeat(3,1fr)}} details summary{{display:none}} details{{display:block}}}}
      </style>
    </head>
    <body>
      <div class="topbar">
        <div>
          <h1>📁 Rejestr windykacji</h1>
          <div class="muted">Sprawy windykacyjne, statusy, terminy, historia i skuteczność</div>
        </div>
        <form class="date-box" method="get">
          <div class="filters">
            <label>Data raportu
              <input type="date" name="date" value="{report_date}">
            </label>
            <label>Status
              <select name="status">
                <option value="open" {selected(status_filter, "open")}>Otwarte</option>
                <option value="overdue" {selected(status_filter, "overdue")}>Przeterminowane</option>
                <option value="all" {selected(status_filter, "all")}>Wszystkie</option>
                <option value="new" {selected(status_filter, "new")}>Nowe</option>
                <option value="demand_generated" {selected(status_filter, "demand_generated")}>Wezwanie wygenerowane</option>
                <option value="sent" {selected(status_filter, "sent")}>Wysłane</option>
                <option value="partially_paid" {selected(status_filter, "partially_paid")}>Częściowo spłacone</option>
                <option value="paid" {selected(status_filter, "paid")}>Spłacone</option>
                <option value="closed" {selected(status_filter, "closed")}>Zamknięte</option>
                <option value="cancelled" {selected(status_filter, "cancelled")}>Anulowane</option>
              </select>
            </label>
            <label>Priorytet
              <select name="priority">
                <option value="all" {selected(priority_filter, "all")}>Wszystkie</option>
                <option value="critical" {selected(priority_filter, "critical")}>Krytyczny</option>
                <option value="high" {selected(priority_filter, "high")}>Wysoki</option>
                <option value="standard" {selected(priority_filter, "standard")}>Standard</option>
              </select>
            </label>
            <label style="padding-top:19px;">
              <span><input type="checkbox" name="overdue" value="1" {"checked" if overdue_only else ""}> tylko po terminie</span>
            </label>
            <button type="submit">Pokaż</button>
          </div>
        </form>
      </div>

      <div class="links">
        <a href="/admin/raporty/?date={report_date}" target="_blank" rel="noopener">Dashboard Zarządcy ↗</a>
        <a href="/admin/raporty/sprawy-windykacyjne/?date={report_date}" target="_blank" rel="noopener">Workflow spraw ↗</a>
        <a href="/admin/raporty/wezwania-do-zaplaty/?date={report_date}" target="_blank" rel="noopener">Wezwania do zapłaty ↗</a>
        <a href="/admin/audit/debtcollectioncase/" target="_blank" rel="noopener">Admin spraw ↗</a>
        <a href="#" onclick="window.print(); return false;">PDF listy</a>
      </div>

      <div class="grid">
        <div class="card">Wszystkie sprawy<strong>{len(all_cases)}</strong></div>
        <div class="card">Otwarte<strong class="minus">{len(open_cases)}</strong></div>
        <div class="card">Przeterminowane<strong class="minus">{len(overdue_cases)}</strong></div>
        <div class="card">Spłacone<strong class="plus">{len(paid_cases)}</strong></div>
        <div class="card">Zamknięte<strong class="plus">{len(closed_cases)}</strong></div>
        <div class="card">Skuteczność<strong>{effectiveness}%</strong></div>
      </div>

      <div class="grid">
        <div class="card">Kwota otwarta<strong class="minus">-{_money(open_amount)}</strong></div>
        <div class="card">Kwota wszystkich spraw<strong class="minus">-{_money(all_amount)}</strong></div>
        <div class="card">Najstarsza otwarta<strong>{oldest_open_days} dni</strong></div>
        <div class="card">Średni czas zamknięcia<strong>{avg_close_days}</strong></div>
        <div class="card">Wynik filtrowania<strong>{len(rows)}</strong></div>
        <div class="card">Data raportu<strong>{report_date}</strong></div>
      </div>

      <h2>Lista spraw</h2>
      <table>
        <tr>
          <th>#</th><th>Numer</th><th>Lokal</th><th>Właściciel</th><th>Kwota</th><th>Priorytet</th>
          <th>Status</th><th>Utworzono</th><th>Wysłano</th><th>Termin</th><th>Historia</th><th>Akcje</th>
        </tr>
        {body}
      </table>

      <p class="note">Raport korzysta z modelu DebtCollectionCase. Historia bazuje na polu notes, bez dodatkowych migracji.</p>
    </body>
    </html>
    """
    return HttpResponse(html)


_original_get_urls_debt_register = admin.site.get_urls


def get_urls_debt_register():
    urls = _original_get_urls_debt_register()
    custom = [
        path("raporty/rejestr-windykacji/", admin.site.admin_view(debt_collection_register_view), name="debt_collection_register"),
    ]
    return custom + urls


if not getattr(admin.site, "_debt_collection_register_patched", False):
    admin.site.get_urls = get_urls_debt_register
    admin.site._debt_collection_register_patched = True
PY

python3 - <<'PY'
from pathlib import Path

p = Path("apps/audit/admin.py")
txt = p.read_text(encoding="utf-8")
line = "from . import admin_debt_collection_register  # noqa"
if line not in txt:
    txt = txt.rstrip() + "\n\n# Etap 2.8.2-2.8.4 - rejestr windykacji\n" + line + "\n"
    p.write_text(txt, encoding="utf-8")
    print("OK: dodano import")
else:
    print("OK: import już istnieje")
PY

python3 - <<'PY'
from pathlib import Path

p = Path("apps/audit/admin_reports_center.py")
txt = p.read_text(encoding="utf-8")

if "/admin/raporty/rejestr-windykacji/" not in txt:
    marker = '<a href="/admin/raporty/wezwania-do-zaplaty/?date={default_date}" target="_blank" rel="noopener">Otwórz raport ↗</a>'
    replacement = marker + '\n        <a href="/admin/raporty/rejestr-windykacji/?date={default_date}" target="_blank" rel="noopener">Rejestr windykacji ↗</a>'
    if marker in txt:
        txt = txt.replace(marker, replacement, 1)
        print("OK: dodano link Rejestr windykacji")
    else:
        print("UWAGA: nie znaleziono markera kafelka Wezwania")
else:
    print("OK: link już istnieje")

p.write_text(txt, encoding="utf-8")
PY

docker compose down
docker compose build --no-cache
docker compose up -d
sleep 15
docker compose exec web python manage.py check
docker compose exec web python manage.py shell -c "from django.urls import reverse; print(reverse('admin:debt_collection_register'))"
