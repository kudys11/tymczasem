# Windykacja 2.8.5 FINAL

Dodaje:
- Dashboard windykacji
- Masowe tworzenie spraw
- Automatyczne zamykanie spłaconych spraw
- Statystyki prezentacyjne

Uruchom:

```bash
cd /opt/_docker-compose/wspolnota
unzip windykacja_final_2_8_5.zip
chmod +x wdroz_2_8_5_windykacja_final.sh
./wdroz_2_8_5_windykacja_final.sh
```

Widok:
`/admin/raporty/windykacja-final/`
