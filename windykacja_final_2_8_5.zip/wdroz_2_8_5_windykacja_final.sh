#!/usr/bin/env bash
set -euo pipefail

cd /opt/_docker-compose/wspolnota

echo "== Backup =="
mkdir -p _backup_windykacja_2_8_5
cp -f apps/audit/admin.py _backup_windykacja_2_8_5/admin.py.bak || true
cp -f apps/audit/admin_reports_center.py _backup_windykacja_2_8_5/admin_reports_center.py.bak || true
cp -f apps/audit/admin_debt_collection_final.py _backup_windykacja_2_8_5/admin_debt_collection_final.py.bak 2>/dev/null || true

echo "== Tworzę moduł: Windykacja FINAL 2.8.5 =="
cat > apps/audit/admin_debt_collection_final.py <<'PY'
from datetime import date, datetime, timedelta
from decimal import Decimal

from django.contrib import admin
from django.http import HttpResponse
from django.shortcuts import redirect
from django.urls import path
from django.utils import timezone

OPEN_STATUSES = ("new", "demand_generated", "sent", "partially_paid")
CLOSED_STATUSES = ("paid", "closed", "cancelled")


def _parse_date(request):
    today = date.today()
    raw = request.GET.get("date") or f"{today.year}-12-31"
    try:
        return datetime.strptime(raw, "%Y-%m-%d").date()
    except ValueError:
        return today


def _dec(value):
    return Decimal(value or 0)


def _money(value):
    return f"{Decimal(value or 0):.2f} zł".replace(".", ",")


def _settings():
    try:
        from apps.audit.models import DebtCollectionSettings
        obj = DebtCollectionSettings.objects.filter(is_active=True).order_by("-updated_at", "-id").first()
        if obj:
            return obj
    except Exception:
        pass

    class DefaultSettings:
        threshold_amount = Decimal("300")
        high_priority_amount = Decimal("500")
        critical_priority_amount = Decimal("1000")
        payment_deadline_days = 7

    return DefaultSettings()


def _priority(amount, settings):
    amount = abs(_dec(amount))
    if amount >= _dec(settings.critical_priority_amount):
        return "critical"
    if amount >= _dec(settings.high_priority_amount):
        return "high"
    return "standard"


def _is_overdue(case, today=None):
    today = today or timezone.localdate()
    return bool(case.status not in CLOSED_STATUSES and case.payment_deadline and case.payment_deadline < today)


def _add_note(case, text):
    now = timezone.now()
    case.notes = (case.notes or "") + f"\n[{now:%Y-%m-%d %H:%M}] {text}"


def bulk_create_cases_view(request):
    report_date = _parse_date(request)
    settings = _settings()
    threshold = _dec(request.GET.get("threshold") or settings.threshold_amount)
    created = 0
    skipped_existing = 0
    skipped_below = 0
    errors = []

    try:
        from apps.communities.models import Apartment
        from apps.audit.models import DebtCollectionCase
        from apps.finance.annual_summary import apartment_balance_until, apartment_owner

        apartments = Apartment.objects.filter(is_active=True).select_related("community").order_by("id")

        for apt in apartments:
            try:
                balance = _dec(apartment_balance_until(apt, report_date))
                if balance >= 0 or abs(balance) < threshold:
                    skipped_below += 1
                    continue

                existing = DebtCollectionCase.objects.filter(
                    apartment=apt,
                    status__in=OPEN_STATUSES,
                ).order_by("-created_at").first()

                if existing:
                    skipped_existing += 1
                    continue

                owner = apartment_owner(apt)
                amount = abs(balance)

                case = DebtCollectionCase.objects.create(
                    community=apt.community,
                    apartment=apt,
                    person=owner,
                    arrears_amount=amount,
                    report_date=report_date,
                    priority=_priority(amount, settings),
                    status="new",
                    payment_deadline=report_date + timedelta(days=int(settings.payment_deadline_days or 7)),
                    notes=f"[{timezone.now():%Y-%m-%d %H:%M}] Utworzono sprawę windykacyjną zbiorczo. Próg: {_money(threshold)}.",
                )
                created += 1
            except Exception as exc:
                errors.append(f"{apt}: {exc}")

    except Exception as exc:
        return HttpResponse(f"Nie udało się utworzyć spraw zbiorczo: {exc}", status=500)

    msg = (
        f"Utworzono spraw: {created}<br>"
        f"Pominięto istniejące: {skipped_existing}<br>"
        f"Pominięto poniżej progu / bez zaległości: {skipped_below}<br>"
    )
    if errors:
        msg += "<br><strong>Błędy:</strong><br>" + "<br>".join(errors[:20])

    return HttpResponse(f"""
    <html><head><meta charset="utf-8"><title>Masowa windykacja</title></head>
    <body style="font-family:Arial;padding:24px">
      <h1>📨 Masowe tworzenie spraw</h1>
      <p>{msg}</p>
      <p>
        <a href="/admin/raporty/rejestr-windykacji/?date={report_date}">Rejestr windykacji</a> |
        <a href="/admin/raporty/windykacja-final/?date={report_date}">Dashboard windykacji</a>
      </p>
    </body></html>
    """)


def auto_close_cases_view(request):
    report_date = _parse_date(request)
    closed = 0
    checked = 0
    errors = []

    try:
        from apps.audit.models import DebtCollectionCase
        from apps.finance.annual_summary import apartment_balance_until

        cases = DebtCollectionCase.objects.filter(status__in=OPEN_STATUSES).select_related("apartment")
        for case in cases:
            checked += 1
            try:
                balance = _dec(apartment_balance_until(case.apartment, report_date))
                if balance >= 0:
                    case.status = "closed"
                    if not case.closed_at:
                        case.closed_at = timezone.now()
                    _add_note(case, f"Automatycznie zamknięto sprawę — saldo lokalu na dzień {report_date}: {_money(balance)}.")
                    case.save()
                    closed += 1
            except Exception as exc:
                errors.append(f"{case}: {exc}")

    except Exception as exc:
        return HttpResponse(f"Nie udało się wykonać automatycznego zamknięcia: {exc}", status=500)

    msg = f"Sprawdzono: {checked}<br>Zamknięto: {closed}<br>"
    if errors:
        msg += "<br><strong>Błędy:</strong><br>" + "<br>".join(errors[:20])

    return HttpResponse(f"""
    <html><head><meta charset="utf-8"><title>Auto-zamykanie windykacji</title></head>
    <body style="font-family:Arial;padding:24px">
      <h1>✅ Automatyczne zamykanie spraw</h1>
      <p>{msg}</p>
      <p>
        <a href="/admin/raporty/rejestr-windykacji/?date={report_date}">Rejestr windykacji</a> |
        <a href="/admin/raporty/windykacja-final/?date={report_date}">Dashboard windykacji</a>
      </p>
    </body></html>
    """)


def debt_collection_final_dashboard_view(request):
    report_date = _parse_date(request)
    settings = _settings()
    threshold = _dec(request.GET.get("threshold") or settings.threshold_amount)
    today_for_age = report_date

    try:
        from apps.audit.models import DebtCollectionCase
        cases = list(DebtCollectionCase.objects.select_related("apartment", "person").all())
    except Exception:
        cases = []

    open_cases = [x for x in cases if x.status in OPEN_STATUSES]
    overdue_cases = [x for x in open_cases if _is_overdue(x, report_date)]
    paid_cases = [x for x in cases if x.status == "paid"]
    closed_cases = [x for x in cases if x.status == "closed"]
    completed_cases = [x for x in cases if x.status in ("paid", "closed")]
    open_amount = sum((x.arrears_amount for x in open_cases), Decimal("0.00"))
    recovered_amount = sum((x.arrears_amount for x in completed_cases), Decimal("0.00"))

    effectiveness = "—"
    if cases and completed_cases:
        effectiveness = f"{round(len(completed_cases) * 100 / len(cases), 1)}%"

    oldest_open_days = 0
    if open_cases:
        oldest = min(open_cases, key=lambda x: x.created_at)
        oldest_open_days = max((today_for_age - oldest.created_at.date()).days, 0)

    avg_close_days = "—"
    closed_with_dates = [x for x in completed_cases if x.closed_at and x.created_at]
    if closed_with_dates:
        days = [(x.closed_at.date() - x.created_at.date()).days for x in closed_with_dates]
        avg_close_days = f"{round(sum(days) / len(days), 1)} dni"

    html = f"""
    <!doctype html>
    <html lang="pl">
    <head>
      <meta charset="utf-8">
      <title>Dashboard windykacji</title>
      <style>
        body{{font-family:Arial,sans-serif;padding:18px;color:#0f172a;background:#fff}}
        .topbar{{display:flex;justify-content:space-between;gap:16px;align-items:flex-start}}
        h1{{margin:0 0 4px 0;font-size:32px}} .muted{{color:#64748b}}
        .box{{border:1px solid #dfe5ec;padding:12px;border-radius:8px;background:#f8fafc}}
        .filters{{display:flex;gap:8px;flex-wrap:wrap;align-items:end}}
        .filters label{{display:flex;flex-direction:column;font-size:12px;color:#64748b}}
        input{{padding:8px 10px}} button{{padding:9px 14px;cursor:pointer}}
        .links{{display:flex;gap:8px;flex-wrap:wrap;margin:14px 0}}
        .links a{{display:inline-block;border:1px solid #cbd5e1;padding:8px 12px;border-radius:6px;text-decoration:none;color:#0f172a;background:#fff;font-weight:600}}
        .grid{{display:grid;grid-template-columns:repeat(4,minmax(180px,1fr));gap:12px;margin:16px 0}}
        .card{{border:1px solid #dfe5ec;border-radius:10px;padding:15px;background:#fff;box-shadow:0 1px 2px rgba(15,23,42,.04)}}
        .card strong{{display:block;font-size:26px;margin-top:6px}}
        .minus{{color:#dc2626}} .plus{{color:#0a8f3c}} .warn{{color:#ca8a04}}
        .panel{{border:1px solid #dfe5ec;border-radius:10px;padding:16px;margin-top:16px;background:#fff}}
        .danger{{border-color:#fecaca;background:#fef2f2}}
        .ok{{border-color:#bbf7d0;background:#ecfdf5}}
        .note{{color:#64748b;margin-top:12px;font-size:13px}}
        @media(max-width:1000px){{.grid{{grid-template-columns:repeat(2,1fr)}} .topbar{{display:block}} .box{{margin-top:12px}}}}
        @media print{{.box,.links,.panel.actions{{display:none}} @page{{size:A4 landscape;margin:8mm}} body{{font-size:9px;padding:0}} .grid{{grid-template-columns:repeat(4,1fr)}}}}
      </style>
    </head>
    <body>
      <div class="topbar">
        <div>
          <h1>📊 Dashboard windykacji</h1>
          <div class="muted">Podsumowanie windykacji, masowe sprawy i automatyczne zamykanie</div>
        </div>
        <form class="box" method="get">
          <div class="filters">
            <label>Data raportu
              <input type="date" name="date" value="{report_date}">
            </label>
            <label>Próg zaległości
              <input type="number" step="0.01" name="threshold" value="{threshold}">
            </label>
            <button type="submit">Pokaż</button>
          </div>
        </form>
      </div>

      <div class="links">
        <a href="/admin/raporty/?date={report_date}" target="_blank" rel="noopener">Dashboard Zarządcy ↗</a>
        <a href="/admin/raporty/rejestr-windykacji/?date={report_date}" target="_blank" rel="noopener">Rejestr windykacji ↗</a>
        <a href="/admin/raporty/sprawy-windykacyjne/?date={report_date}" target="_blank" rel="noopener">Workflow spraw ↗</a>
        <a href="/admin/raporty/wezwania-do-zaplaty/?date={report_date}&threshold={threshold}" target="_blank" rel="noopener">Wezwania do zapłaty ↗</a>
        <a href="#" onclick="window.print(); return false;">PDF</a>
      </div>

      <div class="grid">
        <div class="card">Wszystkie sprawy<strong>{len(cases)}</strong></div>
        <div class="card">Otwarte<strong class="minus">{len(open_cases)}</strong></div>
        <div class="card">Po terminie<strong class="minus">{len(overdue_cases)}</strong></div>
        <div class="card">Spłacone<strong class="plus">{len(paid_cases)}</strong></div>
        <div class="card">Zamknięte<strong class="plus">{len(closed_cases)}</strong></div>
        <div class="card">Skuteczność<strong>{effectiveness}</strong></div>
        <div class="card">Kwota otwarta<strong class="minus">-{_money(open_amount)}</strong></div>
        <div class="card">Odzyskana kwota<strong class="plus">{_money(recovered_amount)}</strong></div>
        <div class="card">Najstarsza otwarta<strong>{oldest_open_days} dni</strong></div>
        <div class="card">Średni czas zamknięcia<strong>{avg_close_days}</strong></div>
        <div class="card">Próg zaległości<strong>{_money(threshold)}</strong></div>
        <div class="card">Data raportu<strong>{report_date}</strong></div>
      </div>

      <div class="panel actions">
        <h2>⚙️ Akcje końcowe</h2>
        <p>Te akcje domykają moduł windykacji operacyjnie.</p>
        <div class="links">
          <a class="danger" href="/admin/raporty/windykacja-final/utworz-zbiorczo/?date={report_date}&threshold={threshold}">📨 Utwórz sprawy zbiorczo</a>
          <a class="ok" href="/admin/raporty/windykacja-final/auto-zamknij/?date={report_date}">✅ Auto-zamknij spłacone</a>
        </div>
      </div>

      <p class="note">Masowe tworzenie pomija lokale bez zaległości, poniżej progu oraz z istniejącą otwartą sprawą. Auto-zamykanie zamyka sprawy, gdy saldo lokalu jest nieujemne.</p>
    </body>
    </html>
    """
    return HttpResponse(html)


_original_get_urls_debt_final = admin.site.get_urls


def get_urls_debt_final():
    urls = _original_get_urls_debt_final()
    custom = [
        path("raporty/windykacja-final/", admin.site.admin_view(debt_collection_final_dashboard_view), name="debt_collection_final_dashboard"),
        path("raporty/windykacja-final/utworz-zbiorczo/", admin.site.admin_view(bulk_create_cases_view), name="debt_collection_bulk_create"),
        path("raporty/windykacja-final/auto-zamknij/", admin.site.admin_view(auto_close_cases_view), name="debt_collection_auto_close"),
    ]
    return custom + urls


if not getattr(admin.site, "_debt_collection_final_patched", False):
    admin.site.get_urls = get_urls_debt_final
    admin.site._debt_collection_final_patched = True
PY

echo "== Import modułu finalnego =="
python3 - <<'PY'
from pathlib import Path

p = Path("apps/audit/admin.py")
txt = p.read_text(encoding="utf-8")
line = "from . import admin_debt_collection_final  # noqa"
if line not in txt:
    txt = txt.rstrip() + "\n\n# Etap 2.8.5 FINAL - dashboard i automatyzacja windykacji\n" + line + "\n"
    p.write_text(txt, encoding="utf-8")
    print("OK: dodano import")
else:
    print("OK: import już istnieje")
PY

echo "== Link w centrum raportów =="
python3 - <<'PY'
from pathlib import Path

p = Path("apps/audit/admin_reports_center.py")
txt = p.read_text(encoding="utf-8")

if "/admin/raporty/windykacja-final/" not in txt:
    marker = '<a href="/admin/raporty/rejestr-windykacji/?date={default_date}" target="_blank" rel="noopener">Rejestr windykacji ↗</a>'
    if marker in txt:
        txt = txt.replace(marker, marker + '\n        <a href="/admin/raporty/windykacja-final/?date={default_date}" target="_blank" rel="noopener">Dashboard windykacji ↗</a>', 1)
        print("OK: dodano link obok rejestru")
    else:
        marker2 = '<a href="/admin/raporty/wezwania-do-zaplaty/?date={default_date}" target="_blank" rel="noopener">Otwórz raport ↗</a>'
        if marker2 in txt:
            txt = txt.replace(marker2, marker2 + '\n        <a href="/admin/raporty/windykacja-final/?date={default_date}" target="_blank" rel="noopener">Dashboard windykacji ↗</a>', 1)
            print("OK: dodano link do kafelka wezwań")
        else:
            print("UWAGA: nie znaleziono miejsca na link")
else:
    print("OK: link już istnieje")

p.write_text(txt, encoding="utf-8")
PY

echo "== Rebuild =="
docker compose down
docker compose build --no-cache
docker compose up -d

sleep 15

echo "== Check =="
docker compose exec web python manage.py check

echo "== Kontrola URL =="
docker compose exec web python manage.py shell -c "from django.urls import reverse; print(reverse('admin:debt_collection_final_dashboard'))"

echo "GOTOWE: Windykacja 2.8.5 FINAL"
