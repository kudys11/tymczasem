# Windykacja hotfix 2.8.5a

Poprawia:
- Workflow spraw: `Najstarsza otwarta` liczona według daty raportu.
- Rejestr windykacji: `Skuteczność` pokazuje `—`, jeśli nie ma zamkniętych/spłaconych spraw.
- Rejestr windykacji: `Najstarsza otwarta` liczona według daty raportu.

Uruchom:

```bash
cd /opt/_docker-compose/wspolnota
unzip windykacja_hotfix_2_8_5a.zip
chmod +x wdroz_hotfix_2_8_5a.sh
./wdroz_hotfix_2_8_5a.sh
```
