#!/usr/bin/env bash
set -euo pipefail

cd /opt/_docker-compose/wspolnota

echo "== Backup =="
mkdir -p _backup_windykacja_2_8_5a
cp -f apps/audit/admin_debt_cases_report.py _backup_windykacja_2_8_5a/admin_debt_cases_report.py.bak || true
cp -f apps/audit/admin_debt_collection_register.py _backup_windykacja_2_8_5a/admin_debt_collection_register.py.bak || true

echo "== Poprawiam pliki =="
python3 - <<'PY'
from pathlib import Path

# Workflow spraw
p = Path("apps/audit/admin_debt_cases_report.py")
txt = p.read_text(encoding="utf-8")
txt = txt.replace(
    "oldest_open_days = max((timezone.localdate() - oldest.created_at.date()).days, 0)",
    "oldest_open_days = max((report_date - oldest.created_at.date()).days, 0)",
)
p.write_text(txt, encoding="utf-8")
print("OK: admin_debt_cases_report.py")

# Rejestr windykacji
p = Path("apps/audit/admin_debt_collection_register.py")
txt = p.read_text(encoding="utf-8")

old = '''    effectiveness = 0
    if all_cases:
        effectiveness = round((len(paid_cases) + len([x for x in all_cases if x.status == "closed"])) * 100 / len(all_cases), 1)
'''

new = '''    completed_cases = [x for x in all_cases if x.status in ("paid", "closed")]
    effectiveness = "—"
    if all_cases and completed_cases:
        effectiveness = f"{round(len(completed_cases) * 100 / len(all_cases), 1)}%"
'''

txt = txt.replace(old, new)
txt = txt.replace(
    "oldest_open_days = max((today - oldest.created_at.date()).days, 0)",
    "oldest_open_days = max((report_date - oldest.created_at.date()).days, 0)",
)

p.write_text(txt, encoding="utf-8")
print("OK: admin_debt_collection_register.py")
PY

echo "== Rebuild =="
docker compose down
docker compose build --no-cache
docker compose up -d

echo "== Czekam na start =="
sleep 15

echo "== Check =="
docker compose exec web python manage.py check

echo "== Kontrola =="
docker compose exec web grep -n "oldest_open_days = max((report_date" /app/apps/audit/admin_debt_cases_report.py
docker compose exec web grep -n "effectiveness = \"—\"\|oldest_open_days = max((report_date" /app/apps/audit/admin_debt_collection_register.py

echo "GOTOWE: Windykacja hotfix 2.8.5a."
