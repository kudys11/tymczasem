# Patch Etap 2.6.1 - media według deklaracji i historii stawek

Ta poprawka nie dodaje nowych tabel i nie wymaga migracji.

Zmienia działanie rozliczenia mediów:
- w `Zaliczki na media` wpisujesz deklarowaną miesięczną ilość `monthly_quantity`,
- stawka pobierana jest z `Fees -> Reguły naliczania`,
- jeśli stawka zmieniła się w trakcie roku, system liczy każdy miesiąc według właściwej stawki,
- `--unit-price` nie jest już wymagane.

## Instalacja

```bash
cd /opt/_docker-compose/wspolnota
unzip wspolnota_etap_2_6_1_stawki_historyczne_patch.zip
python3 patch_etap_2_6_1_stawki_historyczne.py
docker compose down
docker compose build --no-cache
docker compose up -d
docker compose exec web python manage.py check
```

Nie wykonuj `makemigrations` ani `migrate`.

## Uruchomienie

```bash
docker compose exec web python manage.py calculate_utility_settlement --period-id 1 --overwrite
```

Z korektami naliczeń:

```bash
docker compose exec web python manage.py calculate_utility_settlement --period-id 1 --overwrite --create-adjustments
```
