from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from decimal import Decimal, ROUND_HALF_UP

from django.db import transaction
from django.db.models import Q

from apps.meters.models import Meter, MeterReading, UtilityAdvance, UtilitySettlement
from apps.fees.models import MonthlyCharge, ChargeAdjustment, FeeType, FeeRule


MONEY = Decimal("0.01")
QTY = Decimal("0.001")


def money(value) -> Decimal:
    if value is None:
        return Decimal("0.00")
    return Decimal(value).quantize(MONEY, rounding=ROUND_HALF_UP)


def qty(value) -> Decimal:
    if value is None:
        return Decimal("0.000")
    return Decimal(value).quantize(QTY, rounding=ROUND_HALF_UP)


@dataclass
class UtilitySettlementResult:
    apartments_processed: int = 0
    settlements_created: int = 0
    settlements_updated: int = 0
    missing_meters: int = 0
    missing_readings: int = 0
    missing_fee_rules: int = 0
    total_consumption: Decimal = Decimal("0.000")
    total_advance: Decimal = Decimal("0.00")
    total_actual: Decimal = Decimal("0.00")
    total_difference: Decimal = Decimal("0.00")
    adjustments_created: int = 0
    adjustments_updated: int = 0


def month_iter(start_date: date, end_date: date):
    y = start_date.year
    m = start_date.month
    while (y, m) <= (end_date.year, end_date.month):
        yield date(y, m, 1)
        if m == 12:
            y += 1
            m = 1
        else:
            m += 1


def find_reading_at_or_before(meter, target_date):
    return MeterReading.objects.filter(
        meter=meter,
        reading_date__lte=target_date,
    ).order_by("-reading_date", "-id").first()


def find_fee_rule_for_meter_type(community, meter_type, month_date):
    mt_code = (meter_type.code or "").strip().lower()
    mt_name = (meter_type.name or "").strip().lower()

    rules = FeeRule.objects.filter(
        fee_type__community=community,
        fee_type__is_active=True,
        is_active=True,
        valid_from__lte=month_date,
    ).filter(
        Q(valid_to__isnull=True) | Q(valid_to__gte=month_date)
    ).select_related("fee_type").order_by("-valid_from", "-is_default", "id")

    for rule in rules:
        ft_code = (rule.fee_type.code or "").strip().lower()
        ft_name = (rule.fee_type.name or "").strip().lower()

        if mt_code and (mt_code in ft_code or ft_code in mt_code):
            return rule
        if mt_name and (mt_name in ft_name or ft_name in mt_name):
            return rule

    return None


def get_declared_quantity_for_month(apartment, meter_type, month_date) -> Decimal:
    advance = UtilityAdvance.objects.filter(
        apartment=apartment,
        meter_type=meter_type,
        is_active=True,
        valid_from__lte=month_date,
    ).filter(
        Q(valid_to__isnull=True) | Q(valid_to__gte=month_date)
    ).order_by("-valid_from", "id").first()

    if not advance:
        return Decimal("0.000")

    return qty(advance.monthly_quantity or 0)


def calculate_advance_amount_from_rules(apartment, meter_type, period):
    total = Decimal("0.00")
    details = []
    missing_rule_months = 0

    for month_date in month_iter(period.date_from, period.date_to):
        declared_qty = get_declared_quantity_for_month(apartment, meter_type, month_date)
        if declared_qty <= 0:
            continue

        rule = find_fee_rule_for_meter_type(period.community, meter_type, month_date)
        if not rule:
            missing_rule_months += 1
            details.append(f"{month_date:%Y/%m}: brak reguły dla {declared_qty}")
            continue

        rate = Decimal(rule.rate or 0)
        amount = money(declared_qty * rate)
        total += amount
        details.append(f"{month_date:%Y/%m}: {declared_qty} x {rate} = {amount} zł")

    return money(total), details, missing_rule_months


def calculate_actual_amount_from_rules(consumption, meter_type, period):
    months = list(month_iter(period.date_from, period.date_to))
    if not months:
        return Decimal("0.00"), [], 0

    monthly_consumption = qty(Decimal(consumption or 0) / Decimal(len(months)))
    total = Decimal("0.00")
    details = []
    missing_rule_months = 0

    for month_date in months:
        rule = find_fee_rule_for_meter_type(period.community, meter_type, month_date)
        if not rule:
            missing_rule_months += 1
            details.append(f"{month_date:%Y/%m}: brak reguły dla zużycia {monthly_consumption}")
            continue

        rate = Decimal(rule.rate or 0)
        amount = money(monthly_consumption * rate)
        total += amount
        details.append(f"{month_date:%Y/%m}: {monthly_consumption} x {rate} = {amount} zł")

    return money(total), details, missing_rule_months


def get_or_create_fee_type_for_settlement(community, meter_type):
    raw = meter_type.code or meter_type.name or "MEDIA"
    code = ("ROZLICZENIE_" + raw.upper()).replace(" ", "_")[:50]
    name = f"Rozliczenie {meter_type.name}"

    obj, created = FeeType.objects.get_or_create(
        community=community,
        code=code,
        defaults={
            "name": name[:255],
            "description": "Automatyczne rozliczenie mediów.",
            "is_active": True,
            "sort_order": 900,
        },
    )
    return obj


def find_charge_for_adjustment(apartment, period):
    return MonthlyCharge.objects.filter(
        community=period.community,
        apartment=apartment,
        year=period.date_to.year,
        month=period.date_to.month,
    ).first()


@transaction.atomic
def calculate_utility_settlement(period, unit_price=None, create_adjustments=False, overwrite=False):
    result = UtilitySettlementResult()
    meter_type = period.meter_type
    fee_type = get_or_create_fee_type_for_settlement(period.community, meter_type)

    apartments = period.community.apartments.filter(is_active=True).order_by("building__name", "number")

    for apartment in apartments:
        result.apartments_processed += 1

        meter = Meter.objects.filter(
            apartment=apartment,
            meter_type=meter_type,
            is_active=True,
        ).order_by("id").first()

        if not meter:
            result.missing_meters += 1
            continue

        start_reading = find_reading_at_or_before(meter, period.date_from)
        end_reading = find_reading_at_or_before(meter, period.date_to)

        if not start_reading or not end_reading:
            result.missing_readings += 1
            continue

        start_value = Decimal(start_reading.value or 0)
        end_value = Decimal(end_reading.value or 0)
        consumption = qty(end_value - start_value)
        if consumption < 0:
            consumption = Decimal("0.000")

        advance_amount, advance_details, missing_adv_rules = calculate_advance_amount_from_rules(apartment, meter_type, period)
        actual_amount, actual_details, missing_actual_rules = calculate_actual_amount_from_rules(consumption, meter_type, period)

        result.missing_fee_rules += missing_adv_rules + missing_actual_rules

        difference_amount = money(actual_amount - advance_amount)

        snapshot = (
            f"Okres {period.date_from} - {period.date_to}. "
            f"Odczyt: {end_value} - {start_value} = {consumption}. "
            f"Zaliczki z deklaracji i historii stawek: {advance_amount} zł. "
            f"Koszt faktyczny z historii stawek: {actual_amount} zł. "
            f"Różnica: {difference_amount} zł. "
            f"Zaliczki szczegóły: {' | '.join(advance_details)}. "
            f"Koszt szczegóły: {' | '.join(actual_details)}."
        )

        settlement = UtilitySettlement.objects.filter(
            period=period,
            apartment=apartment,
        ).first()

        effective_unit_price = Decimal("0.0000")
        if consumption > 0:
            effective_unit_price = (actual_amount / consumption).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)

        if settlement and not overwrite:
            pass
        elif settlement and overwrite:
            settlement.meter = meter
            settlement.start_reading = start_value
            settlement.end_reading = end_value
            settlement.consumption = consumption
            settlement.unit_price = effective_unit_price
            settlement.advance_quantity = Decimal("0.000")
            settlement.advance_amount = advance_amount
            settlement.actual_amount = actual_amount
            settlement.difference_amount = difference_amount
            settlement.status = "draft"
            settlement.calculation_snapshot = snapshot
            settlement.save()
            result.settlements_updated += 1
        else:
            UtilitySettlement.objects.create(
                period=period,
                apartment=apartment,
                meter=meter,
                start_reading=start_value,
                end_reading=end_value,
                consumption=consumption,
                unit_price=effective_unit_price,
                advance_quantity=Decimal("0.000"),
                advance_amount=advance_amount,
                actual_amount=actual_amount,
                difference_amount=difference_amount,
                status="draft",
                calculation_snapshot=snapshot,
            )
            result.settlements_created += 1

        result.total_consumption += consumption
        result.total_advance += advance_amount
        result.total_actual += actual_amount
        result.total_difference += difference_amount

        if create_adjustments and difference_amount != 0:
            charge = find_charge_for_adjustment(apartment, period)
            if charge:
                description = f"Rozliczenie {meter_type.name} za okres {period.date_from} - {period.date_to}"
                adjustment = ChargeAdjustment.objects.filter(
                    monthly_charge=charge,
                    fee_type=fee_type,
                    description=description,
                ).first()

                if adjustment:
                    adjustment.amount = difference_amount
                    adjustment.adjustment_type = "settlement"
                    adjustment.save()
                    result.adjustments_updated += 1
                else:
                    ChargeAdjustment.objects.create(
                        monthly_charge=charge,
                        fee_type=fee_type,
                        adjustment_type="settlement",
                        description=description,
                        amount=difference_amount,
                    )
                    result.adjustments_created += 1

    result.total_consumption = qty(result.total_consumption)
    result.total_advance = money(result.total_advance)
    result.total_actual = money(result.total_actual)
    result.total_difference = money(result.total_difference)
    return result
