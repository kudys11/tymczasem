# Patch Etap 2.6.2 - wybór miesiąca księgowania korekt

Bez migracji. Dodaje parametry `--charge-year` i `--charge-month`.

## Instalacja

```bash
cd /opt/_docker-compose/wspolnota
unzip wspolnota_etap_2_6_2_miesiac_korekt_patch.zip
python3 patch_etap_2_6_2_miesiac_korekt.py
docker compose down
docker compose build --no-cache
docker compose up -d
docker compose exec web python manage.py check
```

## Użycie

```bash
docker compose exec web python manage.py calculate_utility_settlement --period-id 1 --overwrite --create-adjustments --charge-year 2026 --charge-month 6
```
