#!/usr/bin/env python3
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "patch_files"

files = {
    "apps/meters/services.py": SRC / "meters_services.py",
    "apps/meters/management/commands/calculate_utility_settlement.py": SRC / "calculate_utility_settlement.py",
}

for rel, src in files.items():
    dst = ROOT / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)

print("OK: Etap 2.6.2 miesiąc księgowania korekt został naniesiony.")
print("Nie wykonuj makemigrations ani migrate - ta poprawka nie zmienia struktury bazy.")
