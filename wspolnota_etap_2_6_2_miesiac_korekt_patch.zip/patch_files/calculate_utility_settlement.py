from django.core.management.base import BaseCommand, CommandError

from apps.meters.models import UtilitySettlementPeriod
from apps.meters.services import calculate_utility_settlement


class Command(BaseCommand):
    help = "Liczy rozliczenie mediów i pozwala wybrać miesiąc księgowania korekt."

    def add_arguments(self, parser):
        parser.add_argument("--period-id", type=int, required=True)
        parser.add_argument("--overwrite", action="store_true")
        parser.add_argument("--create-adjustments", action="store_true")
        parser.add_argument("--charge-year", type=int, default=None)
        parser.add_argument("--charge-month", type=int, default=None)

    def handle(self, *args, **options):
        period = UtilitySettlementPeriod.objects.filter(id=options["period_id"]).first()
        if not period:
            raise CommandError(f"Nie znaleziono okresu rozliczeniowego id={options['period_id']}")

        charge_year = options.get("charge_year")
        charge_month = options.get("charge_month")

        if (charge_year and not charge_month) or (charge_month and not charge_year):
            raise CommandError("Parametry --charge-year i --charge-month muszą być podane razem.")

        if charge_month is not None and (charge_month < 1 or charge_month > 12):
            raise CommandError("--charge-month musi być w zakresie 1-12.")

        result = calculate_utility_settlement(
            period=period,
            create_adjustments=options["create_adjustments"],
            overwrite=options["overwrite"],
            charge_year=charge_year,
            charge_month=charge_month,
        )

        self.stdout.write(self.style.SUCCESS("Rozliczenie mediów zakończone."))
        self.stdout.write(f"Okres: {period}")
        if charge_year and charge_month:
            self.stdout.write(f"Miesiąc księgowania korekt: {charge_year}/{charge_month:02d}")
        self.stdout.write(f"Przetworzone lokale: {result.apartments_processed}")
        self.stdout.write(f"Utworzone rozliczenia: {result.settlements_created}")
        self.stdout.write(f"Zaktualizowane rozliczenia: {result.settlements_updated}")
        self.stdout.write(f"Brak liczników: {result.missing_meters}")
        self.stdout.write(f"Brak odczytów: {result.missing_readings}")
        self.stdout.write(f"Brak reguł stawek: {result.missing_fee_rules}")
        self.stdout.write(f"Brak naliczeń dla korekt: {result.missing_charge_for_adjustment}")
        self.stdout.write(f"Suma zużycia: {result.total_consumption}")
        self.stdout.write(f"Suma zaliczek: {result.total_advance} zł")
        self.stdout.write(f"Koszt faktyczny: {result.total_actual} zł")
        self.stdout.write(f"Różnica razem: {result.total_difference} zł")
        self.stdout.write(f"Korekty utworzone: {result.adjustments_created}")
        self.stdout.write(f"Korekty zaktualizowane: {result.adjustments_updated}")
