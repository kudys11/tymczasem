# Patch Etap 2.6 - roczne rozliczenie mediów

Ta poprawka nie dodaje nowych tabel i nie wymaga migracji.

Wykorzystuje istniejące modele:
- UtilitySettlementPeriod,
- UtilitySettlement,
- Meter,
- MeterReading,
- UtilityAdvance,
- ChargeAdjustment.

## Instalacja

```bash
cd /opt/_docker-compose/wspolnota
unzip wspolnota_etap_2_6_media_roczne_patch.zip
python3 patch_etap_2_6_media_roczne.py
docker compose down
docker compose build --no-cache
docker compose up -d
docker compose exec web python manage.py check
```

Nie wykonuj `makemigrations` ani `migrate`.

## Przygotowanie danych

W adminie uzupełnij:
1. Meters -> Typy liczników
2. Meters -> Liczniki
3. Meters -> Odczyty liczników
4. Meters -> Zaliczki na media
5. Meters -> Okresy rozliczenia mediów

## Uruchomienie rozliczenia

```bash
docker compose exec web python manage.py calculate_utility_settlement --period-id 1 --unit-price 12.50
```

Ponowne przeliczenie:

```bash
docker compose exec web python manage.py calculate_utility_settlement --period-id 1 --unit-price 12.50 --overwrite
```

Utworzenie korekt naliczeń:

```bash
docker compose exec web python manage.py calculate_utility_settlement --period-id 1 --unit-price 12.50 --overwrite --create-adjustments
```

## Wynik

Sprawdź w adminie:
- Meters -> Rozliczenia mediów
- Fees -> Korekty naliczeń

Interpretacja difference_amount:
- wartość dodatnia = niedopłata,
- wartość ujemna = nadpłata.
