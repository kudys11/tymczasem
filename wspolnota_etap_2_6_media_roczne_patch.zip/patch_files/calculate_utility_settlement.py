from decimal import Decimal

from django.core.management.base import BaseCommand, CommandError

from apps.meters.models import UtilitySettlementPeriod
from apps.meters.services import calculate_utility_settlement


class Command(BaseCommand):
    help = "Liczy roczne/okresowe rozliczenie mediów dla okresu rozliczeniowego."

    def add_arguments(self, parser):
        parser.add_argument("--period-id", type=int, required=True)
        parser.add_argument("--unit-price", type=Decimal, required=True, help="Cena jednostkowa, np. 12.50")
        parser.add_argument("--overwrite", action="store_true", help="Nadpisuje istniejące rozliczenia.")
        parser.add_argument("--create-adjustments", action="store_true", help="Tworzy korekty naliczeń na końcowy miesiąc okresu.")

    def handle(self, *args, **options):
        period = UtilitySettlementPeriod.objects.filter(id=options["period_id"]).first()
        if not period:
            raise CommandError(f"Nie znaleziono okresu rozliczeniowego id={options['period_id']}")

        result = calculate_utility_settlement(
            period=period,
            unit_price=options["unit_price"],
            create_adjustments=options["create_adjustments"],
            overwrite=options["overwrite"],
        )

        self.stdout.write(self.style.SUCCESS("Rozliczenie mediów zakończone."))
        self.stdout.write(f"Okres: {period}")
        self.stdout.write(f"Przetworzone lokale: {result.apartments_processed}")
        self.stdout.write(f"Utworzone rozliczenia: {result.settlements_created}")
        self.stdout.write(f"Zaktualizowane rozliczenia: {result.settlements_updated}")
        self.stdout.write(f"Brak liczników: {result.missing_meters}")
        self.stdout.write(f"Brak odczytów: {result.missing_readings}")
        self.stdout.write(f"Suma zużycia: {result.total_consumption}")
        self.stdout.write(f"Suma zaliczek: {result.total_advance} zł")
        self.stdout.write(f"Koszt faktyczny: {result.total_actual} zł")
        self.stdout.write(f"Różnica razem: {result.total_difference} zł")
        self.stdout.write(f"Korekty utworzone: {result.adjustments_created}")
        self.stdout.write(f"Korekty zaktualizowane: {result.adjustments_updated}")
