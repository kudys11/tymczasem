# Etap 2.7.10 - Dashboard Zarządcy

Bez migracji.

Zastępuje stronę:

```text
/admin/raporty/
```

nowym Dashboardem Zarządcy.

Sekcje:
- Wymaga uwagi
- Finanse
- Faktury i zobowiązania
- Wspólnota
- Raporty
- Szybkie akcje

Nie rusza:
- `ExpenseDocumentAdmin`
- listy `Finance -> Koszty wspólnoty`
- istniejących raportów szczegółowych

## Instalacja

```bash
cd /opt/_docker-compose/wspolnota
unzip wspolnota_etap_2_7_10_dashboard_zarzadcy_patch.zip
python3 patch_etap_2_7_10_dashboard_zarzadcy.py
docker compose down
docker compose build --no-cache
docker compose up -d
docker compose exec web python manage.py check
```

## Widok

```text
/admin/raporty/
```
