#!/usr/bin/env python3
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "patch_files"

target = ROOT / "apps" / "audit" / "admin_reports_center.py"
backup = ROOT / "apps" / "audit" / "admin_reports_center.py.bak_2_7_10"

if target.exists() and not backup.exists():
    shutil.copyfile(target, backup)

shutil.copyfile(SRC / "admin_reports_center.py", target)

print("OK: Etap 2.7.10 - Dashboard Zarządcy został wdrożony jako /admin/raporty/.")
print("Bez migracji.")
