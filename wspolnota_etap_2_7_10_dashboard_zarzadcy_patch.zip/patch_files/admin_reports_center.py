from datetime import date, datetime, timedelta
from decimal import Decimal

from django.contrib import admin
from django.db import models
from django.db.models import Sum
from django.http import HttpResponse
from django.urls import path, reverse


class ReportCenter(models.Model):
    class Meta:
        managed = False
        app_label = "audit"
        verbose_name = "Centrum raportów"
        verbose_name_plural = "Centrum raportów"


def _dec(value):
    return Decimal(value or 0)


def _money(value):
    return f"{_dec(value):.2f} zł".replace(".", ",")


def _signed_money(value):
    value = _dec(value)
    sign = "+" if value > 0 else "-" if value < 0 else ""
    return f"{sign}{_money(abs(value))}"


def _safe_count(qs):
    try:
        return qs.count()
    except Exception:
        return 0


def _safe_sum(qs, field):
    try:
        return qs.aggregate(s=Sum(field))["s"] or Decimal("0.00")
    except Exception:
        return Decimal("0.00")


def _expense_left(doc):
    return _dec(getattr(doc, "gross_amount", 0)) - _dec(getattr(doc, "paid_amount", 0))


def reports_index_view(request):
    today = date.today()
    default_date = request.GET.get("date") or f"{today.year}-12-31"

    try:
        report_date = datetime.strptime(default_date, "%Y-%m-%d").date()
    except ValueError:
        report_date = today
        default_date = today.isoformat()

    date_30 = report_date - timedelta(days=30)

    try:
        financial_url = reverse("admin:financial_summary_report") + f"?date={default_date}"
    except Exception:
        financial_url = f"/admin/raporty/bilans-finansowy/?date={default_date}"

    # Importy lokalne, żeby centrum raportów nie blokowało startu admina przy zmianach w modułach.
    try:
        from apps.communities.models import Apartment
    except Exception:
        Apartment = None

    try:
        from apps.people.models import ApartmentOwnership
    except Exception:
        ApartmentOwnership = None

    try:
        from apps.finance.models import ExpenseDocument, Payment, BankAccount, OwnerBalance
    except Exception:
        ExpenseDocument = Payment = BankAccount = OwnerBalance = None

    try:
        from apps.meters.models import UtilitySettlement
    except Exception:
        UtilitySettlement = None

    # Faktury i zobowiązania
    open_invoices = []
    overdue_invoices = []
    due_soon_invoices = []
    no_due_invoices = []
    partial_invoices = []

    if ExpenseDocument:
        try:
            docs = list(
                ExpenseDocument.objects
                .exclude(status="cancelled")
                .select_related("vendor", "cost_category")
            )
            for doc in docs:
                payment_status = getattr(doc, "payment_status", "unpaid")
                amount_left = _expense_left(doc)
                due_date = getattr(doc, "due_date", None)
                is_open = payment_status in ("unpaid", "partial") and amount_left > 0

                if is_open:
                    open_invoices.append(doc)
                if is_open and due_date and due_date < report_date:
                    overdue_invoices.append(doc)
                if is_open and due_date and report_date <= due_date <= report_date + timedelta(days=14):
                    due_soon_invoices.append(doc)
                if is_open and not due_date:
                    no_due_invoices.append(doc)
                if payment_status == "partial":
                    partial_invoices.append(doc)
        except Exception:
            pass

    open_invoice_sum = sum((_expense_left(d) for d in open_invoices), Decimal("0.00"))
    overdue_invoice_sum = sum((_expense_left(d) for d in overdue_invoices), Decimal("0.00"))
    due_soon_invoice_sum = sum((_expense_left(d) for d in due_soon_invoices), Decimal("0.00"))

    # Finanse 30 dni i szacunkowe środki
    payments_30 = Decimal("0.00")
    expenses_30 = Decimal("0.00")
    bank_total_estimated = Decimal("0.00")
    main_account_estimated = Decimal("0.00")

    if Payment:
        try:
            payments_30 = _safe_sum(
                Payment.objects.filter(payment_date__gte=date_30, payment_date__lte=report_date, is_confirmed=True),
                "amount",
            )
            all_payments = _safe_sum(Payment.objects.filter(payment_date__lte=report_date, is_confirmed=True), "amount")
        except Exception:
            all_payments = Decimal("0.00")
    else:
        all_payments = Decimal("0.00")

    if ExpenseDocument:
        try:
            expenses_30 = _safe_sum(
                ExpenseDocument.objects.exclude(status="cancelled").filter(posting_date__gte=date_30, posting_date__lte=report_date),
                "gross_amount",
            )
            all_expenses = _safe_sum(
                ExpenseDocument.objects.exclude(status="cancelled").filter(posting_date__lte=report_date),
                "gross_amount",
            )
        except Exception:
            all_expenses = Decimal("0.00")
    else:
        all_expenses = Decimal("0.00")

    bank_total_estimated = all_payments - all_expenses

    if BankAccount and Payment and ExpenseDocument:
        try:
            main_account = (
                BankAccount.objects.filter(is_active=True, account_type__icontains="main").first()
                or BankAccount.objects.filter(is_active=True, name__icontains="głów").first()
                or BankAccount.objects.filter(is_active=True).order_by("id").first()
            )
            if main_account:
                acc_payments = _safe_sum(
                    Payment.objects.filter(bank_account=main_account, payment_date__lte=report_date, is_confirmed=True),
                    "amount",
                )
                acc_expenses = _safe_sum(
                    ExpenseDocument.objects.exclude(status="cancelled").filter(bank_account=main_account, posting_date__lte=report_date),
                    "gross_amount",
                )
                main_account_estimated = acc_payments - acc_expenses
        except Exception:
            pass

    # Wspólnota
    apartment_count = _safe_count(Apartment.objects.filter(is_active=True)) if Apartment else 0
    owners_count = (
        _safe_count(ApartmentOwnership.objects.filter(is_active=True).values("person_id").distinct())
        if ApartmentOwnership else 0
    )

    # Salda właścicieli — jeśli model ma znane pole salda.
    arrears_count = 0
    arrears_sum = Decimal("0.00")
    overpay_count = 0
    overpay_sum = Decimal("0.00")

    if OwnerBalance:
        try:
            fields = {f.name for f in OwnerBalance._meta.fields}
            balance_field = None
            for candidate in ("balance", "current_balance", "amount", "saldo"):
                if candidate in fields:
                    balance_field = candidate
                    break

            if balance_field:
                balances = list(OwnerBalance.objects.all())
                for b in balances:
                    val = _dec(getattr(b, balance_field, 0))
                    if val < 0:
                        arrears_count += 1
                        arrears_sum += abs(val)
                    elif val > 0:
                        overpay_count += 1
                        overpay_sum += val
        except Exception:
            pass

    media_count = _safe_count(UtilitySettlement.objects.all()) if UtilitySettlement else 0

    alert_class = "ok"
    alert_text = "Brak krytycznych alertów na wybraną datę."
    if overdue_invoices or arrears_count:
        alert_class = "bad"
        alert_text = f"Wymaga uwagi: {len(overdue_invoices)} faktur po terminie oraz {arrears_count} sald z zaległością."
    elif due_soon_invoices:
        alert_class = "warnbox"
        alert_text = f"Uwaga: {len(due_soon_invoices)} faktur ma termin płatności w ciągu 14 dni."

    html = f"""
    <style>
      body {{ font-family: Arial, sans-serif; padding: 18px; background:#fff; color:#0f172a; }}
      .topbar {{ display:flex; justify-content:space-between; align-items:flex-start; gap:16px; margin-bottom:18px; }}
      h1 {{ margin:0; font-size:28px; }}
      .subtitle {{ color:#64748b; margin-top:5px; }}
      .date-box {{ border:1px solid #dfe5ec; padding:12px; border-radius:8px; background:#f8fafc; }}
      .date-box input {{ padding:7px 9px; }}
      .date-box button {{ padding:8px 12px; cursor:pointer; }}
      .alert {{ border-radius:9px; padding:13px 15px; margin:12px 0 18px 0; font-weight:700; }}
      .bad {{ background:#fef2f2; color:#dc2626; border:1px solid #fecaca; }}
      .warnbox {{ background:#fffbeb; color:#ca8a04; border:1px solid #fde68a; }}
      .ok {{ background:#ecfdf5; color:#0a8f3c; border:1px solid #bbf7d0; }}
      .section-title {{ margin-top:26px; font-size:22px; }}
      .grid {{ display:grid; grid-template-columns: repeat(4, minmax(180px, 1fr)); gap:14px; margin-top:12px; }}
      .card {{ border:1px solid #dfe5ec; border-radius:10px; padding:15px; background:#fff; box-shadow:0 1px 2px rgba(15,23,42,.04); }}
      .card h2 {{ margin:0 0 8px 0; font-size:17px; }}
      .card .value {{ font-size:24px; font-weight:800; margin-top:6px; }}
      .card .sub {{ color:#64748b; font-size:13px; margin-top:4px; }}
      .plus {{ color:#0a8f3c; }}
      .minus {{ color:#dc2626; }}
      .warn {{ color:#ca8a04; }}
      .reports-grid {{ display:grid; grid-template-columns: repeat(3, minmax(220px, 1fr)); gap:16px; margin-top:14px; }}
      .report-card {{ border:1px solid #dfe5ec; border-radius:10px; padding:16px; background:#fff; box-shadow:0 1px 2px rgba(15,23,42,.04); }}
      .report-card h2 {{ margin:0 0 8px 0; font-size:19px; }}
      .report-card p {{ color:#64748b; min-height:38px; }}
      .report-card a, .quick-links a {{ display:inline-block; margin-top:8px; border:1px solid #cbd5e1; border-radius:6px; padding:8px 12px; text-decoration:none; color:#0f172a; font-weight:600; background:#f8fafc; }}
      .disabled {{ opacity:.55; }}
      .quick-links {{ display:flex; flex-wrap:wrap; gap:8px; margin-top:10px; }}
      .quick-links a {{ margin-top:0; }}
      .note {{ color:#64748b; margin-top:20px; font-size:13px; }}
      @media (max-width: 1100px) {{ .grid, .reports-grid {{ grid-template-columns: repeat(2, minmax(180px, 1fr)); }} }}
      @media (max-width: 700px) {{ .grid, .reports-grid {{ grid-template-columns:1fr; }} .topbar {{ display:block; }} .date-box {{ margin-top:12px; }} }}
    </style>

    <div class="topbar">
      <div>
        <h1>🏢 Dashboard Zarządcy</h1>
        <div class="subtitle">Centrum raportów i bieżąca kontrola wspólnoty mieszkaniowej</div>
      </div>
      <form class="date-box" method="get">
        <label>Data raportu:
          <input type="date" name="date" value="{default_date}">
        </label>
        <button type="submit">Ustaw datę</button>
      </form>
    </div>

    <div class="alert {alert_class}">{alert_text}</div>

    <h2 class="section-title">🚨 Wymaga uwagi</h2>
    <div class="grid">
      <div class="card"><h2>Faktury po terminie</h2><div class="value minus">{len(overdue_invoices)}</div><div class="sub">{_money(overdue_invoice_sum)}</div></div>
      <div class="card"><h2>Termin w 14 dni</h2><div class="value warn">{len(due_soon_invoices)}</div><div class="sub">{_money(due_soon_invoice_sum)}</div></div>
      <div class="card"><h2>Właściciele z zaległością</h2><div class="value minus">{arrears_count}</div><div class="sub">{_money(arrears_sum)}</div></div>
      <div class="card"><h2>Faktury bez terminu</h2><div class="value warn">{len(no_due_invoices)}</div><div class="sub">do uzupełnienia</div></div>
    </div>

    <h2 class="section-title">💰 Finanse</h2>
    <div class="grid">
      <div class="card"><h2>Rachunek główny</h2><div class="value">{_signed_money(main_account_estimated)}</div><div class="sub">szacunkowo</div></div>
      <div class="card"><h2>Wszystkie rachunki</h2><div class="value">{_signed_money(bank_total_estimated)}</div><div class="sub">wpłaty minus koszty</div></div>
      <div class="card"><h2>Wpłaty 30 dni</h2><div class="value plus">{_money(payments_30)}</div><div class="sub">potwierdzone</div></div>
      <div class="card"><h2>Koszty 30 dni</h2><div class="value minus">{_money(expenses_30)}</div><div class="sub">zaksięgowane / zapisane</div></div>
    </div>

    <h2 class="section-title">📄 Faktury i zobowiązania</h2>
    <div class="grid">
      <div class="card"><h2>Do zapłaty</h2><div class="value minus">{len(open_invoices)}</div><div class="sub">{_money(open_invoice_sum)}</div></div>
      <div class="card"><h2>Częściowo zapłacone</h2><div class="value warn">{len(partial_invoices)}</div><div class="sub">wymagają kontroli</div></div>
      <div class="card"><h2>Po terminie</h2><div class="value minus">{len(overdue_invoices)}</div><div class="sub">{_money(overdue_invoice_sum)}</div></div>
      <div class="card"><h2>Bez terminu płatności</h2><div class="value warn">{len(no_due_invoices)}</div><div class="sub">uzupełnij daty</div></div>
    </div>

    <h2 class="section-title">🏢 Wspólnota</h2>
    <div class="grid">
      <div class="card"><h2>Lokale</h2><div class="value">{apartment_count}</div><div class="sub">aktywne</div></div>
      <div class="card"><h2>Właściciele</h2><div class="value">{owners_count}</div><div class="sub">aktywni</div></div>
      <div class="card"><h2>Lokale z nadpłatą</h2><div class="value plus">{overpay_count}</div><div class="sub">{_money(overpay_sum)}</div></div>
      <div class="card"><h2>Rozliczenia mediów</h2><div class="value">{media_count}</div><div class="sub">utworzone</div></div>
    </div>

    <h2 class="section-title">📊 Raporty</h2>
    <div class="reports-grid">
      <div class="report-card">
        <h2>📊 Bilans finansowy</h2>
        <p>Saldo właścicieli, rachunki bankowe, koszty, media, nadpłaty i zaległości.</p>
        <a href="{financial_url}" target="_blank" rel="noopener">Otwórz raport ↗</a>
      </div>

      <div class="report-card">
        <h2>📄 Faktury do zapłaty</h2>
        <p>Zobowiązania wspólnoty: do zapłaty, przeterminowane, nadchodzące i zapłacone.</p>
        <a href="/admin/raporty/faktury-do-zaplaty/?date={default_date}" target="_blank" rel="noopener">Otwórz raport ↗</a>
      </div>

      <div class="report-card">
        <h2>🚨 Monitoring zobowiązań</h2>
        <p>Kontrola faktur po terminie, najbliższych płatności i faktur bez terminu.</p>
        <a href="/admin/raporty/monitoring-zobowiazan/?date={default_date}" target="_blank" rel="noopener">Otwórz raport ↗</a>
      </div>

      <div class="report-card disabled">
        <h2>💧 Rozliczenia mediów</h2>
        <p>Zestawienie zaliczek, kosztów, nadpłat i niedopłat.</p>
        <a href="{financial_url}" target="_blank" rel="noopener">W przygotowaniu ↗</a>
      </div>

      <div class="report-card disabled">
        <h2>⚠️ Zaległości właścicieli</h2>
        <p>Lista lokali z największymi zaległościami.</p>
        <a href="{financial_url}" target="_blank" rel="noopener">W przygotowaniu ↗</a>
      </div>

      <div class="report-card disabled">
        <h2>💰 Nadpłaty właścicieli</h2>
        <p>Lista lokali z nadpłatami.</p>
        <a href="{financial_url}" target="_blank" rel="noopener">W przygotowaniu ↗</a>
      </div>
    </div>

    <h2 class="section-title">⚡ Szybkie akcje</h2>
    <div class="quick-links">
      <a href="/admin/finance/expensedocument/add/" target="_blank" rel="noopener">Dodaj koszt / fakturę ↗</a>
      <a href="/admin/finance/payment/add/" target="_blank" rel="noopener">Dodaj wpłatę ↗</a>
      <a href="/admin/meters/meterreading/add/" target="_blank" rel="noopener">Dodaj odczyt licznika ↗</a>
      <a href="/admin/finance/expensedocument/" target="_blank" rel="noopener">Koszty wspólnoty ↗</a>
      <a href="/admin/finance/vendor/" target="_blank" rel="noopener">Kontrahenci ↗</a>
      <a href="/admin/communities/apartment/" target="_blank" rel="noopener">Lokale ↗</a>
      <a href="/admin/meters/utilitysettlement/" target="_blank" rel="noopener">Rozliczenia mediów ↗</a>
    </div>

    <p class="note">Dashboard pokazuje dane operacyjne na wybraną datę. Wartości rachunków są szacunkowe do czasu wdrożenia pełnego rejestru operacji bankowych.</p>
    """
    return HttpResponse(html)


class ReportCenterAdmin(admin.ModelAdmin):
    def has_add_permission(self, request):
        return False

    def has_delete_permission(self, request, obj=None):
        return False

    def has_view_permission(self, request, obj=None):
        return True

    def changelist_view(self, request, extra_context=None):
        return reports_index_view(request)


try:
    admin.site.unregister(ReportCenter)
except Exception:
    pass

admin.site.register(ReportCenter, ReportCenterAdmin)

_original_get_urls = admin.site.get_urls


def get_urls():
    urls = _original_get_urls()
    custom = [path("raporty/", admin.site.admin_view(reports_index_view), name="reports_center")]
    return custom + urls


if not getattr(admin.site, "_reports_center_patched", False):
    admin.site.get_urls = get_urls
    admin.site._reports_center_patched = True
