# Patch Etap 2.7.1 - Kartoteka lokalu

Bez migracji. Dodaje w adminie przy lokalach link `Kartoteka`.

## Instalacja

```bash
cd /opt/_docker-compose/wspolnota
unzip wspolnota_etap_2_7_1_kartoteka_lokalu_patch.zip
python3 patch_etap_2_7_1_kartoteka_lokalu.py
docker compose down
docker compose build --no-cache
docker compose up -d
docker compose exec web python manage.py check
```

## Użycie

Wejdź: `Communities -> Lokale`, kliknij `Kartoteka`.
