
from decimal import Decimal
from django.contrib import admin
from django.http import HttpResponse
from django.urls import path, reverse
from django.utils.html import format_html
from django.utils.safestring import mark_safe
from django.db.models import Sum
from apps.communities.models import Apartment
from apps.people.models import ApartmentOwnership, ApartmentPerson
from apps.finance.models import Payment, OwnerBalance
from apps.fees.models import MonthlyCharge, ChargeAdjustment
from apps.meters.models import Meter, MeterReading, UtilitySettlement

def money(value):
    if value is None:
        value = Decimal('0.00')
    return f'{value:.2f} zł'

def safe_obj(obj):
    return obj if obj else '-'

def rows(items, renderer, empty='Brak danych'):
    rendered = ''.join(renderer(x) for x in items)
    return rendered or f"<tr><td colspan='10'>{empty}</td></tr>"

def apartment_card_html(apartment):
    owners = ApartmentOwnership.objects.filter(apartment=apartment, is_active=True).select_related('person').order_by('-is_primary_owner','id')
    residents = ApartmentPerson.objects.filter(apartment=apartment, is_active=True).select_related('person').order_by('relation_type','id')
    balances = OwnerBalance.objects.filter(apartment=apartment).select_related('person')
    balance_total = balances.aggregate(s=Sum('balance_total'))['s'] or Decimal('0.00')
    charges_qs = MonthlyCharge.objects.filter(apartment=apartment).exclude(status='cancelled')
    charges = charges_qs.order_by('-year','-month','-id')[:12]
    charge_total = charges_qs.aggregate(s=Sum('total_amount'))['s'] or Decimal('0.00')
    payments_qs = Payment.objects.filter(apartment=apartment)
    payments = payments_qs.order_by('-payment_date','-id')[:12]
    payment_total = payments_qs.filter(is_confirmed=True).aggregate(s=Sum('amount'))['s'] or Decimal('0.00')
    meters = Meter.objects.filter(apartment=apartment, is_active=True).select_related('meter_type').order_by('meter_type__name','id')
    readings = MeterReading.objects.filter(meter_id__in=list(meters.values_list('id', flat=True))).select_related('meter','meter__meter_type').order_by('-reading_date','-id')[:12]
    settlements = UtilitySettlement.objects.filter(apartment=apartment).select_related('period','meter').order_by('-id')[:12]
    adjustments = ChargeAdjustment.objects.filter(monthly_charge__apartment=apartment).select_related('monthly_charge','fee_type').order_by('-created_at','-id')[:12]
    owners_rows = rows(owners, lambda o: f'<tr><td>{safe_obj(o.person)}</td><td>{o.ownership_type}</td><td>{o.share_numerator}/{o.share_denominator}</td><td>{"TAK" if o.is_primary_owner else "NIE"}</td></tr>')
    residents_rows = rows(residents, lambda r: f'<tr><td>{safe_obj(r.person)}</td><td>{r.relation_type}</td><td>{safe_obj(r.valid_from)}</td><td>{safe_obj(r.valid_to)}</td></tr>')
    balances_rows = rows(balances, lambda b: f'<tr><td>{safe_obj(b.person)}</td><td>{money(b.balance_total)}</td><td>{safe_obj(b.calculated_at)}</td></tr>')
    charges_rows = rows(charges, lambda c: f'<tr><td>{c.year}/{c.month:02d}</td><td>{money(c.total_amount)}</td><td>{c.status}</td></tr>')
    payments_rows = rows(payments, lambda p: f'<tr><td>{p.payment_date}</td><td>{money(p.amount)}</td><td>{safe_obj(p.person)}</td><td>{p.title or ""}</td><td>{"TAK" if p.is_confirmed else "NIE"}</td></tr>')
    meters_rows = rows(meters, lambda m: f'<tr><td>{safe_obj(m.meter_type)}</td><td>{getattr(m,"serial_number","") or getattr(m,"number","") or "-"}</td><td>{getattr(m,"seal_number","") or "-"}</td><td>{"TAK" if m.is_active else "NIE"}</td></tr>')
    readings_rows = rows(readings, lambda r: f'<tr><td>{r.reading_date}</td><td>{safe_obj(r.meter.meter_type)}</td><td>{r.value}</td><td>{r.source}</td><td>{r.status}</td></tr>')
    settlements_rows = rows(settlements, lambda s: f'<tr><td>{safe_obj(s.period)}</td><td>{s.consumption}</td><td>{money(s.advance_amount)}</td><td>{money(s.actual_amount)}</td><td>{money(s.difference_amount)}</td><td>{s.status}</td></tr>')
    adjustments_rows = rows(adjustments, lambda a: f'<tr><td>{a.monthly_charge.year}/{a.monthly_charge.month:02d}</td><td>{safe_obj(a.fee_type)}</td><td>{a.adjustment_type}</td><td>{money(a.amount)}</td><td>{a.description}</td></tr>')
    status = getattr(apartment, 'status', 'aktywny')
    html = []
    html.append('<style>.card-grid{display:grid;grid-template-columns:repeat(4,minmax(160px,1fr));gap:12px;margin:16px 0}.stat-card{background:#f8f8f8;border:1px solid #ddd;border-radius:8px;padding:12px}.stat-card strong{display:block;font-size:18px;margin-top:4px}.section{margin-top:24px}.section h2{border-bottom:1px solid #ddd;padding-bottom:6px}.wm-table{width:100%;border-collapse:collapse;margin-top:8px}.wm-table th,.wm-table td{border:1px solid #ddd;padding:6px 8px;vertical-align:top}.wm-table th{background:#f0f0f0;text-align:left}</style>')
    html.append(f'<h1>Kartoteka lokalu: {apartment}</h1>')
    html.append(f'<div class="card-grid"><div class="stat-card">Powierzchnia<strong>{apartment.apartment_area} m²</strong></div><div class="stat-card">Mieszkańcy<strong>{apartment.residents_count}</strong></div><div class="stat-card">Suma naliczeń<strong>{money(charge_total)}</strong></div><div class="stat-card">Suma wpłat<strong>{money(payment_total)}</strong></div><div class="stat-card">Saldo<strong>{money(balance_total)}</strong></div><div class="stat-card">Status<strong>{status}</strong></div><div class="stat-card">Udział<strong>{apartment.share_numerator}/{apartment.share_denominator}</strong></div><div class="stat-card">Aktywny<strong>{"TAK" if apartment.is_active else "NIE"}</strong></div></div>')
    html.append(f'<div class="section"><h2>Właściciele</h2><table class="wm-table"><tr><th>Osoba</th><th>Typ</th><th>Udział</th><th>Główny</th></tr>{owners_rows}</table></div>')
    html.append(f'<div class="section"><h2>Osoby powiązane</h2><table class="wm-table"><tr><th>Osoba</th><th>Relacja</th><th>Od</th><th>Do</th></tr>{residents_rows}</table></div>')
    html.append(f'<div class="section"><h2>Salda</h2><table class="wm-table"><tr><th>Osoba</th><th>Saldo</th><th>Przeliczono</th></tr>{balances_rows}</table></div>')
    html.append(f'<div class="section"><h2>Ostatnie naliczenia</h2><table class="wm-table"><tr><th>Okres</th><th>Kwota</th><th>Status</th></tr>{charges_rows}</table></div>')
    html.append(f'<div class="section"><h2>Ostatnie wpłaty</h2><table class="wm-table"><tr><th>Data</th><th>Kwota</th><th>Osoba</th><th>Tytuł</th><th>Potwierdzona</th></tr>{payments_rows}</table></div>')
    html.append(f'<div class="section"><h2>Liczniki</h2><table class="wm-table"><tr><th>Typ</th><th>Numer</th><th>Plomba</th><th>Aktywny</th></tr>{meters_rows}</table></div>')
    html.append(f'<div class="section"><h2>Odczyty</h2><table class="wm-table"><tr><th>Data</th><th>Typ</th><th>Wartość</th><th>Źródło</th><th>Status</th></tr>{readings_rows}</table></div>')
    html.append(f'<div class="section"><h2>Rozliczenia mediów</h2><table class="wm-table"><tr><th>Okres</th><th>Zużycie</th><th>Zaliczki</th><th>Koszt</th><th>Różnica</th><th>Status</th></tr>{settlements_rows}</table></div>')
    html.append(f'<div class="section"><h2>Korekty naliczeń</h2><table class="wm-table"><tr><th>Okres</th><th>Typ</th><th>Rodzaj</th><th>Kwota</th><th>Opis</th></tr>{adjustments_rows}</table></div>')
    return mark_safe(''.join(html))

def patch_apartment_admin():
    old_admin = admin.site._registry.get(Apartment)
    old_cls = old_admin.__class__ if old_admin else admin.ModelAdmin
    if old_admin:
        admin.site.unregister(Apartment)
    class ApartmentAdmin(old_cls):
        def get_urls(self):
            urls = super().get_urls()
            custom = [path('<int:apartment_id>/kartoteka/', self.admin_site.admin_view(self.apartment_card_view), name='communities_apartment_card')]
            return custom + urls
        def apartment_card_view(self, request, apartment_id):
            apartment = Apartment.objects.get(id=apartment_id)
            return HttpResponse(apartment_card_html(apartment))
        def kartoteka_link(self, obj):
            url = reverse('admin:communities_apartment_card', args=[obj.id])
            return format_html('<a class="button" href="{}">Kartoteka</a>', url)
        kartoteka_link.short_description = 'Kartoteka'
        def get_list_display(self, request):
            base = list(super().get_list_display(request))
            if 'kartoteka_link' not in base:
                base.append('kartoteka_link')
            return tuple(base)
    admin.site.register(Apartment, ApartmentAdmin)
patch_apartment_admin()
