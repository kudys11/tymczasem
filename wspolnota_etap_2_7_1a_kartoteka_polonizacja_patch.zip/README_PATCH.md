# Patch Etap 2.7.1a - polonizacja i kosmetyka kartoteki

Bez migracji.

Zmiany:
- polskie nazwy statusów: Szkic, Zatwierdzony itd.
- polskie typy właścicieli i relacji,
- data przeliczenia salda usunięta z kartoteki,
- daty skrócone do YYYY-MM-DD,
- nadpłaty i niedopłaty kolorowane,
- link Kartoteka otwiera się w nowym oknie,
- na kartotece jest przycisk powrotu do listy lokali.

## Instalacja

```bash
cd /opt/_docker-compose/wspolnota
unzip wspolnota_etap_2_7_1a_kartoteka_polonizacja_patch.zip
python3 patch_etap_2_7_1a_kartoteka_polonizacja.py
docker compose down
docker compose build --no-cache
docker compose up -d
docker compose exec web python manage.py check
```
