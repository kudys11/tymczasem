# Patch Etap 2.7.1b - kartoteka, udziały i kolory

Bez migracji.

Zmiany:
- dodatnie saldo = nadpłata = zielone,
- ujemne saldo = zaległość = czerwone,
- rozliczenia mediów pokazują `Nadpłata` / `Niedopłata` bez znaku minus,
- `active` -> `Aktywny`,
- udział lokalu można ukryć/pokazać ustawieniem systemowym,
- komenda wyliczania udziałów z powierzchni.

## Instalacja

```bash
cd /opt/_docker-compose/wspolnota
unzip wspolnota_etap_2_7_1b_kartoteka_udzialy_patch.zip
python3 patch_etap_2_7_1b_kartoteka_udzialy.py
docker compose down
docker compose build --no-cache
docker compose up -d
docker compose exec web python manage.py check
```

## Ukrycie udziałów w kartotece

```bash
docker compose exec web python manage.py set_show_shares --show nie
```

## Pokazanie udziałów w kartotece

```bash
docker compose exec web python manage.py set_show_shares --show tak
```

## Podgląd wyliczenia udziałów

```bash
docker compose exec web python manage.py calculate_area_shares
```

## Zapis wyliczonych udziałów

```bash
docker compose exec web python manage.py calculate_area_shares --apply
```
