#!/usr/bin/env python3
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "patch_files"

files = {
    "apps/communities/admin_kartoteka.py": SRC / "admin_kartoteka.py",
    "apps/communities/management/__init__.py": SRC / "init.py",
    "apps/communities/management/commands/__init__.py": SRC / "init.py",
    "apps/communities/management/commands/calculate_area_shares.py": SRC / "calculate_area_shares.py",
    "apps/audit/management/__init__.py": SRC / "init.py",
    "apps/audit/management/commands/__init__.py": SRC / "init.py",
    "apps/audit/management/commands/set_show_shares.py": SRC / "set_show_shares.py",
}

for rel, src in files.items():
    dst = ROOT / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    if src.name == "init.py":
        dst.write_text("", encoding="utf-8")
    else:
        shutil.copyfile(src, dst)

admin_file = ROOT / "apps" / "communities" / "admin.py"
txt = admin_file.read_text(encoding="utf-8")
line = "\n# Kartoteka lokalu\nfrom . import admin_kartoteka  # noqa\n"
if "admin_kartoteka" not in txt:
    admin_file.write_text(txt.rstrip() + line, encoding="utf-8")

print("OK: Etap 2.7.1b kartoteka, udziały i kolory został naniesiony.")
print("Nie wykonuj makemigrations ani migrate - ta poprawka nie zmienia struktury bazy.")
