from decimal import Decimal

from django.contrib import admin
from django.http import HttpResponse
from django.urls import path, reverse
from django.utils.html import format_html
from django.utils.safestring import mark_safe
from django.db.models import Sum

from apps.communities.models import Apartment
from apps.people.models import ApartmentOwnership, ApartmentPerson
from apps.finance.models import Payment, OwnerBalance
from apps.fees.models import MonthlyCharge, ChargeAdjustment
from apps.meters.models import Meter, MeterReading, UtilitySettlement


STATUS_LABELS = {
    "active": "Aktywny",
    "inactive": "Nieaktywny",
    "suspended": "Zawieszony",
    "sold": "Sprzedany",
    "draft": "Szkic",
    "approved": "Zatwierdzony",
    "confirmed": "Potwierdzony",
    "cancelled": "Anulowany",
    "rejected": "Odrzucony",
    "pending": "Oczekuje",
    "new": "Nowy",
}

OWNERSHIP_LABELS = {
    "single_owner": "Właściciel",
    "co_owner": "Współwłaściciel",
    "usufructuary": "Użytkownik",
    "other": "Inne",
}

RELATION_LABELS = {
    "owner": "Właściciel",
    "co_owner": "Współwłaściciel",
    "tenant": "Najemca",
    "resident": "Lokator",
    "other": "Inne",
}

ADJUSTMENT_LABELS = {
    "settlement": "Rozliczenie mediów",
    "correction": "Korekta",
    "discount": "Obniżka",
    "surcharge": "Dopłata",
    "other": "Inne",
}


def get_setting_bool(key, default=False):
    try:
        from apps.audit.models import SystemSetting
        obj = SystemSetting.objects.filter(key=key).first()
        if not obj:
            return default
        val = str(getattr(obj, "value", "") or "").strip().lower()
        return val in ("1", "true", "tak", "yes", "on", "t")
    except Exception:
        return default


def label(value, mapping):
    return mapping.get(value, value or "-")


def only_date(value):
    if not value:
        return "-"
    try:
        if hasattr(value, "date"):
            return value.date().isoformat()
        return str(value)[:10]
    except Exception:
        return str(value)


def money_plain(value):
    if value is None:
        value = Decimal("0.00")
    value = abs(Decimal(value))
    return f"{value:.2f} zł".replace(".", ",")


def money_balance(value):
    """Saldo: dodatnie = nadpłata = zielone, ujemne = zaległość = czerwone."""
    value = Decimal(value or 0)
    css = "money-plus" if value >= 0 else "money-minus"
    return f'<span class="{css}">{money_plain(value)}</span>'


def money_difference(value):
    """Różnica mediów: ujemna = nadpłata, dodatnia = niedopłata."""
    value = Decimal(value or 0)
    if value < 0:
        return f'<span class="money-plus">Nadpłata {money_plain(value)}</span>'
    if value > 0:
        return f'<span class="money-minus">Niedopłata {money_plain(value)}</span>'
    return "0,00 zł"


def safe_obj(obj):
    return obj if obj else "-"


def share_text(apartment):
    num = Decimal(getattr(apartment, "share_numerator", 0) or 0)
    den = Decimal(getattr(apartment, "share_denominator", 0) or 0)
    if den <= 0:
        return "Nie ustawiono"
    if num <= 0:
        return "Nie ustawiono"
    percent = (num / den * Decimal("100")).quantize(Decimal("0.0001"))
    return f"{int(num)}/{int(den)} ({percent}%)"


def apartment_card_html(apartment):
    show_shares = get_setting_bool("pokazuj_udzialy_lokali", False)

    owners = ApartmentOwnership.objects.filter(apartment=apartment, is_active=True).select_related("person").order_by("-is_primary_owner", "id")
    residents = ApartmentPerson.objects.filter(apartment=apartment, is_active=True).select_related("person").order_by("relation_type", "id")
    balances = OwnerBalance.objects.filter(apartment=apartment).select_related("person")
    balance_total = balances.aggregate(s=Sum("balance_total"))["s"] or Decimal("0.00")
    charges_qs = MonthlyCharge.objects.filter(apartment=apartment)
    charges = charges_qs.order_by("-year", "-month", "-id")[:12]
    charge_total = charges_qs.exclude(status="cancelled").aggregate(s=Sum("total_amount"))["s"] or Decimal("0.00")
    payments_qs = Payment.objects.filter(apartment=apartment)
    payments = payments_qs.order_by("-payment_date", "-id")[:12]
    payment_total = payments_qs.filter(is_confirmed=True).aggregate(s=Sum("amount"))["s"] or Decimal("0.00")
    meters = Meter.objects.filter(apartment=apartment, is_active=True).select_related("meter_type").order_by("meter_type__name", "id")
    meter_ids = list(meters.values_list("id", flat=True))
    readings = MeterReading.objects.filter(meter_id__in=meter_ids).select_related("meter", "meter__meter_type").order_by("-reading_date", "-id")[:12]
    settlements = UtilitySettlement.objects.filter(apartment=apartment).select_related("period", "meter").order_by("-id")[:12]
    adjustments = ChargeAdjustment.objects.filter(monthly_charge__apartment=apartment).select_related("monthly_charge", "fee_type").order_by("-created_at", "-id")[:12]

    def rows(items, renderer, empty="Brak danych"):
        rendered = "".join(renderer(x) for x in items)
        return rendered or f"<tr><td colspan='10'>{empty}</td></tr>"

    owners_rows = rows(owners, lambda o: f"<tr><td>{safe_obj(o.person)}</td><td>{label(o.ownership_type, OWNERSHIP_LABELS)}</td><td>{o.share_numerator}/{o.share_denominator}</td><td>{'Tak' if o.is_primary_owner else 'Nie'}</td></tr>")
    residents_rows = rows(residents, lambda r: f"<tr><td>{safe_obj(r.person)}</td><td>{label(r.relation_type, RELATION_LABELS)}</td><td>{only_date(r.valid_from)}</td><td>{only_date(r.valid_to)}</td></tr>")
    balances_rows = rows(balances, lambda b: f"<tr><td>{safe_obj(b.person)}</td><td>{money_balance(b.balance_total)}</td></tr>")
    charges_rows = rows(charges, lambda c: f"<tr><td>{c.year}/{c.month:02d}</td><td>{money_plain(c.total_amount)}</td><td>{label(c.status, STATUS_LABELS)}</td></tr>")
    payments_rows = rows(payments, lambda p: f"<tr><td>{only_date(p.payment_date)}</td><td>{money_plain(p.amount)}</td><td>{safe_obj(p.person)}</td><td>{p.title or ''}</td><td>{'Tak' if p.is_confirmed else 'Nie'}</td></tr>")
    meters_rows = rows(meters, lambda m: f"<tr><td>{safe_obj(m.meter_type)}</td><td>{getattr(m, 'serial_number', '') or getattr(m, 'number', '') or '-'}</td><td>{getattr(m, 'seal_number', '') or '-'}</td><td>{'Tak' if m.is_active else 'Nie'}</td></tr>")
    readings_rows = rows(readings, lambda r: f"<tr><td>{only_date(r.reading_date)}</td><td>{safe_obj(r.meter.meter_type)}</td><td>{r.value}</td><td>{r.source}</td><td>{label(r.status, STATUS_LABELS)}</td></tr>")
    settlements_rows = rows(settlements, lambda s: f"<tr><td>{safe_obj(s.period)}</td><td>{s.consumption}</td><td>{money_plain(s.advance_amount)}</td><td>{money_plain(s.actual_amount)}</td><td>{money_difference(s.difference_amount)}</td><td>{label(s.status, STATUS_LABELS)}</td></tr>")
    adjustments_rows = rows(adjustments, lambda a: f"<tr><td>{a.monthly_charge.year}/{a.monthly_charge.month:02d}</td><td>{safe_obj(a.fee_type)}</td><td>{'Nadpłata' if Decimal(a.amount or 0) < 0 else 'Niedopłata' if Decimal(a.amount or 0) > 0 else label(a.adjustment_type, ADJUSTMENT_LABELS)}</td><td>{money_difference(a.amount)}</td><td>{a.description}</td></tr>")

    back_url = reverse("admin:communities_apartment_changelist")

    share_card = ""
    if show_shares:
        share_card = f'<div class="stat-card">Udział<strong>{share_text(apartment)}</strong></div>'

    html = f"""
    <style>
      body {{ padding: 18px; }}
      .top-actions {{ margin: 0 0 16px 0; }}
      .top-actions a {{ display:inline-block; padding:8px 12px; border:1px solid #ccc; border-radius:6px; background:#f5f5f5; text-decoration:none; color:#222; }}
      .card-grid {{ display:grid; grid-template-columns: repeat(4, minmax(160px, 1fr)); gap:12px; margin:16px 0; }}
      .stat-card {{ background:#f8f8f8; border:1px solid #ddd; border-radius:8px; padding:12px; }}
      .stat-card strong {{ display:block; font-size:18px; margin-top:4px; }}
      .section {{ margin-top:24px; }}
      .section h2 {{ border-bottom:1px solid #ddd; padding-bottom:6px; }}
      .wm-table {{ width:100%; border-collapse:collapse; margin-top:8px; }}
      .wm-table th, .wm-table td {{ border:1px solid #ddd; padding:6px 8px; vertical-align:top; }}
      .wm-table th {{ background:#f0f0f0; text-align:left; }}
      .money-plus {{ color:#128a34; font-weight:700; }}
      .money-minus {{ color:#b00020; font-weight:700; }}
    </style>

    <div class="top-actions"><a href="{back_url}">← Powrót do listy lokali</a></div>
    <h1>Kartoteka lokalu: {apartment}</h1>

    <div class="card-grid">
      <div class="stat-card">Powierzchnia lokalu<strong>{apartment.apartment_area} m²</strong></div>
      <div class="stat-card">Liczba mieszkańców<strong>{apartment.residents_count}</strong></div>
      <div class="stat-card">Suma naliczeń<strong>{money_plain(charge_total)}</strong></div>
      <div class="stat-card">Suma wpłat<strong>{money_plain(payment_total)}</strong></div>
      <div class="stat-card">Saldo<strong>{money_balance(balance_total)}</strong></div>
      <div class="stat-card">Status<strong>{label(getattr(apartment, 'status', 'active'), STATUS_LABELS)}</strong></div>
      {share_card}
      <div class="stat-card">Aktywny<strong>{'Tak' if apartment.is_active else 'Nie'}</strong></div>
    </div>

    <div class="section"><h2>Właściciele</h2><table class="wm-table"><tr><th>Osoba</th><th>Typ</th><th>Udział</th><th>Główny</th></tr>{owners_rows}</table></div>
    <div class="section"><h2>Osoby powiązane z lokalem</h2><table class="wm-table"><tr><th>Osoba</th><th>Relacja</th><th>Od</th><th>Do</th></tr>{residents_rows}</table></div>
    <div class="section"><h2>Salda</h2><table class="wm-table"><tr><th>Osoba</th><th>Saldo</th></tr>{balances_rows}</table></div>
    <div class="section"><h2>Ostatnie naliczenia</h2><table class="wm-table"><tr><th>Okres</th><th>Kwota</th><th>Status</th></tr>{charges_rows}</table></div>
    <div class="section"><h2>Ostatnie wpłaty</h2><table class="wm-table"><tr><th>Data</th><th>Kwota</th><th>Osoba</th><th>Tytuł</th><th>Potwierdzona</th></tr>{payments_rows}</table></div>
    <div class="section"><h2>Liczniki</h2><table class="wm-table"><tr><th>Typ</th><th>Numer seryjny</th><th>Plomba</th><th>Aktywny</th></tr>{meters_rows}</table></div>
    <div class="section"><h2>Ostatnie odczyty</h2><table class="wm-table"><tr><th>Data</th><th>Typ</th><th>Wartość</th><th>Źródło</th><th>Status</th></tr>{readings_rows}</table></div>
    <div class="section"><h2>Rozliczenia mediów</h2><table class="wm-table"><tr><th>Okres</th><th>Zużycie</th><th>Zaliczki</th><th>Koszt</th><th>Wynik</th><th>Status</th></tr>{settlements_rows}</table></div>
    <div class="section"><h2>Korekty naliczeń</h2><table class="wm-table"><tr><th>Okres</th><th>Typ</th><th>Rodzaj</th><th>Kwota</th><th>Opis</th></tr>{adjustments_rows}</table></div>
    """
    return mark_safe(html)


def patch_apartment_admin():
    try:
        old_admin = admin.site._registry.get(Apartment)
        if old_admin:
            old_cls = old_admin.__class__
            admin.site.unregister(Apartment)
        else:
            old_cls = admin.ModelAdmin
    except Exception:
        old_cls = admin.ModelAdmin

    class ApartmentAdmin(old_cls):
        def get_urls(self):
            urls = super().get_urls()
            custom = [path("<int:apartment_id>/kartoteka/", self.admin_site.admin_view(self.apartment_card_view), name="communities_apartment_card")]
            return custom + urls

        def apartment_card_view(self, request, apartment_id):
            apartment = Apartment.objects.get(id=apartment_id)
            return HttpResponse(apartment_card_html(apartment))

        def kartoteka_link(self, obj):
            url = reverse("admin:communities_apartment_card", args=[obj.id])
            return format_html('<a class="button" href="{}" target="_blank" rel="noopener">Kartoteka ↗</a>', url)

        kartoteka_link.short_description = "Kartoteka"

        def get_list_display(self, request):
            base = list(super().get_list_display(request))
            if "kartoteka_link" not in base:
                base.append("kartoteka_link")
            return tuple(base)

    admin.site.register(Apartment, ApartmentAdmin)


patch_apartment_admin()
