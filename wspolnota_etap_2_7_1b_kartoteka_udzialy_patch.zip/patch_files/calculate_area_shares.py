from decimal import Decimal

from django.core.management.base import BaseCommand

from apps.communities.models import Apartment


class Command(BaseCommand):
    help = "Wylicza udziały lokali według powierzchni lokalu + aktywnych pomieszczeń przynależnych."

    def add_arguments(self, parser):
        parser.add_argument("--apply", action="store_true", help="Zapisuje wyliczone udziały do lokali.")
        parser.add_argument("--scale", type=int, default=100, help="Mnożnik do zapisu udziałów, domyślnie 100.")
        parser.add_argument("--community-id", type=int, default=None)

    def handle(self, *args, **options):
        apply = options["apply"]
        scale = Decimal(options["scale"])
        community_id = options.get("community_id")

        qs = Apartment.objects.filter(is_active=True).prefetch_related("attached_rooms")
        if community_id:
            qs = qs.filter(community_id=community_id)

        apartments = list(qs.order_by("building__name", "number"))

        areas = {}
        total = Decimal("0.00")

        for apt in apartments:
            area = Decimal(apt.apartment_area or 0)
            for room in apt.attached_rooms.filter(is_active=True, included_in_common_fees=True):
                area += Decimal(room.area or 0)
            areas[apt.id] = area
            total += area

        if total <= 0:
            self.stdout.write(self.style.ERROR("Suma powierzchni wynosi 0. Nie można wyliczyć udziałów."))
            return

        denominator = int((total * scale).quantize(Decimal("1")))

        for apt in apartments:
            numerator = int((areas[apt.id] * scale).quantize(Decimal("1")))
            percent = (areas[apt.id] / total * Decimal("100")).quantize(Decimal("0.0001"))
            self.stdout.write(f"{apt}: area={areas[apt.id]} udział={numerator}/{denominator} ({percent}%)")
            if apply:
                apt.share_numerator = numerator
                apt.share_denominator = denominator
                apt.save(update_fields=["share_numerator", "share_denominator"])

        if apply:
            self.stdout.write(self.style.SUCCESS("Udziały zostały zapisane."))
        else:
            self.stdout.write(self.style.WARNING("Tryb podglądu. Dodaj --apply aby zapisać udziały."))
