from django.core.management.base import BaseCommand

from apps.audit.models import SystemSetting


class Command(BaseCommand):
    help = "Ustawia widoczność udziałów lokali w kartotece."

    def add_arguments(self, parser):
        parser.add_argument("--show", choices=["tak", "nie"], required=True)

    def handle(self, *args, **options):
        value = "tak" if options["show"] == "tak" else "nie"
        obj, created = SystemSetting.objects.get_or_create(
            key="pokazuj_udzialy_lokali",
            defaults={
                "value": value,
                "description": "Czy pokazywać udział lokalu w kartotece.",
            },
        )
        if not created:
            obj.value = value
            obj.description = "Czy pokazywać udział lokalu w kartotece."
            obj.save()

        self.stdout.write(self.style.SUCCESS(f"pokazuj_udzialy_lokali = {value}"))
