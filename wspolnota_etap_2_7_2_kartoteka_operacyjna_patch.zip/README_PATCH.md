# Patch Etap 2.7.2 - kartoteka operacyjna lokalu

Bez migracji.

Dodaje:
- szybkie podsumowanie właściciela,
- przyciski akcji: edycja lokalu, dodaj wpłatę, dodaj odczyt, dodaj dokument, PDF/drukuj, wyślij e-mailem,
- historię rozrachunku lokalu,
- widok PDF/drukuj przez przeglądarkę.

Uwaga: przycisk "Wyślij e-mailem" jest na razie placeholderem. Pełna obsługa poczty SMTP będzie osobnym etapem.

## Instalacja

```bash
cd /opt/_docker-compose/wspolnota
unzip wspolnota_etap_2_7_2_kartoteka_operacyjna_patch.zip
python3 patch_etap_2_7_2_kartoteka_operacyjna.py
docker compose down
docker compose build --no-cache
docker compose up -d
docker compose exec web python manage.py check
```
