# Patch Etap 2.7.2a - spójne saldo kartoteki i kompaktowy PDF

Bez migracji.

Zmiany:
- saldo właściciela liczone z tej samej historii co tabela rozrachunku,
- historia rozrachunku ma znaki +/- również w kolumnie "Saldo po operacji",
- kolejność operacji w tym samym dniu: naliczenie -> korekta -> wpłata,
- PDF/druk ma mniejsze czcionki i ciasny układ A4.

## Instalacja

```bash
cd /opt/_docker-compose/wspolnota
unzip wspolnota_etap_2_7_2a_kartoteka_saldo_pdf_patch.zip
python3 patch_etap_2_7_2a_kartoteka_saldo_pdf.py
docker compose down
docker compose build --no-cache
docker compose up -d
docker compose exec web python manage.py check
```
