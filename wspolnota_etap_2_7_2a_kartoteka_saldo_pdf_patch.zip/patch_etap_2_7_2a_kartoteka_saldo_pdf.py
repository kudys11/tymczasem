#!/usr/bin/env python3
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "patch_files"

target = ROOT / "apps" / "communities" / "admin_kartoteka.py"
target.parent.mkdir(parents=True, exist_ok=True)
shutil.copyfile(SRC / "admin_kartoteka.py", target)

admin_file = ROOT / "apps" / "communities" / "admin.py"
txt = admin_file.read_text(encoding="utf-8")
line = "\n# Kartoteka lokalu\nfrom . import admin_kartoteka  # noqa\n"
if "admin_kartoteka" not in txt:
    admin_file.write_text(txt.rstrip() + line, encoding="utf-8")

print("OK: Etap 2.7.2a saldo kartoteki i kompaktowy PDF został naniesiony.")
print("Nie wykonuj makemigrations ani migrate - ta poprawka nie zmienia struktury bazy.")
