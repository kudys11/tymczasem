# Etap 2.7.6a - Centrum raportów

Bez migracji.

Dodaje:
- widok `/admin/raporty/`,
- pozycję `Centrum raportów` w panelu admina,
- kafelki raportów,
- formularz daty raportu,
- szybkie linki do kosztów, wpłat, sald, lokali i rozliczeń mediów.

## Instalacja

```bash
cd /opt/_docker-compose/wspolnota
unzip wspolnota_etap_2_7_6a_centrum_raportow_patch.zip
python3 patch_etap_2_7_6a_centrum_raportow.py
docker compose down
docker compose build --no-cache
docker compose up -d
docker compose exec web python manage.py check
```

## Użycie

```text
/admin/raporty/
```

albo w panelu admina:

```text
Audit -> Centrum raportów
```
