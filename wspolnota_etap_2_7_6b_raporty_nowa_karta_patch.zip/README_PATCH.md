# Etap 2.7.6b - raporty i szybkie przejścia w nowej karcie

Bez migracji.

Zmiany:
- raporty w Centrum raportów otwierają się w nowej karcie,
- szybkie przejścia otwierają się w nowej karcie,
- linki mają `target="_blank"` i `rel="noopener"`.

## Instalacja

```bash
cd /opt/_docker-compose/wspolnota
unzip wspolnota_etap_2_7_6b_raporty_nowa_karta_patch.zip
python3 patch_etap_2_7_6b_raporty_nowa_karta.py
docker compose down
docker compose build --no-cache
docker compose up -d
docker compose exec web python manage.py check
```
