#!/usr/bin/env python3
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "patch_files"

target = ROOT / "apps" / "audit" / "admin_reports_center.py"
target.parent.mkdir(parents=True, exist_ok=True)
shutil.copyfile(SRC / "admin_reports_center.py", target)

admin_file = ROOT / "apps" / "audit" / "admin.py"
txt = admin_file.read_text(encoding="utf-8")
line = "\n# Etap 2.7.6a/2.7.6b - centrum raportów\nfrom . import admin_reports_center  # noqa\n"
if "admin_reports_center" not in txt:
    admin_file.write_text(txt.rstrip() + line, encoding="utf-8")

print("OK: Etap 2.7.6b - raporty i szybkie przejścia otwierają się w nowej karcie.")
print("Nie wykonuj makemigrations ani migrate.")
