from datetime import date, datetime

from django.contrib import admin
from django.db import models
from django.http import HttpResponse
from django.urls import path, reverse


class ReportCenter(models.Model):
    class Meta:
        managed = False
        app_label = "audit"
        verbose_name = "Centrum raportów"
        verbose_name_plural = "Centrum raportów"


def reports_index_view(request):
    today = date.today()
    default_date = request.GET.get("date") or f"{today.year}-12-31"
    try:
        datetime.strptime(default_date, "%Y-%m-%d")
    except ValueError:
        default_date = today.isoformat()

    try:
        financial_url = reverse("admin:financial_summary_report") + f"?date={default_date}"
    except Exception:
        financial_url = f"/admin/raporty/bilans-finansowy/?date={default_date}"

    html = f"""
    <style>
      body {{ font-family: Arial, sans-serif; padding: 18px; background:#fff; color:#0f172a; }}
      .topbar {{ display:flex; justify-content:space-between; align-items:flex-start; gap:16px; margin-bottom:18px; }}
      h1 {{ margin:0; font-size:28px; }}
      .subtitle {{ color:#64748b; margin-top:5px; }}
      .date-box {{ border:1px solid #dfe5ec; padding:12px; border-radius:8px; background:#f8fafc; }}
      .date-box input {{ padding:7px 9px; }}
      .date-box button {{ padding:8px 12px; cursor:pointer; }}
      .grid {{ display:grid; grid-template-columns: repeat(3, minmax(220px, 1fr)); gap:16px; margin-top:16px; }}
      .card {{ border:1px solid #dfe5ec; border-radius:10px; padding:16px; background:#fff; box-shadow:0 1px 2px rgba(15,23,42,.04); }}
      .card h2 {{ margin:0 0 8px 0; font-size:19px; }}
      .card p {{ color:#64748b; min-height:38px; }}
      .card a {{ display:inline-block; margin-top:8px; border:1px solid #cbd5e1; border-radius:6px; padding:8px 12px; text-decoration:none; color:#0f172a; font-weight:600; background:#f8fafc; }}
      .disabled {{ opacity:.55; }}
      .section-title {{ margin-top:26px; font-size:22px; }}
      .quick-links {{ display:flex; flex-wrap:wrap; gap:8px; margin-top:10px; }}
      .quick-links a {{ border:1px solid #dfe5ec; border-radius:6px; padding:8px 10px; text-decoration:none; color:#0f172a; background:#fff; }}
      .note {{ color:#64748b; margin-top:20px; font-size:13px; }}
      @media (max-width: 900px) {{ .grid {{ grid-template-columns:1fr; }} .topbar {{ display:block; }} .date-box {{ margin-top:12px; }} }}
    </style>

    <div class="topbar">
      <div>
        <h1>📊 Centrum raportów</h1>
        <div class="subtitle">Raporty i analizy wspólnoty mieszkaniowej</div>
      </div>
      <form class="date-box" method="get">
        <label>Data raportu:
          <input type="date" name="date" value="{default_date}">
        </label>
        <button type="submit">Ustaw datę</button>
      </form>
    </div>

    <div class="grid">
      <div class="card">
        <h2>📊 Bilans finansowy</h2>
        <p>Saldo właścicieli, rachunki bankowe, koszty, media, nadpłaty i zaległości.</p>
        <a href="{financial_url}" target="_blank" rel="noopener">Otwórz raport ↗</a>
      </div>
      <div class="card disabled"><h2>💧 Rozliczenia mediów</h2><p>Zestawienie zaliczek, kosztów, nadpłat i niedopłat.</p><a href="{financial_url}" target="_blank" rel="noopener">W przygotowaniu ↗</a></div>
      <div class="card disabled"><h2>⚠️ Zaległości właścicieli</h2><p>Lista lokali z największymi zaległościami.</p><a href="{financial_url}" target="_blank" rel="noopener">W przygotowaniu ↗</a></div>
      <div class="card disabled"><h2>💰 Nadpłaty właścicieli</h2><p>Lista lokali z nadpłatami.</p><a href="{financial_url}" target="_blank" rel="noopener">W przygotowaniu ↗</a></div>
      <div class="card disabled"><h2>👥 Salda właścicieli</h2><p>Pełna lista sald właścicieli i lokali.</p><a href="{financial_url}" target="_blank" rel="noopener">W przygotowaniu ↗</a></div>
      <div class="card disabled"><h2>📄 Sprawozdanie roczne</h2><p>Raport roczny wspólnoty gotowy do PDF.</p><a href="{financial_url}" target="_blank" rel="noopener">W przygotowaniu ↗</a></div>
    </div>

    <h2 class="section-title">Szybkie przejścia</h2>
    <div class="quick-links">
      <a href="/admin/finance/expensedocument/" target="_blank" rel="noopener">Koszty wspólnoty ↗</a>
      <a href="/admin/finance/costcategory/" target="_blank" rel="noopener">Kategorie kosztów ↗</a>
      <a href="/admin/finance/vendor/" target="_blank" rel="noopener">Kontrahenci ↗</a>
      <a href="/admin/finance/payment/" target="_blank" rel="noopener">Wpłaty ↗</a>
      <a href="/admin/finance/ownerbalance/" target="_blank" rel="noopener">Salda właścicieli ↗</a>
      <a href="/admin/communities/apartment/" target="_blank" rel="noopener">Lokale ↗</a>
      <a href="/admin/meters/utilitysettlement/" target="_blank" rel="noopener">Rozliczenia mediów ↗</a>
    </div>

    <p class="note">Raporty i szybkie przejścia otwierają się w nowej karcie, żeby nie tracić miejsca pracy w centrum raportów.</p>
    """
    return HttpResponse(html)


class ReportCenterAdmin(admin.ModelAdmin):
    def has_add_permission(self, request):
        return False
    def has_delete_permission(self, request, obj=None):
        return False
    def has_view_permission(self, request, obj=None):
        return True
    def changelist_view(self, request, extra_context=None):
        return reports_index_view(request)


try:
    admin.site.unregister(ReportCenter)
except Exception:
    pass

admin.site.register(ReportCenter, ReportCenterAdmin)

_original_get_urls = admin.site.get_urls

def get_urls():
    urls = _original_get_urls()
    custom = [path("raporty/", admin.site.admin_view(reports_index_view), name="reports_center")]
    return custom + urls

if not getattr(admin.site, "_reports_center_patched", False):
    admin.site.get_urls = get_urls
    admin.site._reports_center_patched = True
