# Etap 2.7.7.1 - Załączniki dokumentów

Dodaje:
- model `DocumentAttachment`,
- załączniki do zwykłych dokumentów,
- załączniki do kosztów wspólnoty,
- osobne menu `Documents -> Załączniki dokumentów`,
- inline załączników w `Finance -> Koszty wspólnoty`.

## Ważne

Aplikacja `documents` miała już tabele w bazie, ale nie miała migracji. Dlatego wdrożenie wygląda tak:

```bash
cd /opt/_docker-compose/wspolnota
unzip wspolnota_etap_2_7_7_1_zalaczniki_dokumentow_patch.zip
python3 patch_etap_2_7_7_1_zalaczniki_dokumentow.py
docker compose down
docker compose build --no-cache
docker compose up -d
docker compose exec web python manage.py migrate documents 0001 --fake
docker compose exec web python manage.py migrate documents
docker compose exec web python manage.py check
```

## Sprawdzenie

```bash
docker compose exec web python manage.py showmigrations documents
```

Powinno być:

```text
[X] 0001_initial
[X] 0002_document_attachment
```
