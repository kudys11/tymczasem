#!/usr/bin/env python3
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "patch_files"

models_file = ROOT / "apps" / "documents" / "models.py"
models_txt = models_file.read_text(encoding="utf-8")
if "class DocumentAttachment(models.Model):" not in models_txt:
    models_file.write_text(models_txt.rstrip() + "\n\n" + (SRC / "models_document_attachment.py").read_text(encoding="utf-8") + "\n", encoding="utf-8")

mig_dir = ROOT / "apps" / "documents" / "migrations"
mig_dir.mkdir(parents=True, exist_ok=True)
init_file = mig_dir / "__init__.py"
init_file.touch()

shutil.copyfile(SRC / "0001_initial.py", mig_dir / "0001_initial.py")
shutil.copyfile(SRC / "0002_document_attachment.py", mig_dir / "0002_document_attachment.py")

admin_file = ROOT / "apps" / "documents" / "admin.py"
admin_txt = admin_file.read_text(encoding="utf-8")
if "Etap 2.7.7.1 - Załączniki dokumentów" not in admin_txt:
    admin_file.write_text(admin_txt.rstrip() + "\n\n" + (SRC / "admin_document_attachment.py").read_text(encoding="utf-8") + "\n", encoding="utf-8")

finance_admin = ROOT / "apps" / "finance" / "admin.py"
if finance_admin.exists():
    txt = finance_admin.read_text(encoding="utf-8")
    if "Inline załączników przy kosztach" not in txt:
        finance_admin.write_text(txt.rstrip() + "\n\n" + (SRC / "finance_admin_inline_attachment.py").read_text(encoding="utf-8") + "\n", encoding="utf-8")

print("OK: Etap 2.7.7.1 Załączniki dokumentów został naniesiony.")
print("Uwaga: wykonaj najpierw migrate documents 0001 --fake, potem migrate documents.")
