# Repair migration state for existing documents tables.
from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    initial = True

    dependencies = [
        ("communities", "0001_initial"),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name="DocumentCategory",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(max_length=255)),
                ("is_active", models.BooleanField(default=True)),
                ("sort_order", models.PositiveIntegerField(default=100)),
                ("community", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="document_categories", to="communities.community")),
            ],
            options={
                "ordering": ("sort_order", "name"),
            },
        ),
        migrations.CreateModel(
            name="Document",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("title", models.CharField(max_length=255)),
                ("description", models.TextField(blank=True)),
                ("file", models.FileField(upload_to="documents/")),
                ("document_date", models.DateField(blank=True, null=True)),
                ("visibility", models.CharField(default="private", max_length=30)),
                ("is_public", models.BooleanField(default=False)),
                ("visible_from", models.DateField(blank=True, null=True)),
                ("visible_to", models.DateField(blank=True, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("category", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="documents", to="documents.documentcategory")),
                ("community", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="documents", to="communities.community")),
                ("uploaded_by", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="uploaded_documents", to=settings.AUTH_USER_MODEL)),
                ("apartments", models.ManyToManyField(blank=True, related_name="documents", to="communities.apartment")),
            ],
            options={
                "ordering": ("-document_date", "-id"),
            },
        ),
    ]
