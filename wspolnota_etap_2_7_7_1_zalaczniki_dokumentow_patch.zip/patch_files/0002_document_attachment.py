from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ("documents", "0001_initial"),
        ("finance", "0002_cost_registry"),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name="DocumentAttachment",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("title", models.CharField(max_length=255, verbose_name="Nazwa załącznika")),
                ("attachment_type", models.CharField(choices=[("file", "Plik"), ("invoice", "Faktura"), ("photo", "Zdjęcie"), ("protocol", "Protokół"), ("contract", "Umowa"), ("other", "Inne")], default="file", max_length=30, verbose_name="Typ załącznika")),
                ("file", models.FileField(upload_to="documents/attachments/%Y/%m/", verbose_name="Plik")),
                ("description", models.TextField(blank=True, verbose_name="Opis")),
                ("is_active", models.BooleanField(default=True, verbose_name="Aktywny")),
                ("created_at", models.DateTimeField(auto_now_add=True, verbose_name="Utworzono")),
                ("updated_at", models.DateTimeField(auto_now=True, verbose_name="Zmieniono")),
                ("document", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.CASCADE, related_name="attachments", to="documents.document", verbose_name="Dokument")),
                ("expense_document", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.CASCADE, related_name="attachments", to="finance.expensedocument", verbose_name="Koszt wspólnoty")),
                ("uploaded_by", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to=settings.AUTH_USER_MODEL, verbose_name="Dodał")),
            ],
            options={
                "verbose_name": "Załącznik dokumentu",
                "verbose_name_plural": "Załączniki dokumentów",
                "ordering": ("-created_at", "-id"),
            },
        ),
    ]
