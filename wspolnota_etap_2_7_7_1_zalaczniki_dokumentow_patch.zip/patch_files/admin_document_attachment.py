# ================================================================
# Etap 2.7.7.1 - Załączniki dokumentów
# ================================================================
from django.utils.html import format_html

try:
    from .models import DocumentAttachment
except Exception:
    DocumentAttachment = None


if DocumentAttachment:

    @admin.register(DocumentAttachment)
    class DocumentAttachmentAdmin(admin.ModelAdmin):
        list_display = (
            "title",
            "attachment_type",
            "document",
            "expense_document",
            "is_active",
            "created_at",
            "file_link",
        )
        list_filter = ("attachment_type", "is_active", "created_at")
        search_fields = (
            "title",
            "description",
            "document__title",
            "expense_document__document_number",
            "expense_document__vendor__name",
        )
        autocomplete_fields = ("document", "expense_document", "uploaded_by")
        readonly_fields = ("created_at", "updated_at", "file_link")
        ordering = ("-created_at", "-id")

        def file_link(self, obj):
            if obj and obj.file:
                return format_html('<a href="{}" target="_blank" rel="noopener">Otwórz plik ↗</a>', obj.file.url)
            return "-"

        file_link.short_description = "Plik"
