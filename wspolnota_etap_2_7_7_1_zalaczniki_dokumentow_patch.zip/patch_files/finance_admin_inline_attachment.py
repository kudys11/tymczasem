# ================================================================
# Etap 2.7.7.1 - Inline załączników przy kosztach
# ================================================================
try:
    from apps.documents.models import DocumentAttachment
except Exception:
    DocumentAttachment = None

if DocumentAttachment and "ExpenseDocumentAdmin" in globals():

    class ExpenseDocumentAttachmentInline(admin.TabularInline):
        model = DocumentAttachment
        fk_name = "expense_document"
        extra = 0
        fields = ("title", "attachment_type", "file", "description", "is_active", "uploaded_by")
        autocomplete_fields = ("uploaded_by",)

    try:
        ExpenseDocumentAdmin.inlines = tuple(list(getattr(ExpenseDocumentAdmin, "inlines", ())) + [ExpenseDocumentAttachmentInline])
    except Exception:
        pass
