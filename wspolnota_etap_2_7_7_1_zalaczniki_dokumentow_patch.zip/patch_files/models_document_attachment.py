# ================================================================
# Etap 2.7.7.1 - Załączniki dokumentów
# ================================================================

class DocumentAttachment(models.Model):
    ATTACHMENT_TYPE_FILE = "file"
    ATTACHMENT_TYPE_INVOICE = "invoice"
    ATTACHMENT_TYPE_PHOTO = "photo"
    ATTACHMENT_TYPE_PROTOCOL = "protocol"
    ATTACHMENT_TYPE_CONTRACT = "contract"
    ATTACHMENT_TYPE_OTHER = "other"

    ATTACHMENT_TYPE_CHOICES = (
        (ATTACHMENT_TYPE_FILE, "Plik"),
        (ATTACHMENT_TYPE_INVOICE, "Faktura"),
        (ATTACHMENT_TYPE_PHOTO, "Zdjęcie"),
        (ATTACHMENT_TYPE_PROTOCOL, "Protokół"),
        (ATTACHMENT_TYPE_CONTRACT, "Umowa"),
        (ATTACHMENT_TYPE_OTHER, "Inne"),
    )

    document = models.ForeignKey(
        "documents.Document",
        on_delete=models.CASCADE,
        related_name="attachments",
        null=True,
        blank=True,
        verbose_name="Dokument",
    )
    expense_document = models.ForeignKey(
        "finance.ExpenseDocument",
        on_delete=models.CASCADE,
        related_name="attachments",
        null=True,
        blank=True,
        verbose_name="Koszt wspólnoty",
    )
    title = models.CharField("Nazwa załącznika", max_length=255)
    attachment_type = models.CharField(
        "Typ załącznika",
        max_length=30,
        choices=ATTACHMENT_TYPE_CHOICES,
        default=ATTACHMENT_TYPE_FILE,
    )
    file = models.FileField("Plik", upload_to="documents/attachments/%Y/%m/")
    description = models.TextField("Opis", blank=True)
    is_active = models.BooleanField("Aktywny", default=True)
    uploaded_by = models.ForeignKey(
        "auth.User",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name="Dodał",
    )
    created_at = models.DateTimeField("Utworzono", auto_now_add=True)
    updated_at = models.DateTimeField("Zmieniono", auto_now=True)

    class Meta:
        verbose_name = "Załącznik dokumentu"
        verbose_name_plural = "Załączniki dokumentów"
        ordering = ("-created_at", "-id")

    def __str__(self):
        return self.title
