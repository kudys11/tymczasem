# Etap 2.7.8 - Rejestr faktur i zobowiązań

Dodaje do `ExpenseDocument`:
- data sprzedaży / wykonania usługi,
- termin płatności,
- status płatności,
- kwota zapłacona,
- data zapłaty.

Dodaje widok:
- `/admin/raporty/faktury/`

## Instalacja

```bash
cd /opt/_docker-compose/wspolnota
unzip wspolnota_etap_2_7_8_rejestr_faktur_patch.zip
python3 patch_etap_2_7_8_rejestr_faktur.py
docker compose down
docker compose build --no-cache
docker compose up -d
docker compose exec web python manage.py migrate finance
docker compose exec web python manage.py check
```

## Sprawdzenie

```bash
docker compose exec web python manage.py showmigrations finance
```

Powinno być:
```text
[X] 0003_invoice_register
```

Widok:
```text
/admin/raporty/faktury/
```
