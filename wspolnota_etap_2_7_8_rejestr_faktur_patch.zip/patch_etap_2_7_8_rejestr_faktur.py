#!/usr/bin/env python3
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "patch_files"

models_file = ROOT / "apps" / "finance" / "models.py"
txt = models_file.read_text(encoding="utf-8")
if "Etap 2.7.8 - Rejestr faktur i zobowiązań" not in txt:
    models_file.write_text(txt.rstrip() + "\n\n" + (SRC / "models_invoice_register.py").read_text(encoding="utf-8") + "\n", encoding="utf-8")

mig = ROOT / "apps" / "finance" / "migrations" / "0003_invoice_register.py"
shutil.copyfile(SRC / "0003_invoice_register.py", mig)

admin_file = ROOT / "apps" / "finance" / "admin.py"
admin_txt = admin_file.read_text(encoding="utf-8")
if "Etap 2.7.8 - Rejestr faktur i zobowiązań" not in admin_txt:
    admin_file.write_text(admin_txt.rstrip() + "\n\n" + (SRC / "admin_invoice_register.py").read_text(encoding="utf-8") + "\n", encoding="utf-8")

report_file = ROOT / "apps" / "finance" / "admin_invoice_dashboard.py"
shutil.copyfile(SRC / "admin_invoice_dashboard.py", report_file)

# podpięcie raportu
if "admin_invoice_dashboard" not in admin_txt:
    admin_txt = admin_file.read_text(encoding="utf-8")
    admin_file.write_text(admin_txt.rstrip() + "\n\n# Etap 2.7.8 - dashboard faktur\nfrom . import admin_invoice_dashboard  # noqa\n", encoding="utf-8")

print("OK: Etap 2.7.8 Rejestr faktur i zobowiązań został naniesiony.")
print("Wykonaj build, migrate finance i check.")
