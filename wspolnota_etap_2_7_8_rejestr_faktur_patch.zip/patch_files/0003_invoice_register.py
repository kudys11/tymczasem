from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("finance", "0002_cost_registry"),
    ]

    operations = [
        migrations.AddField(
            model_name="expensedocument",
            name="sale_date",
            field=models.DateField(blank=True, null=True, verbose_name="Data sprzedaży / wykonania usługi"),
        ),
        migrations.AddField(
            model_name="expensedocument",
            name="due_date",
            field=models.DateField(blank=True, null=True, verbose_name="Termin płatności"),
        ),
        migrations.AddField(
            model_name="expensedocument",
            name="payment_status",
            field=models.CharField(
                choices=[
                    ("unpaid", "Do zapłaty"),
                    ("partial", "Częściowo zapłacona"),
                    ("paid", "Zapłacona"),
                    ("cancelled", "Anulowana"),
                ],
                default="unpaid",
                max_length=30,
                verbose_name="Status płatności",
            ),
        ),
        migrations.AddField(
            model_name="expensedocument",
            name="paid_amount",
            field=models.DecimalField(decimal_places=2, default=0, max_digits=12, verbose_name="Kwota zapłacona"),
        ),
        migrations.AddField(
            model_name="expensedocument",
            name="paid_date",
            field=models.DateField(blank=True, null=True, verbose_name="Data zapłaty"),
        ),
    ]
