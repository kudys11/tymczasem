from datetime import date
from decimal import Decimal

from django.contrib import admin
from django.http import HttpResponse
from django.urls import path

from apps.finance.models import ExpenseDocument


def _money(value):
    value = Decimal(value or 0)
    return f"{value:.2f} zł".replace(".", ",")


def invoice_dashboard_view(request):
    today = date.today()
    docs = ExpenseDocument.objects.exclude(status="cancelled")

    unpaid = docs.filter(payment_status="unpaid")
    partial = docs.filter(payment_status="partial")
    paid = docs.filter(payment_status="paid")

    overdue_list = []
    for d in docs.filter(payment_status__in=["unpaid", "partial"]):
        if d.due_date and d.due_date < today:
            overdue_list.append(d)

    unpaid_sum = sum((d.amount_left() for d in unpaid), Decimal("0.00"))
    partial_sum = sum((d.amount_left() for d in partial), Decimal("0.00"))
    overdue_sum = sum((d.amount_left() for d in overdue_list), Decimal("0.00"))

    rows = ""
    for d in sorted(overdue_list, key=lambda x: x.due_date or today)[:20]:
        rows += f"<tr><td>{d.due_date}</td><td>{d.document_number}</td><td>{d.vendor}</td><td>{_money(d.gross_amount)}</td><td class='minus'>{_money(d.amount_left())}</td></tr>"

    if not rows:
        rows = "<tr><td colspan='5'>Brak przeterminowanych faktur.</td></tr>"

    html = f"""
    <style>
      body {{ font-family:Arial,sans-serif; padding:18px; color:#0f172a; }}
      .grid {{ display:grid; grid-template-columns:repeat(4,minmax(160px,1fr)); gap:12px; margin:16px 0; }}
      .card {{ border:1px solid #dfe5ec; border-radius:8px; padding:14px; background:#fff; }}
      .card strong {{ display:block; font-size:20px; margin-top:6px; }}
      table {{ width:100%; border-collapse:collapse; margin-top:12px; }}
      th,td {{ border:1px solid #dfe5ec; padding:7px 9px; text-align:left; }}
      th {{ background:#f1f5f9; }}
      .plus {{ color:#0a8f3c; font-weight:700; }}
      .minus {{ color:#dc2626; font-weight:700; }}
      .actions a {{ display:inline-block; margin-right:8px; border:1px solid #cbd5e1; padding:8px 12px; border-radius:6px; text-decoration:none; color:#0f172a; }}
    </style>
    <h1>📄 Rejestr faktur i zobowiązań</h1>
    <div class="actions">
      <a href="/admin/finance/expensedocument/" target="_blank" rel="noopener">Otwórz koszty / faktury ↗</a>
      <a href="/admin/finance/vendor/" target="_blank" rel="noopener">Kontrahenci ↗</a>
      <a href="/admin/finance/costcategory/" target="_blank" rel="noopener">Kategorie kosztów ↗</a>
    </div>
    <div class="grid">
      <div class="card">Do zapłaty<strong class="minus">{unpaid.count()}</strong><div>{_money(unpaid_sum)}</div></div>
      <div class="card">Częściowo zapłacone<strong>{partial.count()}</strong><div>{_money(partial_sum)}</div></div>
      <div class="card">Przeterminowane<strong class="minus">{len(overdue_list)}</strong><div>{_money(overdue_sum)}</div></div>
      <div class="card">Zapłacone<strong class="plus">{paid.count()}</strong></div>
    </div>
    <h2>Przeterminowane faktury</h2>
    <table>
      <tr><th>Termin</th><th>Numer</th><th>Kontrahent</th><th>Kwota brutto</th><th>Pozostało</th></tr>
      {rows}
    </table>
    """
    return HttpResponse(html)


_original_get_urls_invoice = admin.site.get_urls


def get_urls_invoice():
    urls = _original_get_urls_invoice()
    custom = [
        path(
            "raporty/faktury/",
            admin.site.admin_view(invoice_dashboard_view),
            name="invoice_dashboard",
        )
    ]
    return custom + urls


if not getattr(admin.site, "_invoice_dashboard_patched", False):
    admin.site.get_urls = get_urls_invoice
    admin.site._invoice_dashboard_patched = True
