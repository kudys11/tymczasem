# ================================================================
# Etap 2.7.8 - Rejestr faktur i zobowiązań
# ================================================================
from django.utils import timezone
from django.utils.html import format_html

try:
    _old_expense_list_display = ExpenseDocumentAdmin.list_display
    ExpenseDocumentAdmin.list_display = (
        "posting_date",
        "document_number",
        "vendor",
        "cost_category",
        "gross_amount",
        "paid_amount",
        "amount_left_display",
        "due_date",
        "payment_status_display",
        "status",
    )

    ExpenseDocumentAdmin.list_filter = (
        "community",
        "status",
        "payment_status",
        "cost_category",
        "fund",
        "bank_account",
        "posting_date",
        "due_date",
    )

    ExpenseDocumentAdmin.search_fields = (
        "document_number",
        "vendor__name",
        "vendor__tax_id",
        "description",
        "cost_category__name",
    )

    ExpenseDocumentAdmin.date_hierarchy = "due_date"

    ExpenseDocumentAdmin.fieldsets = (
        ("Dokument / faktura", {
            "fields": (
                "community",
                "document_number",
                "document_date",
                "sale_date",
                "posting_date",
                "due_date",
                "status",
                "payment_status",
            )
        }),
        ("Klasyfikacja", {
            "fields": ("vendor", "cost_category", "fund", "bank_account")
        }),
        ("Kwoty", {
            "fields": ("net_amount", "vat_amount", "gross_amount", "paid_amount", "paid_date")
        }),
        ("Opis", {
            "fields": ("description",)
        }),
    )

    def payment_status_display(self, obj):
        if obj.is_overdue():
            return format_html('<strong style="color:#dc2626;">Przeterminowana</strong>')
        if obj.payment_status == "paid":
            return format_html('<strong style="color:#0a8f3c;">Zapłacona</strong>')
        if obj.payment_status == "partial":
            return format_html('<strong style="color:#ca8a04;">Częściowo zapłacona</strong>')
        if obj.payment_status == "cancelled":
            return "Anulowana"
        return "Do zapłaty"

    payment_status_display.short_description = "Status płatności"

    def amount_left_display(self, obj):
        left = obj.amount_left()
        if left > 0:
            return format_html('<strong style="color:#dc2626;">{} zł</strong>', f"{left:.2f}".replace(".", ","))
        return format_html('<strong style="color:#0a8f3c;">0,00 zł</strong>')

    amount_left_display.short_description = "Pozostało"

    ExpenseDocumentAdmin.payment_status_display = payment_status_display
    ExpenseDocumentAdmin.amount_left_display = amount_left_display

except Exception:
    pass
