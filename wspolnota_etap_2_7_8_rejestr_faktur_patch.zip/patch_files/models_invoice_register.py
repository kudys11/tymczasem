# ================================================================
# Etap 2.7.8 - Rejestr faktur i zobowiązań
# ================================================================
# Pola dodane migracją 0003_invoice_register:
# - sale_date
# - due_date
# - payment_status
# - paid_amount
# - paid_date
#
# Metody dopinamy dynamicznie, żeby nie przepisywać całej klasy.

from django.utils import timezone


def _expense_is_overdue(self):
    if not getattr(self, "due_date", None):
        return False
    if getattr(self, "payment_status", "") in ("paid", "cancelled"):
        return False
    return self.due_date < timezone.localdate()


def _expense_amount_left(self):
    gross = self.gross_amount or 0
    paid = getattr(self, "paid_amount", 0) or 0
    return gross - paid


def _expense_payment_status_label(self):
    labels = {
        "unpaid": "Do zapłaty",
        "partial": "Częściowo zapłacona",
        "paid": "Zapłacona",
        "cancelled": "Anulowana",
    }
    if self.is_overdue():
        return "Przeterminowana"
    return labels.get(getattr(self, "payment_status", ""), getattr(self, "payment_status", ""))


try:
    ExpenseDocument.is_overdue = _expense_is_overdue
    ExpenseDocument.amount_left = _expense_amount_left
    ExpenseDocument.payment_status_label = _expense_payment_status_label
except NameError:
    pass
