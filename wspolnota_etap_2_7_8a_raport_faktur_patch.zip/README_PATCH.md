# Etap 2.7.8a - Faktury i zobowiązania jako osobny raport

Bez migracji. Nie rusza listy `Finance -> Koszty wspólnoty`.

## Instalacja

```bash
cd /opt/_docker-compose/wspolnota
unzip wspolnota_etap_2_7_8a_raport_faktur_patch.zip
python3 patch_etap_2_7_8a_raport_faktur.py
docker compose down
docker compose build --no-cache
docker compose up -d
docker compose exec web python manage.py check
```

Widok:

```text
/admin/raporty/faktury/
```
