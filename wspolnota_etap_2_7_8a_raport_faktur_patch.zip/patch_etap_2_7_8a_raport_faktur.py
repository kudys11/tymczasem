#!/usr/bin/env python3
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "patch_files"

report_file = ROOT / "apps" / "finance" / "admin_invoice_dashboard.py"
shutil.copyfile(SRC / "admin_invoice_dashboard.py", report_file)

admin_file = ROOT / "apps" / "finance" / "admin.py"
txt = admin_file.read_text(encoding="utf-8")
line = "\n# Etap 2.7.8a - bezpieczny raport faktur\nfrom . import admin_invoice_dashboard  # noqa\n"
if "admin_invoice_dashboard" not in txt:
    admin_file.write_text(txt.rstrip() + line, encoding="utf-8")

center = ROOT / "apps" / "audit" / "admin_reports_center.py"
if center.exists():
    txt = center.read_text(encoding="utf-8")
    if "/admin/raporty/faktury/" not in txt:
        marker = '<div class="card disabled"><h2>📄 Sprawozdanie roczne</h2><p>Raport roczny wspólnoty gotowy do PDF.</p><a href="{financial_url}" target="_blank" rel="noopener">W przygotowaniu ↗</a></div>'
        repl = '<div class="card"><h2>📄 Faktury i zobowiązania</h2><p>Faktury do zapłaty, częściowo zapłacone i przeterminowane.</p><a href="/admin/raporty/faktury/?date={default_date}" target="_blank" rel="noopener">Otwórz raport ↗</a></div>\n      ' + marker
        txt = txt.replace(marker, repl)
        center.write_text(txt, encoding="utf-8")

print("OK: Etap 2.7.8a - bezpieczny raport faktur został naniesiony.")
print("Nie wykonuj migracji.")
