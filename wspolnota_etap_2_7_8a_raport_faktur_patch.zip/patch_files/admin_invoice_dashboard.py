from datetime import date, datetime
from decimal import Decimal
from django.contrib import admin
from django.http import HttpResponse
from django.urls import path
from apps.finance.models import ExpenseDocument

def dec(v):
    return Decimal(v or 0)

def money(v):
    return f"{dec(v):.2f} zł".replace(".", ",")

def amount_left(d):
    return dec(d.gross_amount) - dec(getattr(d, "paid_amount", 0))

def is_overdue(d, report_date):
    return bool(getattr(d, "due_date", None) and d.due_date < report_date and getattr(d, "payment_status", "unpaid") not in ("paid", "cancelled") and amount_left(d) > 0)

def invoice_dashboard_view(request):
    today = date.today()
    raw = request.GET.get("date") or today.isoformat()
    try:
        report_date = datetime.strptime(raw, "%Y-%m-%d").date()
    except ValueError:
        report_date = today

    docs = ExpenseDocument.objects.exclude(status="cancelled").select_related(
        "vendor", "cost_category", "bank_account"
    )

    unpaid, partial, paid, overdue = [], [], [], []
    for d in docs:
        st = getattr(d, "payment_status", "unpaid")
        if st == "paid":
            paid.append(d)
        elif st == "partial":
            partial.append(d)
        elif st == "unpaid":
            unpaid.append(d)
        if is_overdue(d, report_date):
            overdue.append(d)

    def rows(items, empty):
        out = ""
        for d in sorted(items, key=lambda x: x.due_date or report_date):
            left = amount_left(d)
            st = getattr(d, "payment_status", "unpaid")
            if is_overdue(d, report_date):
                label = '<span class="minus">Przeterminowana</span>'
            elif st == "paid":
                label = '<span class="plus">Zapłacona</span>'
            elif st == "partial":
                label = '<span class="warn">Częściowo zapłacona</span>'
            else:
                label = "Do zapłaty"
            out += f"""
            <tr>
              <td>{d.due_date or "-"}</td>
              <td>{d.document_number}</td>
              <td>{d.vendor}</td>
              <td>{d.cost_category}</td>
              <td>{d.bank_account or "-"}</td>
              <td>{money(d.gross_amount)}</td>
              <td>{money(getattr(d, "paid_amount", 0))}</td>
              <td class="{'minus' if left > 0 else 'plus'}">{money(left)}</td>
              <td>{label}</td>
              <td><a href="/admin/finance/expensedocument/{d.id}/change/" target="_blank" rel="noopener">Otwórz ↗</a></td>
            </tr>
            """
        return out or f"<tr><td colspan='10'>{empty}</td></tr>"

    unpaid_sum = sum((amount_left(d) for d in unpaid), Decimal("0.00"))
    partial_sum = sum((amount_left(d) for d in partial), Decimal("0.00"))
    overdue_sum = sum((amount_left(d) for d in overdue), Decimal("0.00"))
    paid_sum = sum((dec(getattr(d, "paid_amount", 0)) for d in paid), Decimal("0.00"))

    html = f"""
    <style>
      body {{ font-family:Arial,sans-serif; padding:18px; color:#0f172a; }}
      .topbar {{ display:flex; justify-content:space-between; gap:16px; align-items:flex-start; }}
      h1 {{ margin:0 0 4px 0; }}
      .subtitle {{ color:#64748b; }}
      .date-box {{ border:1px solid #dfe5ec; padding:12px; border-radius:8px; background:#f8fafc; }}
      .date-box input {{ padding:7px 9px; }}
      .date-box button {{ padding:8px 12px; }}
      .grid {{ display:grid; grid-template-columns:repeat(4,minmax(160px,1fr)); gap:12px; margin:16px 0; }}
      .card {{ border:1px solid #dfe5ec; border-radius:8px; padding:14px; background:#fff; }}
      .card strong {{ display:block; font-size:22px; margin-top:6px; }}
      table {{ width:100%; border-collapse:collapse; margin-top:12px; }}
      th,td {{ border:1px solid #dfe5ec; padding:7px 9px; text-align:left; vertical-align:top; }}
      th {{ background:#f1f5f9; }}
      .plus {{ color:#0a8f3c; font-weight:700; }}
      .minus {{ color:#dc2626; font-weight:700; }}
      .warn {{ color:#ca8a04; font-weight:700; }}
      .actions a {{ display:inline-block; margin-right:8px; border:1px solid #cbd5e1; padding:8px 12px; border-radius:6px; text-decoration:none; color:#0f172a; background:#fff; }}
      @media print {{ .actions,.date-box {{ display:none; }} body {{ font-size:10px; padding:6px; }} th,td {{ padding:3px 4px; }} }}
    </style>
    <div class="topbar">
      <div><h1>📄 Faktury i zobowiązania</h1><div class="subtitle">Stan na dzień: <strong>{report_date}</strong></div></div>
      <form class="date-box" method="get"><label>Data raportu: <input type="date" name="date" value="{report_date}"></label> <button type="submit">Pokaż</button></form>
    </div>
    <div class="actions" style="margin-top:14px;">
      <a href="/admin/finance/expensedocument/" target="_blank" rel="noopener">Koszty / faktury ↗</a>
      <a href="/admin/finance/expensedocument/add/" target="_blank" rel="noopener">Dodaj fakturę ↗</a>
      <a href="/admin/finance/vendor/" target="_blank" rel="noopener">Kontrahenci ↗</a>
      <a href="#" onclick="window.print(); return false;">PDF</a>
    </div>
    <div class="grid">
      <div class="card">Do zapłaty<strong class="minus">{len(unpaid)}</strong><div>{money(unpaid_sum)}</div></div>
      <div class="card">Częściowo zapłacone<strong class="warn">{len(partial)}</strong><div>{money(partial_sum)}</div></div>
      <div class="card">Przeterminowane<strong class="minus">{len(overdue)}</strong><div>{money(overdue_sum)}</div></div>
      <div class="card">Zapłacone<strong class="plus">{len(paid)}</strong><div>{money(paid_sum)}</div></div>
    </div>
    <h2>Przeterminowane faktury</h2>
    <table><tr><th>Termin</th><th>Numer</th><th>Kontrahent</th><th>Kategoria</th><th>Rachunek</th><th>Brutto</th><th>Zapłacono</th><th>Pozostało</th><th>Status</th><th></th></tr>{rows(overdue, "Brak przeterminowanych faktur.")}</table>
    <h2>Faktury otwarte</h2>
    <table><tr><th>Termin</th><th>Numer</th><th>Kontrahent</th><th>Kategoria</th><th>Rachunek</th><th>Brutto</th><th>Zapłacono</th><th>Pozostało</th><th>Status</th><th></th></tr>{rows(unpaid + partial, "Brak faktur do zapłaty.")}</table>
    """
    return HttpResponse(html)

_original_get_urls_invoice_dashboard = admin.site.get_urls

def get_urls_invoice_dashboard():
    urls = _original_get_urls_invoice_dashboard()
    custom = [path("raporty/faktury/", admin.site.admin_view(invoice_dashboard_view), name="invoice_dashboard")]
    return custom + urls

if not getattr(admin.site, "_invoice_dashboard_safe_patched", False):
    admin.site.get_urls = get_urls_invoice_dashboard
    admin.site._invoice_dashboard_safe_patched = True
