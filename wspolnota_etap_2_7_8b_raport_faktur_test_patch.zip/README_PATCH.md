# Etap 2.7.8b - testowy raport faktur

Bez migracji.

Nie rusza:
- `ExpenseDocumentAdmin`,
- `Finance -> Koszty wspólnoty`,
- Centrum raportów.

Dodaje tylko testowy URL:

```text
/admin/raporty/faktury-test/
```

## Instalacja

```bash
cd /opt/_docker-compose/wspolnota
unzip wspolnota_etap_2_7_8b_raport_faktur_test_patch.zip
python3 patch_etap_2_7_8b_raport_faktur_test.py
docker compose down
docker compose build --no-cache
docker compose up -d
docker compose exec web python manage.py check
```

## Test

```text
/admin/raporty/faktury-test/?date=2026-12-31
```
