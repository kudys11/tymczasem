# ================================================================
# Etap 2.7.8b - testowy raport faktur
# Nie rusza ExpenseDocumentAdmin.
# URL: /admin/raporty/faktury-test/
# ================================================================
from datetime import date, datetime
from decimal import Decimal

from django.contrib import admin
from django.http import HttpResponse
from django.urls import path

from apps.finance.models import ExpenseDocument


def inv_dec(value):
    return Decimal(value or 0)


def inv_money(value):
    value = inv_dec(value)
    return f"{value:.2f} zł".replace(".", ",")


def inv_amount_left(doc):
    return inv_dec(doc.gross_amount) - inv_dec(getattr(doc, "paid_amount", 0))


def inv_is_overdue(doc, report_date):
    due_date = getattr(doc, "due_date", None)
    payment_status = getattr(doc, "payment_status", "unpaid")
    return bool(
        due_date
        and due_date < report_date
        and payment_status not in ("paid", "cancelled")
        and inv_amount_left(doc) > 0
    )


def inv_status_label(doc, report_date):
    payment_status = getattr(doc, "payment_status", "unpaid")
    if inv_is_overdue(doc, report_date):
        return '<span class="minus">Przeterminowana</span>'
    if payment_status == "paid":
        return '<span class="plus">Zapłacona</span>'
    if payment_status == "partial":
        return '<span class="warn">Częściowo zapłacona</span>'
    if payment_status == "cancelled":
        return "Anulowana"
    return "Do zapłaty"


def invoice_test_report_view(request):
    today = date.today()
    raw_date = request.GET.get("date") or today.isoformat()

    try:
        report_date = datetime.strptime(raw_date, "%Y-%m-%d").date()
    except ValueError:
        report_date = today

    docs = list(
        ExpenseDocument.objects
        .exclude(status="cancelled")
        .select_related("vendor", "cost_category", "fund", "bank_account")
        .order_by("due_date", "posting_date", "id")
    )

    unpaid_docs = []
    partial_docs = []
    paid_docs = []
    overdue_docs = []

    for doc in docs:
        payment_status = getattr(doc, "payment_status", "unpaid")
        if payment_status == "paid":
            paid_docs.append(doc)
        elif payment_status == "partial":
            partial_docs.append(doc)
        elif payment_status == "unpaid":
            unpaid_docs.append(doc)

        if inv_is_overdue(doc, report_date):
            overdue_docs.append(doc)

    unpaid_sum = sum((inv_amount_left(d) for d in unpaid_docs), Decimal("0.00"))
    partial_sum = sum((inv_amount_left(d) for d in partial_docs), Decimal("0.00"))
    overdue_sum = sum((inv_amount_left(d) for d in overdue_docs), Decimal("0.00"))
    paid_sum = sum((inv_dec(getattr(d, "paid_amount", 0)) for d in paid_docs), Decimal("0.00"))

    def render_rows(items, empty_text):
        rows = []
        for doc in items:
            left = inv_amount_left(doc)
            rows.append(f"""
                <tr>
                    <td>{getattr(doc, "due_date", None) or "-"}</td>
                    <td>{doc.document_number}</td>
                    <td>{doc.vendor}</td>
                    <td>{doc.cost_category}</td>
                    <td>{doc.bank_account or "-"}</td>
                    <td>{inv_money(doc.gross_amount)}</td>
                    <td>{inv_money(getattr(doc, "paid_amount", 0))}</td>
                    <td class="{'minus' if left > 0 else 'plus'}">{inv_money(left)}</td>
                    <td>{inv_status_label(doc, report_date)}</td>
                    <td><a href="/admin/finance/expensedocument/{doc.id}/change/" target="_blank" rel="noopener">Otwórz ↗</a></td>
                </tr>
            """)

        if not rows:
            return f"<tr><td colspan='10'>{empty_text}</td></tr>"

        return "".join(rows)

    open_docs = [d for d in docs if getattr(d, "payment_status", "unpaid") in ("unpaid", "partial")]

    html = f"""
    <!doctype html>
    <html lang="pl">
    <head>
      <meta charset="utf-8">
      <title>Faktury i zobowiązania</title>
      <style>
        body {{ font-family: Arial, sans-serif; padding: 18px; color: #0f172a; background: #fff; }}
        .topbar {{ display: flex; justify-content: space-between; gap: 16px; align-items: flex-start; }}
        h1 {{ margin: 0 0 4px 0; }}
        .subtitle {{ color: #64748b; }}
        .date-box {{ border: 1px solid #dfe5ec; padding: 12px; border-radius: 8px; background: #f8fafc; }}
        .date-box input {{ padding: 7px 9px; }}
        .date-box button {{ padding: 8px 12px; }}
        .grid {{ display: grid; grid-template-columns: repeat(4, minmax(160px, 1fr)); gap: 12px; margin: 16px 0; }}
        .card {{ border: 1px solid #dfe5ec; border-radius: 8px; padding: 14px; background: #fff; }}
        .card strong {{ display: block; font-size: 22px; margin-top: 6px; }}
        table {{ width: 100%; border-collapse: collapse; margin-top: 12px; }}
        th, td {{ border: 1px solid #dfe5ec; padding: 7px 9px; text-align: left; vertical-align: top; }}
        th {{ background: #f1f5f9; }}
        .plus {{ color: #0a8f3c; font-weight: 700; }}
        .minus {{ color: #dc2626; font-weight: 700; }}
        .warn {{ color: #ca8a04; font-weight: 700; }}
        .actions a {{ display: inline-block; margin-right: 8px; border: 1px solid #cbd5e1; padding: 8px 12px; border-radius: 6px; text-decoration: none; color: #0f172a; background: #fff; }}
        .section {{ margin-top: 24px; }}
        @media print {{
          .actions, .date-box {{ display: none; }}
          body {{ font-size: 10px; padding: 6px; }}
          th, td {{ padding: 3px 4px; }}
        }}
      </style>
    </head>
    <body>
      <div class="topbar">
        <div>
          <h1>📄 Faktury i zobowiązania — test</h1>
          <div class="subtitle">Stan na dzień: <strong>{report_date}</strong></div>
        </div>
        <form class="date-box" method="get">
          <label>Data raportu:
            <input type="date" name="date" value="{report_date}">
          </label>
          <button type="submit">Pokaż</button>
        </form>
      </div>

      <div class="actions" style="margin-top:14px;">
        <a href="/admin/finance/expensedocument/" target="_blank" rel="noopener">Koszty / faktury ↗</a>
        <a href="/admin/finance/expensedocument/add/" target="_blank" rel="noopener">Dodaj fakturę ↗</a>
        <a href="/admin/finance/vendor/" target="_blank" rel="noopener">Kontrahenci ↗</a>
        <a href="#" onclick="window.print(); return false;">PDF</a>
      </div>

      <div class="grid">
        <div class="card">Do zapłaty<strong class="minus">{len(unpaid_docs)}</strong><div>{inv_money(unpaid_sum)}</div></div>
        <div class="card">Częściowo zapłacone<strong class="warn">{len(partial_docs)}</strong><div>{inv_money(partial_sum)}</div></div>
        <div class="card">Przeterminowane<strong class="minus">{len(overdue_docs)}</strong><div>{inv_money(overdue_sum)}</div></div>
        <div class="card">Zapłacone<strong class="plus">{len(paid_docs)}</strong><div>{inv_money(paid_sum)}</div></div>
      </div>

      <div class="section">
        <h2>Przeterminowane faktury</h2>
        <table>
          <tr><th>Termin</th><th>Numer</th><th>Kontrahent</th><th>Kategoria</th><th>Rachunek</th><th>Brutto</th><th>Zapłacono</th><th>Pozostało</th><th>Status</th><th></th></tr>
          {render_rows(overdue_docs, "Brak przeterminowanych faktur.")}
        </table>
      </div>

      <div class="section">
        <h2>Faktury otwarte</h2>
        <table>
          <tr><th>Termin</th><th>Numer</th><th>Kontrahent</th><th>Kategoria</th><th>Rachunek</th><th>Brutto</th><th>Zapłacono</th><th>Pozostało</th><th>Status</th><th></th></tr>
          {render_rows(open_docs, "Brak faktur do zapłaty.")}
        </table>
      </div>
    </body>
    </html>
    """
    return HttpResponse(html)


_original_get_urls_invoice_test = admin.site.get_urls


def get_urls_invoice_test():
    urls = _original_get_urls_invoice_test()
    custom = [
        path(
            "raporty/faktury-test/",
            admin.site.admin_view(invoice_test_report_view),
            name="invoice_test_report",
        )
    ]
    return custom + urls


if not getattr(admin.site, "_invoice_test_report_patched", False):
    admin.site.get_urls = get_urls_invoice_test
    admin.site._invoice_test_report_patched = True
