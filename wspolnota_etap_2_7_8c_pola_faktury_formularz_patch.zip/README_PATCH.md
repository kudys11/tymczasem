# Etap 2.7.8c - pola faktury w formularzu kosztu

Bez migracji.

Nie rusza:
- `ExpenseDocumentAdmin.list_display`
- `ExpenseDocumentAdmin.list_filter`
- `ExpenseDocumentAdmin.date_hierarchy`
- listy `Finance -> Koszty wspólnoty`

Dodaje tylko sekcję w formularzu dodawania/edycji kosztu:

```text
Faktura i płatność
- Data sprzedaży / wykonania usługi
- Termin płatności
- Status płatności
- Kwota zapłacona
- Data zapłaty
```

## Instalacja

```bash
cd /opt/_docker-compose/wspolnota
unzip wspolnota_etap_2_7_8c_pola_faktury_formularz_patch.zip
python3 patch_etap_2_7_8c_pola_faktury_formularz.py
docker compose down
docker compose build --no-cache
docker compose up -d
docker compose exec web python manage.py check
```

## Test

Wejdź:

```text
Finance -> Koszty wspólnoty -> Dodaj
```

albo edytuj istniejący koszt i sprawdź, czy jest sekcja:

```text
Faktura i płatność
```
