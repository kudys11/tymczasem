#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parent

admin_file = ROOT / "apps" / "finance" / "admin.py"
txt = admin_file.read_text(encoding="utf-8")

marker = "# Etap 2.7.8c - pola faktury tylko w formularzu kosztu"

if marker not in txt:
    block = (ROOT / "patch_files" / "safe_admin_invoice_fields.py").read_text(encoding="utf-8")
    admin_file.write_text(txt.rstrip() + "\n\n" + block + "\n", encoding="utf-8")

print("OK: Etap 2.7.8c - dodano pola faktury tylko do formularza kosztu.")
print("Bez migracji. Bez zmian listy Koszty wspólnoty.")
