# ================================================================
# Etap 2.7.8c - pola faktury tylko w formularzu kosztu
# Bez zmian list_display, list_filter i date_hierarchy.
# ================================================================
try:
    _expense_old_get_fieldsets = getattr(ExpenseDocumentAdmin, "get_fieldsets", None)

    def _expense_invoice_get_fieldsets(self, request, obj=None):
        base = _expense_old_get_fieldsets(self, request, obj)

        invoice_fields = []
        model_field_names = {f.name for f in self.model._meta.fields}
        for name in ("sale_date", "due_date", "payment_status", "paid_amount", "paid_date"):
            if name in model_field_names:
                invoice_fields.append(name)

        if not invoice_fields:
            return base

        # Nie dodawaj drugi raz, jeśli pola już są gdzieś w formularzu.
        existing = set()
        for _title, opts in base:
            for f in opts.get("fields", ()):
                if isinstance(f, (list, tuple)):
                    existing.update(f)
                else:
                    existing.add(f)

        if any(f in existing for f in invoice_fields):
            return base

        return tuple(list(base) + [
            ("Faktura i płatność", {
                "fields": tuple(invoice_fields),
                "description": "Dane zobowiązania: termin płatności, status zapłaty i kwota zapłacona."
            })
        ])

    ExpenseDocumentAdmin.get_fieldsets = _expense_invoice_get_fieldsets

except Exception:
    pass
