# Etap 2.7.8d - Raport faktur do zapłaty

Bez migracji. Nie rusza listy `Finance -> Koszty wspólnoty`.

## Instalacja

```bash
cd /opt/_docker-compose/wspolnota
unzip wspolnota_etap_2_7_8d_raport_faktur_do_zaplaty_patch.zip
python3 patch_etap_2_7_8d_raport_faktur_do_zaplaty.py
docker compose down
docker compose build --no-cache
docker compose up -d
docker compose exec web python manage.py check
```

## Test

```text
/admin/raporty/faktury-do-zaplaty/?date=2026-12-31
```
