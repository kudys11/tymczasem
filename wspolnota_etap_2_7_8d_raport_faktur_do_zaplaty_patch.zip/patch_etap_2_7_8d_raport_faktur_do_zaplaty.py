#!/usr/bin/env python3
from pathlib import Path
import shutil
ROOT = Path(__file__).resolve().parent
SRC = ROOT / "patch_files"

report_file = ROOT / "apps" / "finance" / "admin_invoice_due_report.py"
shutil.copyfile(SRC / "admin_invoice_due_report.py", report_file)

admin_file = ROOT / "apps" / "finance" / "admin.py"
txt = admin_file.read_text(encoding="utf-8")
line = "\n# Etap 2.7.8d - raport faktur do zapłaty\nfrom . import admin_invoice_due_report  # noqa\n"
if "admin_invoice_due_report" not in txt:
    admin_file.write_text(txt.rstrip() + line, encoding="utf-8")

print("OK: Etap 2.7.8d - raport faktur do zapłaty został naniesiony.")
print("Bez migracji. Bez zmian ExpenseDocumentAdmin.")
