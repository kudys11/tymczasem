from datetime import date, datetime
from decimal import Decimal
from django.contrib import admin
from django.http import HttpResponse
from django.urls import path
from apps.finance.models import ExpenseDocument

def dec(v):
    return Decimal(v or 0)

def money(v):
    return f"{dec(v):.2f} zł".replace(".", ",")

def left(doc):
    return dec(doc.gross_amount) - dec(getattr(doc, "paid_amount", 0))

def is_open(doc):
    return getattr(doc, "payment_status", "unpaid") in ("unpaid", "partial")

def is_overdue(doc, report_date):
    return bool(getattr(doc, "due_date", None) and doc.due_date < report_date and is_open(doc) and left(doc) > 0)

def status_html(doc, report_date):
    st = getattr(doc, "payment_status", "unpaid")
    if is_overdue(doc, report_date):
        return '<span class="minus">Przeterminowana</span>'
    if st == "paid":
        return '<span class="plus">Zapłacona</span>'
    if st == "partial":
        return '<span class="warn">Częściowo zapłacona</span>'
    if st == "cancelled":
        return "Anulowana"
    return "Do zapłaty"

def row(doc, report_date):
    l = left(doc)
    cls = "minus" if l > 0 else "plus"
    return f"""
    <tr>
      <td>{doc.due_date or "-"}</td>
      <td>{doc.document_number}</td>
      <td>{doc.vendor}</td>
      <td>{doc.cost_category}</td>
      <td>{doc.bank_account or "-"}</td>
      <td>{money(doc.gross_amount)}</td>
      <td>{money(getattr(doc, "paid_amount", 0))}</td>
      <td class="{cls}">{money(l)}</td>
      <td>{status_html(doc, report_date)}</td>
      <td><a href="/admin/finance/expensedocument/{doc.id}/change/" target="_blank" rel="noopener">Otwórz ↗</a></td>
    </tr>
    """

def rows(items, report_date, empty):
    body = "".join(row(d, report_date) for d in items)
    return body or f"<tr><td colspan='10'>{empty}</td></tr>"

def invoice_due_report_view(request):
    today = date.today()
    raw = request.GET.get("date") or today.isoformat()
    try:
        report_date = datetime.strptime(raw, "%Y-%m-%d").date()
    except ValueError:
        report_date = today

    docs = list(ExpenseDocument.objects.exclude(status="cancelled").select_related(
        "vendor", "cost_category", "bank_account"
    ).order_by("due_date", "posting_date", "id"))

    open_docs = [d for d in docs if is_open(d) and left(d) > 0]
    overdue_docs = [d for d in open_docs if is_overdue(d, report_date)]
    upcoming_docs = [d for d in open_docs if not is_overdue(d, report_date)]
    paid_docs = [d for d in docs if getattr(d, "payment_status", "unpaid") == "paid"]

    open_sum = sum((left(d) for d in open_docs), Decimal("0.00"))
    overdue_sum = sum((left(d) for d in overdue_docs), Decimal("0.00"))
    upcoming_sum = sum((left(d) for d in upcoming_docs), Decimal("0.00"))
    paid_sum = sum((dec(getattr(d, "paid_amount", 0)) for d in paid_docs), Decimal("0.00"))

    html = f"""
    <!doctype html><html lang="pl"><head><meta charset="utf-8"><title>Faktury do zapłaty</title>
    <style>
    body{{font-family:Arial,sans-serif;padding:18px;color:#0f172a;background:#fff}}
    .topbar{{display:flex;justify-content:space-between;gap:16px;align-items:flex-start}}
    h1{{margin:0 0 4px 0}} .subtitle{{color:#64748b}}
    .date-box{{border:1px solid #dfe5ec;padding:12px;border-radius:8px;background:#f8fafc}}
    .date-box input{{padding:7px 9px}} .date-box button{{padding:8px 12px}}
    .grid{{display:grid;grid-template-columns:repeat(4,minmax(160px,1fr));gap:12px;margin:16px 0}}
    .card{{border:1px solid #dfe5ec;border-radius:8px;padding:14px;background:#fff}}
    .card strong{{display:block;font-size:22px;margin-top:6px}}
    table{{width:100%;border-collapse:collapse;margin-top:12px}}
    th,td{{border:1px solid #dfe5ec;padding:7px 9px;text-align:left;vertical-align:top}}
    th{{background:#f1f5f9}} .plus{{color:#0a8f3c;font-weight:700}} .minus{{color:#dc2626;font-weight:700}} .warn{{color:#ca8a04;font-weight:700}}
    .actions a{{display:inline-block;margin-right:8px;border:1px solid #cbd5e1;padding:8px 12px;border-radius:6px;text-decoration:none;color:#0f172a;background:#fff}}
    .section{{margin-top:24px}}
    @media print{{.actions,.date-box{{display:none}} body{{font-size:10px;padding:6px}} th,td{{padding:3px 4px}}}}
    </style></head><body>
    <div class="topbar"><div><h1>📄 Faktury do zapłaty</h1><div class="subtitle">Stan na dzień: <strong>{report_date}</strong></div></div>
    <form class="date-box" method="get"><label>Data raportu: <input type="date" name="date" value="{report_date}"></label> <button type="submit">Pokaż</button></form></div>
    <div class="actions" style="margin-top:14px;">
      <a href="/admin/finance/expensedocument/" target="_blank" rel="noopener">Koszty / faktury ↗</a>
      <a href="/admin/finance/expensedocument/add/" target="_blank" rel="noopener">Dodaj fakturę ↗</a>
      <a href="/admin/finance/vendor/" target="_blank" rel="noopener">Kontrahenci ↗</a>
      <a href="#" onclick="window.print(); return false;">PDF</a>
    </div>
    <div class="grid">
      <div class="card">Do zapłaty<strong class="minus">{len(open_docs)}</strong><div>{money(open_sum)}</div></div>
      <div class="card">Przeterminowane<strong class="minus">{len(overdue_docs)}</strong><div>{money(overdue_sum)}</div></div>
      <div class="card">Nadchodzące<strong class="warn">{len(upcoming_docs)}</strong><div>{money(upcoming_sum)}</div></div>
      <div class="card">Zapłacone<strong class="plus">{len(paid_docs)}</strong><div>{money(paid_sum)}</div></div>
    </div>
    <div class="section"><h2>Przeterminowane</h2><table>
    <tr><th>Termin</th><th>Numer</th><th>Kontrahent</th><th>Kategoria</th><th>Rachunek</th><th>Brutto</th><th>Zapłacono</th><th>Pozostało</th><th>Status</th><th></th></tr>
    {rows(overdue_docs, report_date, "Brak przeterminowanych faktur.")}</table></div>
    <div class="section"><h2>Do zapłaty</h2><table>
    <tr><th>Termin</th><th>Numer</th><th>Kontrahent</th><th>Kategoria</th><th>Rachunek</th><th>Brutto</th><th>Zapłacono</th><th>Pozostało</th><th>Status</th><th></th></tr>
    {rows(upcoming_docs, report_date, "Brak faktur do zapłaty.")}</table></div>
    </body></html>
    """
    return HttpResponse(html)

_original_get_urls_invoice_due = admin.site.get_urls

def get_urls_invoice_due():
    urls = _original_get_urls_invoice_due()
    custom = [path("raporty/faktury-do-zaplaty/", admin.site.admin_view(invoice_due_report_view), name="invoice_due_report")]
    return custom + urls

if not getattr(admin.site, "_invoice_due_report_patched", False):
    admin.site.get_urls = get_urls_invoice_due
    admin.site._invoice_due_report_patched = True
