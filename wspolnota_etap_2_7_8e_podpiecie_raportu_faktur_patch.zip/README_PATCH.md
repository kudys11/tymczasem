# Etap 2.7.8e - Podpięcie raportu faktur do Centrum raportów

Bez migracji.

Dodaje kafelek `📄 Faktury do zapłaty` w:

```text
/admin/raporty/
```

## Instalacja

```bash
cd /opt/_docker-compose/wspolnota
unzip wspolnota_etap_2_7_8e_podpiecie_raportu_faktur_patch.zip
python3 patch_etap_2_7_8e_podpiecie_raportu_faktur.py
docker compose down
docker compose build --no-cache
docker compose up -d
docker compose exec web python manage.py check
```
