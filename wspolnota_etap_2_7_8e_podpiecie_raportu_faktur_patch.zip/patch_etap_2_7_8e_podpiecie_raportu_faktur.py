#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parent
p = ROOT / "apps" / "audit" / "admin_reports_center.py"

txt = p.read_text(encoding="utf-8")

if "/admin/raporty/faktury-do-zaplaty/" in txt:
    print("Raport faktur jest już podpięty w Centrum raportów.")
    raise SystemExit(0)

card = """
      <div class="card">
        <h2>📄 Faktury do zapłaty</h2>
        <p>Zobowiązania wspólnoty: do zapłaty, przeterminowane, nadchodzące i zapłacone.</p>
        <a href="/admin/raporty/faktury-do-zaplaty/?date={default_date}" target="_blank" rel="noopener">Otwórz raport ↗</a>
      </div>

"""

marker = """    </div>

    <h2 class="section-title">Szybkie przejścia</h2>
"""

if marker not in txt:
    raise SystemExit("Nie znaleziono miejsca do podpięcia kafelka w admin_reports_center.py")

txt = txt.replace(marker, card + marker, 1)
p.write_text(txt, encoding="utf-8")
print("OK: raport Faktury do zapłaty podpięty do Centrum raportów.")
