# Etap 2.7.8f - Porządkowanie raportu Faktury do zapłaty

Bez migracji.

Zmiany:
- dodaje szybkie przejście do raportu faktur w Centrum raportów,
- usuwa stary kafelek `Faktury i zobowiązania`, jeśli jeszcze istnieje,
- poprawia opis i druk/PDF raportu faktur,
- nie rusza listy `Finance -> Koszty wspólnoty`.

## Instalacja

```bash
cd /opt/_docker-compose/wspolnota
unzip wspolnota_etap_2_7_8f_porządkowanie_raportu_faktur_patch.zip
python3 patch_etap_2_7_8f_porządkowanie_raportu_faktur.py
docker compose down
docker compose build --no-cache
docker compose up -d
docker compose exec web python manage.py check
```
