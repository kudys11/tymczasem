#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parent

center = ROOT / "apps" / "audit" / "admin_reports_center.py"
if center.exists():
    txt = center.read_text(encoding="utf-8")

    # Usuń ewentualny stary kafelek "Faktury i zobowiązania"
    old_title = '<div class="card"><h2>📄 Faktury i zobowiązania</h2>'
    start = txt.find(old_title)
    if start != -1:
        end = txt.find('</div>', start)
        end = txt.find('</div>', end + 1)
        if end != -1:
            end += len('</div>')
            txt = txt[:start] + txt[end:]

    # Dodaj szybkie przejście do raportu faktur, jeśli go nie ma
    if 'Faktury do zapłaty ↗</a>' not in txt:
        anchor = '<a href="/admin/finance/expensedocument/" target="_blank" rel="noopener">Koszty wspólnoty ↗</a>'
        extra = anchor + '\n      <a href="/admin/raporty/faktury-do-zaplaty/?date={default_date}" target="_blank" rel="noopener">Faktury do zapłaty ↗</a>'
        if anchor in txt:
            txt = txt.replace(anchor, extra, 1)

    center.write_text(txt, encoding="utf-8")


report = ROOT / "apps" / "finance" / "admin_invoice_due_report.py"
if report.exists():
    txt = report.read_text(encoding="utf-8")

    if "Raport obejmuje koszty wspólnoty z uzupełnionymi polami faktury" not in txt:
        txt = txt.replace(
            '<div class="subtitle">Stan na dzień: <strong>{report_date}</strong></div>',
            '<div class="subtitle">Stan na dzień: <strong>{report_date}</strong><br>Raport obejmuje koszty wspólnoty z uzupełnionymi polami faktury.</div>'
        )

    old_css = '@media print{{.actions,.date-box{{display:none}} body{{font-size:10px;padding:6px}} th,td{{padding:3px 4px}}}}'
    new_css = '@media print{{.actions,.date-box{{display:none}} @page{{size:A4 landscape;margin:8mm}} body{{font-size:9px;padding:0}} h1{{font-size:18px}} h2{{font-size:14px;margin:10px 0 4px}} .grid{{grid-template-columns:repeat(4,1fr);gap:6px;margin:8px 0}} .card{{padding:6px}} .card strong{{font-size:15px}} th,td{{padding:3px 4px}}}}'
    if old_css in txt:
        txt = txt.replace(old_css, new_css)

    report.write_text(txt, encoding="utf-8")

print("OK: Etap 2.7.8f - uporządkowano raport Faktury do zapłaty.")
print("Bez migracji.")
