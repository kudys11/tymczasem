# Etap 2.7.9 - Monitoring zobowiązań

Bez migracji.

Dodaje:
- `/admin/raporty/monitoring-zobowiazan/`
- kafelek w Centrum raportów
- liczniki: otwarte, po terminie, termin w 14 dni, bez terminu
- usuwa szybkie przejście `Faktury do zapłaty`, jeśli jest zdublowane

Nie rusza:
- `ExpenseDocumentAdmin`
- listy `Finance -> Koszty wspólnoty`

## Instalacja

```bash
cd /opt/_docker-compose/wspolnota
unzip wspolnota_etap_2_7_9_monitoring_zobowiazan_patch.zip
python3 patch_etap_2_7_9_monitoring_zobowiazan.py
docker compose down
docker compose build --no-cache
docker compose up -d
docker compose exec web python manage.py check
```

## Widok

```text
/admin/raporty/monitoring-zobowiazan/?date=2026-12-31
```
