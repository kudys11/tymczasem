#!/usr/bin/env python3
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "patch_files"

report_file = ROOT / "apps" / "finance" / "admin_obligation_monitoring.py"
shutil.copyfile(SRC / "admin_obligation_monitoring.py", report_file)

admin_file = ROOT / "apps" / "finance" / "admin.py"
txt = admin_file.read_text(encoding="utf-8")
line = "\n# Etap 2.7.9 - monitoring zobowiązań\nfrom . import admin_obligation_monitoring  # noqa\n"
if "admin_obligation_monitoring" not in txt:
    admin_file.write_text(txt.rstrip() + line, encoding="utf-8")

center = ROOT / "apps" / "audit" / "admin_reports_center.py"
if center.exists():
    txt = center.read_text(encoding="utf-8")

    # Usuń szybkie przejście Faktury do zapłaty, jeśli jest zdublowane
    line_to_remove = '<a href="/admin/raporty/faktury-do-zaplaty/?date={default_date}" target="_blank" rel="noopener">Faktury do zapłaty ↗</a>'
    txt = txt.replace("\n      " + line_to_remove, "")
    txt = txt.replace(line_to_remove, "")

    if "/admin/raporty/monitoring-zobowiazan/" not in txt:
        marker = '    </div>\n\n    <h2 class="section-title">Szybkie przejścia</h2>'
        card = '''      <div class="card">
        <h2>🚨 Monitoring zobowiązań</h2>
        <p>Kontrola faktur po terminie, najbliższych płatności i faktur bez terminu.</p>
        <a href="/admin/raporty/monitoring-zobowiazan/?date={default_date}" target="_blank" rel="noopener">Otwórz raport ↗</a>
      </div>

'''
        if marker in txt:
            txt = txt.replace(marker, card + marker, 1)

    center.write_text(txt, encoding="utf-8")

print("OK: Etap 2.7.9 - Monitoring zobowiązań został naniesiony.")
print("Bez migracji. Bez zmian ExpenseDocumentAdmin.")
