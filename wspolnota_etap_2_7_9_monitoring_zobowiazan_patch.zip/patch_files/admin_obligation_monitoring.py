from datetime import date, datetime, timedelta
from decimal import Decimal

from django.contrib import admin
from django.http import HttpResponse
from django.urls import path

from apps.finance.models import ExpenseDocument


def dec(v):
    return Decimal(v or 0)


def money(v):
    return f"{dec(v):.2f} zł".replace(".", ",")


def left(doc):
    return dec(doc.gross_amount) - dec(getattr(doc, "paid_amount", 0))


def is_open(doc):
    return getattr(doc, "payment_status", "unpaid") in ("unpaid", "partial")


def is_overdue(doc, report_date):
    return bool(getattr(doc, "due_date", None) and doc.due_date < report_date and is_open(doc) and left(doc) > 0)


def is_due_soon(doc, report_date, days=14):
    due = getattr(doc, "due_date", None)
    return bool(due and report_date <= due <= report_date + timedelta(days=days) and is_open(doc) and left(doc) > 0)


def row(doc, report_date):
    l = left(doc)
    if is_overdue(doc, report_date):
        label = '<span class="minus">Po terminie</span>'
    elif is_due_soon(doc, report_date):
        label = '<span class="warn">Termin blisko</span>'
    elif getattr(doc, "payment_status", "unpaid") == "partial":
        label = '<span class="warn">Częściowo zapłacona</span>'
    else:
        label = "Do zapłaty"

    return f'''
    <tr>
      <td>{doc.due_date or "-"}</td>
      <td>{doc.document_number}</td>
      <td>{doc.vendor}</td>
      <td>{doc.cost_category}</td>
      <td>{money(doc.gross_amount)}</td>
      <td>{money(getattr(doc, "paid_amount", 0))}</td>
      <td class="{'minus' if l > 0 else 'plus'}">{money(l)}</td>
      <td>{label}</td>
      <td><a href="/admin/finance/expensedocument/{doc.id}/change/" target="_blank" rel="noopener">Otwórz ↗</a></td>
    </tr>
    '''


def rows(items, report_date, empty):
    body = "".join(row(d, report_date) for d in items)
    return body or f"<tr><td colspan='9'>{empty}</td></tr>"


def obligation_monitoring_view(request):
    today = date.today()
    raw = request.GET.get("date") or today.isoformat()

    try:
        report_date = datetime.strptime(raw, "%Y-%m-%d").date()
    except ValueError:
        report_date = today

    docs = list(
        ExpenseDocument.objects
        .exclude(status="cancelled")
        .select_related("vendor", "cost_category")
        .order_by("due_date", "posting_date", "id")
    )

    open_docs = [d for d in docs if is_open(d) and left(d) > 0]
    overdue_docs = [d for d in open_docs if is_overdue(d, report_date)]
    due_soon_docs = [d for d in open_docs if is_due_soon(d, report_date)]
    no_due_date_docs = [d for d in open_docs if not getattr(d, "due_date", None)]

    open_sum = sum((left(d) for d in open_docs), Decimal("0.00"))
    overdue_sum = sum((left(d) for d in overdue_docs), Decimal("0.00"))
    due_soon_sum = sum((left(d) for d in due_soon_docs), Decimal("0.00"))
    no_due_sum = sum((left(d) for d in no_due_date_docs), Decimal("0.00"))

    if overdue_docs:
        alert = f'<div class="alert bad">Uwaga: {len(overdue_docs)} faktur po terminie na kwotę {money(overdue_sum)}.</div>'
    elif due_soon_docs:
        alert = f'<div class="alert warnbox">Uwaga: {len(due_soon_docs)} faktur ma termin płatności w ciągu 14 dni.</div>'
    else:
        alert = '<div class="alert ok">Brak przeterminowanych faktur.</div>'

    html = f'''
    <!doctype html>
    <html lang="pl">
    <head>
      <meta charset="utf-8">
      <title>Monitoring zobowiązań</title>
      <style>
        body{{font-family:Arial,sans-serif;padding:18px;color:#0f172a;background:#fff}}
        .topbar{{display:flex;justify-content:space-between;gap:16px;align-items:flex-start}}
        h1{{margin:0 0 4px 0}} .subtitle{{color:#64748b}}
        .date-box{{border:1px solid #dfe5ec;padding:12px;border-radius:8px;background:#f8fafc}}
        .date-box input{{padding:7px 9px}} .date-box button{{padding:8px 12px}}
        .grid{{display:grid;grid-template-columns:repeat(4,minmax(160px,1fr));gap:12px;margin:16px 0}}
        .card{{border:1px solid #dfe5ec;border-radius:8px;padding:14px;background:#fff}}
        .card strong{{display:block;font-size:22px;margin-top:6px}}
        table{{width:100%;border-collapse:collapse;margin-top:12px}}
        th,td{{border:1px solid #dfe5ec;padding:7px 9px;text-align:left;vertical-align:top}}
        th{{background:#f1f5f9}} .plus{{color:#0a8f3c;font-weight:700}} .minus{{color:#dc2626;font-weight:700}} .warn{{color:#ca8a04;font-weight:700}}
        .actions a{{display:inline-block;margin-right:8px;border:1px solid #cbd5e1;padding:8px 12px;border-radius:6px;text-decoration:none;color:#0f172a;background:#fff}}
        .alert{{border-radius:8px;padding:12px;margin:16px 0;font-weight:700}}
        .bad{{background:#fef2f2;color:#dc2626;border:1px solid #fecaca}}
        .warnbox{{background:#fffbeb;color:#ca8a04;border:1px solid #fde68a}}
        .ok{{background:#ecfdf5;color:#0a8f3c;border:1px solid #bbf7d0}}
        .section{{margin-top:24px}}
        @media print{{.actions,.date-box{{display:none}} @page{{size:A4 landscape;margin:8mm}} body{{font-size:9px;padding:0}} th,td{{padding:3px 4px}}}}
      </style>
    </head>
    <body>
      <div class="topbar">
        <div>
          <h1>🚨 Monitoring zobowiązań</h1>
          <div class="subtitle">Stan na dzień: <strong>{report_date}</strong></div>
        </div>
        <form class="date-box" method="get">
          <label>Data raportu: <input type="date" name="date" value="{report_date}"></label>
          <button type="submit">Pokaż</button>
        </form>
      </div>

      <div class="actions" style="margin-top:14px;">
        <a href="/admin/raporty/faktury-do-zaplaty/?date={report_date}" target="_blank" rel="noopener">Faktury do zapłaty ↗</a>
        <a href="/admin/finance/expensedocument/" target="_blank" rel="noopener">Koszty / faktury ↗</a>
        <a href="/admin/finance/expensedocument/add/" target="_blank" rel="noopener">Dodaj fakturę ↗</a>
        <a href="#" onclick="window.print(); return false;">PDF</a>
      </div>

      {alert}

      <div class="grid">
        <div class="card">Otwarte zobowiązania<strong class="minus">{len(open_docs)}</strong><div>{money(open_sum)}</div></div>
        <div class="card">Po terminie<strong class="minus">{len(overdue_docs)}</strong><div>{money(overdue_sum)}</div></div>
        <div class="card">Termin w 14 dni<strong class="warn">{len(due_soon_docs)}</strong><div>{money(due_soon_sum)}</div></div>
        <div class="card">Bez terminu<strong class="warn">{len(no_due_date_docs)}</strong><div>{money(no_due_sum)}</div></div>
      </div>

      <div class="section">
        <h2>Faktury po terminie</h2>
        <table>
          <tr><th>Termin</th><th>Numer</th><th>Kontrahent</th><th>Kategoria</th><th>Brutto</th><th>Zapłacono</th><th>Pozostało</th><th>Status</th><th></th></tr>
          {rows(overdue_docs, report_date, "Brak faktur po terminie.")}
        </table>
      </div>

      <div class="section">
        <h2>Terminy w ciągu 14 dni</h2>
        <table>
          <tr><th>Termin</th><th>Numer</th><th>Kontrahent</th><th>Kategoria</th><th>Brutto</th><th>Zapłacono</th><th>Pozostało</th><th>Status</th><th></th></tr>
          {rows(due_soon_docs, report_date, "Brak faktur z terminem w ciągu 14 dni.")}
        </table>
      </div>
    </body>
    </html>
    '''
    return HttpResponse(html)


_original_get_urls_obligation_monitoring = admin.site.get_urls


def get_urls_obligation_monitoring():
    urls = _original_get_urls_obligation_monitoring()
    custom = [
        path(
            "raporty/monitoring-zobowiazan/",
            admin.site.admin_view(obligation_monitoring_view),
            name="obligation_monitoring",
        )
    ]
    return custom + urls


if not getattr(admin.site, "_obligation_monitoring_patched", False):
    admin.site.get_urls = get_urls_obligation_monitoring
    admin.site._obligation_monitoring_patched = True
