# Etap 2.8.1 - Numeracja spraw i sprawy przeterminowane

Bez migracji.

## Instalacja

```bash
cd /opt/_docker-compose/wspolnota
unzip wspolnota_etap_2_8_1_numeracja_i_przeterminowane_windykacja_patch.zip
python3 patch_etap_2_8_1_numeracja_i_przeterminowane_windykacja.py
docker compose down
docker compose build --no-cache
docker compose up -d
docker compose exec web python manage.py check
```

## Uzupełnienie pustych numerów

```bash
docker compose exec web python manage.py shell -c "
from apps.audit.models import DebtCollectionCase
for x in DebtCollectionCase.objects.filter(case_number=''):
    x.save()
print('OK')
"
```
