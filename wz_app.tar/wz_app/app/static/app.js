const $=id=>document.getElementById(id);
let recipients=[], materials=[], editingId=null;
const today=new Date(); $("issue_date").value=today.toISOString().slice(0,10);
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
async function api(url,opts={}){const r=await fetch(url,{headers:{"Content-Type":"application/json"},...opts});if(!r.ok)throw new Error(await r.text());return r.json()}
function page(name){document.querySelectorAll(".page").forEach(x=>x.classList.add("hidden"));$("page-"+name).classList.remove("hidden");document.querySelectorAll("nav button").forEach(b=>b.classList.toggle("active",b.dataset.page===name));if(name==="archive")loadArchive();if(name==="recipients")loadRecipients();if(name==="materials")loadMaterials()}
document.querySelectorAll("nav button").forEach(b=>b.onclick=()=>page(b.dataset.page));
async function loadRecipients(){
 recipients=await api("/api/recipients");
 $("recipientlist").innerHTML=recipients.map(r=>`<option value="${esc(r.name)}"></option>`).join("");
 $("recipients").innerHTML=recipients.map(r=>`<tr><td>${esc(r.name)}</td><td>${esc(r.nip)}</td><td>${esc(r.address)} ${esc(r.city)}</td><td><button class="danger small" onclick="delRecipient(${r.id})">Usuń</button></td></tr>`).join("");
}
function matchRecipient(){
 const name=$("recipient_name").value.trim().toLocaleLowerCase("pl");
 const r=recipients.find(x=>x.name.trim().toLocaleLowerCase("pl")===name);
 if(r){$("recipient_nip").value=r.nip;$("recipient_address").value=[r.address,r.city].filter(Boolean).join(", ");$("addRecipientInline").classList.add("hidden");$("recipient_name").dataset.id=r.id;}
 else{$("recipient_name").dataset.id="";$("recipient_nip").value="";$("recipient_address").value="";$("addRecipientInline").classList.toggle("hidden",!name);}
}
$("recipient_name").addEventListener("input",()=>{
 const q=$("recipient_name").value.toLocaleLowerCase("pl");
 $("recipientlist").innerHTML=recipients.filter(r=>r.name.toLocaleLowerCase("pl").includes(q)).map(r=>`<option value="${esc(r.name)}"></option>`).join("");
 matchRecipient();
});
$("recipient_name").addEventListener("change",matchRecipient);
$("addRecipientInline").onclick=async()=>{
 const name=$("recipient_name").value.trim();if(!name)return;
 const parts=$("recipient_address").value.split(",").map(x=>x.trim());
 const r=await api("/api/recipients",{method:"POST",body:JSON.stringify({name,nip:$("recipient_nip").value,address:parts[0]||"",city:parts.slice(1).join(", ")})});
 await loadRecipients();$("recipient_name").dataset.id=r.id;$("addRecipientInline").classList.add("hidden");
};
window.delRecipient=async id=>{if(confirm("Usunąć odbiorcę?")){await api("/api/recipients/"+id,{method:"DELETE"});loadRecipients()}};
$("saveRecipient").onclick=async()=>{await api("/api/recipients",{method:"POST",body:JSON.stringify({name:$("r_name").value,nip:$("r_nip").value,address:$("r_address").value,city:$("r_city").value})});["r_name","r_nip","r_address","r_city"].forEach(x=>$(x).value="");loadRecipients()};
async function loadMaterials(){materials=await api("/api/materials");$("materials").innerHTML=materials.map(m=>`<tr><td>${esc(m.index_no)}</td><td>${esc(m.name)}</td><td>${esc(m.unit)}</td><td>${Number(m.default_price).toFixed(2)}</td><td><button class="danger small" onclick="delMaterial(${m.id})">Usuń</button></td></tr>`).join("")}
window.delMaterial=async id=>{if(confirm("Usunąć materiał?")){await api("/api/materials/"+id,{method:"DELETE"});loadMaterials()}};
$("saveMaterial").onclick=async()=>{await api("/api/materials",{method:"POST",body:JSON.stringify({index_no:$("m_index").value,name:$("m_name").value,unit:$("m_unit").value,default_price:Number($("m_price").value||0)})});["m_index","m_name","m_price"].forEach(x=>$(x).value="");loadMaterials()};
function addRow(m){
 let tr=document.createElement("tr");
 tr.innerHTML=`<td><input class="idx" list="indexlist" value="${esc(m?.index_no||"")}" placeholder="Indeks"></td><td><input class="name" list="matlist" value="${esc(m?.name||"")}" placeholder="Nazwa materiału"><button class="secondary small addMaterialInline hidden" type="button">＋ Dodaj materiał</button></td><td><input class="planned" type="number" step="0.001" value="0"></td><td><input class="unit" value="${esc(m?.unit||"szt.")}"></td><td><input class="issued" type="number" step="0.001" value="0"></td><td><input class="price" type="number" step="0.01" value="${m?.default_price||0}"></td><td><input class="account"></td><td><button class="danger small remove">×</button></td>`;
 tr.querySelector(".remove").onclick=()=>{tr.remove();calc()};
 const idx=tr.querySelector(".idx"), name=tr.querySelector(".name"), add=tr.querySelector(".addMaterialInline");
 function matchMaterial(){
   let qi=idx.value.trim().toLocaleLowerCase("pl"), qn=name.value.trim().toLocaleLowerCase("pl");
   let found=materials.find(x=>(qi && x.index_no.toLocaleLowerCase("pl")===qi)||(qn && x.name.toLocaleLowerCase("pl")===qn));
   if(found){idx.value=found.index_no;name.value=found.name;tr.querySelector(".unit").value=found.unit;tr.querySelector(".price").value=found.default_price;add.classList.add("hidden");}
   else add.classList.toggle("hidden",!(qi||qn));
   calc();
 }
 idx.addEventListener("input",()=>{let q=idx.value.toLocaleLowerCase("pl");$("indexlist").innerHTML=materials.filter(x=>x.index_no.toLocaleLowerCase("pl").includes(q)).map(x=>`<option value="${esc(x.index_no)}"></option>`).join("");matchMaterial()});
 name.addEventListener("input",()=>{let q=name.value.toLocaleLowerCase("pl");$("matlist").innerHTML=materials.filter(x=>x.name.toLocaleLowerCase("pl").includes(q)).map(x=>`<option value="${esc(x.name)}"></option>`).join("");matchMaterial()});
 idx.addEventListener("change",matchMaterial);name.addEventListener("change",matchMaterial);
 add.onclick=async()=>{
   if(!name.value.trim()){alert("Wpisz nazwę materiału.");return}
   await api("/api/materials",{method:"POST",body:JSON.stringify({index_no:idx.value,name:name.value,unit:tr.querySelector(".unit").value,default_price:Number(tr.querySelector(".price").value||0)})});
   await refreshMaterialList();matchMaterial();add.classList.add("hidden");
 };
 tr.querySelectorAll("input").forEach(i=>i.addEventListener("input",calc));
 $("items").appendChild(tr);calc();
}
$("addrow").onclick=()=>addRow();$("items").innerHTML='<datalist id="matlist"></datalist>';
async function refreshMaterialList(){await loadMaterials();$("matlist").innerHTML=materials.map(m=>`<option value="${esc(m.name)}"></option>`).join("");$("indexlist").innerHTML=materials.map(m=>`<option value="${esc(m.index_no)}"></option>`).join("")}
function val(tr,cls){return tr.querySelector("."+cls).value}
function calc(){let total=0;document.querySelectorAll("#items tr").forEach(tr=>total+=Number(val(tr,"issued")||0)*Number(val(tr,"price")||0));$("total").textContent="Wartość razem: "+total.toFixed(2).replace(".",",")+" zł"}
$("save").onclick=async()=>{try{let trs=[...$("items").querySelectorAll("tr")];let incomplete=trs.findIndex(tr=>!val(tr,"name").trim());if(incomplete>=0)throw Error("Uzupełnij nazwę materiału w pozycji "+(incomplete+1)+".");let rows=trs.map(tr=>({index_no:val(tr,"idx"),name:val(tr,"name"),quantity_planned:Number(val(tr,"planned")||0),unit:val(tr,"unit"),quantity_issued:Number(val(tr,"issued")||0),price:Number(val(tr,"price")||0),account_no:val(tr,"account")}));let body={recipient_id:$("recipient_name").dataset.id?Number($("recipient_name").dataset.id):null,recipient_name:$("recipient_name").value,recipient_nip:$("recipient_nip").value,recipient_address:$("recipient_address").value,issue_date:$("issue_date").value,warehouse_no:$("warehouse_no").value,transport:$("transport").value,order_no:$("order_no").value,purpose:$("purpose").value,dispatch_date:$("dispatch_date").value,shipping_cost:$("shipping_cost").value,invoice_ref:$("invoice_ref").value,issuer:$("issuer").value,approver:$("approver").value,items:rows};if(!body.recipient_name.trim())throw Error("Wpisz nazwę odbiorcy.");let result;if(editingId){result=await api("/api/documents/"+editingId,{method:"PUT",body:JSON.stringify(body)});$("notice").textContent="Zaktualizowano dokument.";}else{result=await api("/api/documents",{method:"POST",body:JSON.stringify(body)});$("notice").textContent="Zapisano dokument "+result.number;}window.open(`/api/documents/${result.id}/pdf`,"_blank");editingId=null;$("cancelEdit").classList.add("hidden");$("save").textContent="Zapisz WZ i wygeneruj PDF";loadArchive();}catch(e){let msg=e.message;try{let j=JSON.parse(msg);msg=j.detail||msg}catch{}alert("Nie udało się zapisać: "+msg)}};
$("cancelEdit").onclick=()=>{editingId=null;$("cancelEdit").classList.add("hidden");$("save").textContent="Zapisz WZ i wygeneruj PDF";$("notice").textContent="Anulowano edycję.";$("items").innerHTML="";addRow()};
window.editDocument=async id=>{let d=await api("/api/documents/"+id);editingId=id;page("new");$("recipient").value=d.recipient_id||"";["recipient_name","recipient_nip","recipient_address","issue_date","warehouse_no","transport","order_no","purpose","dispatch_date","shipping_cost","invoice_ref","issuer","approver"].forEach(k=>$(k).value=d[k]||"");$("items").innerHTML="";d.items.forEach(it=>{addRow(it);let tr=$("items").lastElementChild;tr.querySelector(".planned").value=it.quantity_planned;tr.querySelector(".issued").value=it.quantity_issued;tr.querySelector(".account").value=it.account_no;});calc();$("cancelEdit").classList.remove("hidden");$("save").textContent="Zapisz zmiany i wygeneruj PDF";$("notice").textContent="Edycja dokumentu "+d.number;};
async function loadArchive(){let p=new URLSearchParams({q:$("search").value,date_from:$("from").value,date_to:$("to").value});let rows=await api("/api/documents?"+p);$("archive").innerHTML=rows.map(d=>`<tr><td><b>${esc(d.number)}</b></td><td>${esc(d.issue_date)}</td><td>${esc(d.recipient_name)}</td><td>${esc(d.recipient_nip)}</td><td><button class="small" onclick="editDocument(${d.id})">Edytuj</button> <button class="small" onclick="window.open('/api/documents/${d.id}/pdf','_blank')">PDF</button></td></tr>`).join("")||'<tr><td colspan="5" class="muted">Brak dokumentów spełniających kryteria.</td></tr>'}
$("filter").onclick=loadArchive;
async function loadCompany(){let c=await api("/api/settings/company");for(let k of ["name","nip","address","postal_code","city","phone","email","extra"])$("c_"+k).value=c[k]||""}
$("saveCompany").onclick=async()=>{let c={};for(let k of ["name","nip","address","postal_code","city","phone","email","extra"])c[k]=$("c_"+k).value;await api("/api/settings/company",{method:"PUT",body:JSON.stringify(c)});$("companyNotice").textContent="Dane firmy zapisane."};
loadRecipients();refreshMaterialList();addRow();loadCompany();
