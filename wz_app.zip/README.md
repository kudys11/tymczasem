# MAGAZYN WZ – aktualizacja funkcjonalna

## Wymagania
- Docker Engine + Docker Compose
- Port domyślny 8457
- Wolumen `wz_data` przechowuje SQLite

## Aktualizacja istniejącej instalacji
1. Zrób kopię bazy:
   ```bash
   cd /opt/docker/wz_app
   mkdir -p /opt/docker/wz-backup
   docker compose exec -T wz cat /data/wz.sqlite3 > /opt/docker/wz-backup/wz-$(date +%F-%H%M).sqlite3
   ```
2. Rozpakuj zawartość ZIP do katalogu projektu `/opt/docker/wz_app`, zastępując pliki aplikacji.
3. Przebuduj kontener:
   ```bash
   docker compose up -d --build
   ```
4. W przeglądarce wykonaj twarde odświeżenie: Ctrl+F5.

**Nie używaj `docker compose down -v`** – usuwa wolumen z bazą danych.

## Zmiany
- nowa zakładka „Dane firmy” i API `/api/settings/company`;
- dane firmy zapisywane w SQLite i drukowane w nagłówku PDF;
- dynamiczna lista podpowiedzi odbiorców; wybór istniejącego odbiorcy uzupełnia pola;
- przycisk dodawania odbiorcy, gdy wpisana nazwa nie istnieje (formularz pyta o NIP, adres i miejscowość);
- podpowiedzi materiałów po indeksie i nazwie;
- przycisk „Dodaj do bazy” przy nowej pozycji materiałowej;
- walidacja wskazuje numer niekompletnego wiersza zamiast odrzucać go po cichu;
- zachowana edycja istniejącego dokumentu.

## Uwaga
To aktualizacja funkcjonalna MVP, nie certyfikowany system ERP. Przed użyciem produkcyjnym należy przetestować wydruk na docelowej drukarce, zrobić próbę odtworzenia kopii bazy i dodać uwierzytelnianie oraz role użytkowników. PostgreSQL pozostaje kolejnym etapem migracji.


## Aktualizacja poprawkowa v2.1
Ta paczka naprawia identyfikator pola wyszukiwania odbiorcy, usuwa zdublowaną zakładkę danych firmy i porządkuje zdublowane endpointy konfiguracji. Zachowuje zgodność z istniejącą bazą SQLite (`app_settings`). Po aktualizacji wykonaj twarde odświeżenie przeglądarki (Ctrl+F5).
