# MAGAZYN WZ – aktualizacja 3.0

## Co zawiera
- Wyszukiwanie odbiorców na żywo (częściowa nazwa/NIP), wybór z wyników i uzupełnianie NIP/adresu.
- Dodawanie nowego odbiorcy bez opuszczania WZ, z formularzem NIP/adres/miejscowość.
- Wyszukiwanie materiału po indeksie lub nazwie.
- Przycisk dodania nowego materiału pokazuje się także wtedy, gdy indeksu nie ma w bazie; materiał można dopisać w formularzu przy pozycji.
- Zakładka Dane firmy z zapisem ustawień.
- Wydruk oparty na dostarczonym przez użytkownika oryginalnym formularzu PDF, zamiast ręcznie rysowanej tabeli.
- Czcionka DejaVu Sans z polskimi znakami.
- Numeracja roczna i brak gospodarki magazynowej pozostają bez zmian.

## Instalacja
1. Zrób kopię bazy: `docker compose exec -T wz cat /data/wz.sqlite3 > wz-przed-v3.sqlite3`
2. Rozpakuj zawartość ZIP do katalogu projektu, zastępując katalog `app`.
3. Wykonaj `docker compose up -d --build`.
4. Otwórz aplikację przez Ctrl+F5. Jeśli używasz reverse proxy, odśwież też ewentualny cache proxy.

Nie wykonuj `docker compose down -v` i nie usuwaj wolumenu `wz_data`.

Uwaga: PDF korzysta z oryginalnego wzoru dołączonego do `app/static/wz_template.pdf`. Przed użyciem formalnym należy sprawdzić wydruk próbny na konkretnej drukarce.
