import os, sqlite3, io
from datetime import date, datetime
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse, StreamingResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from pypdf import PdfReader, PdfWriter

DB = os.getenv("DATABASE_PATH", "/data/wz.sqlite3")
Path(DB).parent.mkdir(parents=True, exist_ok=True)
app = FastAPI(title="WZ – dokumenty magazynowe")
app.mount("/static", StaticFiles(directory="app/static"), name="static")

def conn():
    c = sqlite3.connect(DB, timeout=30)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    return c

def init_db():
    with conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS app_settings(key TEXT PRIMARY KEY, value TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS recipients(
          id INTEGER PRIMARY KEY, name TEXT NOT NULL, nip TEXT DEFAULT '',
          address TEXT DEFAULT '', city TEXT DEFAULT '', notes TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS materials(
          id INTEGER PRIMARY KEY, index_no TEXT DEFAULT '', name TEXT NOT NULL,
          unit TEXT DEFAULT 'szt.', default_price REAL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS documents(
          id INTEGER PRIMARY KEY, number TEXT UNIQUE NOT NULL, year INTEGER NOT NULL,
          sequence INTEGER NOT NULL, recipient_id INTEGER, recipient_name TEXT NOT NULL,
          recipient_nip TEXT DEFAULT '', recipient_address TEXT DEFAULT '',
          issue_date TEXT NOT NULL, warehouse_no TEXT DEFAULT '', transport TEXT DEFAULT '',
          order_no TEXT DEFAULT '', purpose TEXT DEFAULT '', dispatch_date TEXT DEFAULT '',
          shipping_cost TEXT DEFAULT '', invoice_ref TEXT DEFAULT '',
          issuer TEXT DEFAULT '', approver TEXT DEFAULT '', notes TEXT DEFAULT '',
          created_at TEXT NOT NULL,
          FOREIGN KEY(recipient_id) REFERENCES recipients(id)
        );
        CREATE TABLE IF NOT EXISTS document_items(
          id INTEGER PRIMARY KEY, document_id INTEGER NOT NULL,
          index_no TEXT DEFAULT '', name TEXT NOT NULL, quantity_planned REAL DEFAULT 0,
          unit TEXT DEFAULT 'szt.', quantity_issued REAL DEFAULT 0,
          price REAL DEFAULT 0, account_no TEXT DEFAULT '', stock_qty TEXT DEFAULT '',
          FOREIGN KEY(document_id) REFERENCES documents(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_documents_date ON documents(issue_date);
        CREATE INDEX IF NOT EXISTS idx_documents_recipient ON documents(recipient_name);
        """)
init_db()

COMPANY_FIELDS = ["name","nip","address","postal_code","city","phone","email","extra"]
@app.get("/api/settings/company")
def get_company():
    with conn() as c:
        rows = c.execute("SELECT key,value FROM app_settings WHERE key LIKE 'company_%'").fetchall()
        data = {r["key"].replace("company_","",1): r["value"] for r in rows}
        return {k:data.get(k,"") for k in COMPANY_FIELDS}
@app.put("/api/settings/company")
def save_company(data: dict):
    with conn() as c:
        for key in COMPANY_FIELDS:
            value = str(data.get(key,"") or "")
            c.execute("INSERT INTO app_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                      ("company_"+key,value))
    return {"ok":True}

class Recipient(BaseModel):
    name: str
    nip: str = ""
    address: str = ""
    city: str = ""
    notes: str = ""

class Material(BaseModel):
    index_no: str = ""
    name: str
    unit: str = "szt."
    default_price: float = 0

class Item(BaseModel):
    index_no: str = ""
    name: str
    quantity_planned: float = 0
    unit: str = "szt."
    quantity_issued: float = 0
    price: float = 0
    account_no: str = ""
    stock_qty: str = ""

class Document(BaseModel):
    recipient_id: Optional[int] = None
    recipient_name: str
    recipient_nip: str = ""
    recipient_address: str = ""
    issue_date: str = Field(default_factory=lambda: date.today().isoformat())
    warehouse_no: str = ""
    transport: str = ""
    order_no: str = ""
    purpose: str = ""
    dispatch_date: str = ""
    shipping_cost: str = ""
    invoice_ref: str = ""
    issuer: str = ""
    approver: str = ""
    notes: str = ""
    items: list[Item] = []

@app.get("/", response_class=HTMLResponse)
def home():
    return Path("app/static/index.html").read_text(encoding="utf-8")

@app.get("/api/recipients")
def recipients():
    with conn() as c:
        return [dict(x) for x in c.execute("SELECT * FROM recipients ORDER BY name")]
@app.post("/api/recipients")
def add_recipient(x: Recipient):
    with conn() as c:
        cur=c.execute("INSERT INTO recipients(name,nip,address,city,notes) VALUES(?,?,?,?,?)",
                      (x.name,x.nip,x.address,x.city,x.notes))
        return {"id":cur.lastrowid}
@app.delete("/api/recipients/{rid}")
def delete_recipient(rid:int):
    with conn() as c: c.execute("DELETE FROM recipients WHERE id=?",(rid,))
    return {"ok":True}

@app.get("/api/materials")
def materials():
    with conn() as c: return [dict(x) for x in c.execute("SELECT * FROM materials ORDER BY name")]
@app.post("/api/materials")
def add_material(x: Material):
    with conn() as c:
        cur=c.execute("INSERT INTO materials(index_no,name,unit,default_price) VALUES(?,?,?,?)",
                      (x.index_no,x.name,x.unit,x.default_price))
        return {"id":cur.lastrowid}
@app.delete("/api/materials/{mid}")
def delete_material(mid:int):
    with conn() as c: c.execute("DELETE FROM materials WHERE id=?",(mid,))
    return {"ok":True}

@app.post("/api/documents")
def create_document(x: Document):
    if not x.items: raise HTTPException(400,"Dokument musi zawierać przynajmniej jedną pozycję.")
    try: yr=int(x.issue_date[:4])
    except: raise HTTPException(400,"Nieprawidłowa data dokumentu.")
    with conn() as c:
        c.execute("BEGIN IMMEDIATE")
        seq=c.execute("SELECT COALESCE(MAX(sequence),0)+1 FROM documents WHERE year=?",(yr,)).fetchone()[0]
        number=f"WZ/{seq:03d}/{yr}"
        cur=c.execute("""INSERT INTO documents(number,year,sequence,recipient_id,recipient_name,recipient_nip,
          recipient_address,issue_date,warehouse_no,transport,order_no,purpose,dispatch_date,shipping_cost,
          invoice_ref,issuer,approver,notes,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
          (number,yr,seq,x.recipient_id,x.recipient_name,x.recipient_nip,x.recipient_address,x.issue_date,
           x.warehouse_no,x.transport,x.order_no,x.purpose,x.dispatch_date,x.shipping_cost,x.invoice_ref,
           x.issuer,x.approver,x.notes,datetime.now().isoformat(timespec="seconds")))
        did=cur.lastrowid
        for it in x.items:
            c.execute("""INSERT INTO document_items(document_id,index_no,name,quantity_planned,unit,
              quantity_issued,price,account_no,stock_qty) VALUES(?,?,?,?,?,?,?,?,?)""",
              (did,it.index_no,it.name,it.quantity_planned,it.unit,it.quantity_issued,it.price,it.account_no,it.stock_qty))
        return {"id":did,"number":number}

@app.put("/api/documents/{did}")
def update_document(did: int, x: Document):
    if not x.items:
        raise HTTPException(400, "Dokument musi zawierać przynajmniej jedną pozycję.")
    with conn() as c:
        c.execute("BEGIN IMMEDIATE")
        old = c.execute("SELECT id FROM documents WHERE id=?", (did,)).fetchone()
        if not old:
            raise HTTPException(404, "Nie znaleziono dokumentu")
        c.execute("""UPDATE documents SET recipient_id=?,recipient_name=?,recipient_nip=?,recipient_address=?,
          issue_date=?,warehouse_no=?,transport=?,order_no=?,purpose=?,dispatch_date=?,shipping_cost=?,
          invoice_ref=?,issuer=?,approver=?,notes=? WHERE id=?""",
          (x.recipient_id,x.recipient_name,x.recipient_nip,x.recipient_address,x.issue_date,x.warehouse_no,
           x.transport,x.order_no,x.purpose,x.dispatch_date,x.shipping_cost,x.invoice_ref,x.issuer,x.approver,x.notes,did))
        c.execute("DELETE FROM document_items WHERE document_id=?", (did,))
        for it in x.items:
            c.execute("""INSERT INTO document_items(document_id,index_no,name,quantity_planned,unit,
              quantity_issued,price,account_no,stock_qty) VALUES(?,?,?,?,?,?,?,?,?)""",
              (did,it.index_no,it.name,it.quantity_planned,it.unit,it.quantity_issued,it.price,it.account_no,it.stock_qty))
    return {"id": did, "updated": True}

@app.get("/api/documents")
def list_documents(q:str="", date_from:str="", date_to:str=""):
    sql="SELECT * FROM documents WHERE 1=1"; args=[]
    if q:
        sql+=" AND (number LIKE ? OR recipient_name LIKE ?)"; args += [f"%{q}%",f"%{q}%"]
    if date_from: sql+=" AND issue_date>=?"; args.append(date_from)
    if date_to: sql+=" AND issue_date<=?"; args.append(date_to)
    sql+=" ORDER BY issue_date DESC, id DESC"
    with conn() as c: return [dict(x) for x in c.execute(sql,args)]

@app.get("/api/documents/{did}")
def get_document(did:int):
    with conn() as c:
        d=c.execute("SELECT * FROM documents WHERE id=?",(did,)).fetchone()
        if not d: raise HTTPException(404,"Nie znaleziono dokumentu")
        out=dict(d); out["items"]=[dict(x) for x in c.execute("SELECT * FROM document_items WHERE document_id=? ORDER BY id",(did,))]
        return out

def money(v):
    return f"{float(v or 0):.2f}".replace(".", ",")


def _register_wz_font():
    font_path = Path("app/fonts/DejaVuSans.ttf")
    if "WZDejaVu" not in pdfmetrics.getRegisteredFontNames():
        pdfmetrics.registerFont(TTFont("WZDejaVu", str(font_path)))
    return "WZDejaVu"

def _put(c, x_px, y_px, text, max_width_px=200, size=7, page_w=595.2, page_h=841.68):
    """Współrzędne w pikselach skanu wzoru (992 x 1403), początek u góry."""
    if text is None: return
    text = str(text).strip()
    if not text: return
    scale = page_w / 992.0
    x = x_px * scale
    y = page_h - y_px * scale
    font = _register_wz_font()
    fs = size
    while fs > 4.5 and pdfmetrics.stringWidth(text, font, fs) > max_width_px * scale:
        fs -= .25
    c.setFont(font, fs)
    c.drawString(x, y, text)

def make_pdf(d, items):
    # Używamy oryginalnego formularza użytkownika jako tła, dzięki czemu
    # szerokości i położenie wszystkich 21 pól pozostają zgodne z wzorem.
    template = Path("app/static/wz_template.pdf")
    reader = PdfReader(str(template))
    base = reader.pages[0]
    page_w, page_h = float(base.mediabox.width), float(base.mediabox.height)
    overlay_io = io.BytesIO()
    c = canvas.Canvas(overlay_io, pagesize=(page_w, page_h))
    with conn() as db:
        rows = db.execute("SELECT key,value FROM app_settings WHERE key LIKE 'company_%'").fetchall()
    company = {r["key"].replace("company_","",1): r["value"] for r in rows}
    _register_wz_font()

    # Dwie kopie formularza – współrzędne odnoszą się do oryginalnego skanu.
    for offset, copy_no in [(0, 1), (587, 2)]:
        # Dane firmy – lewy panel
        _put(c, 113, 132+offset, company.get("name",""), 200, 8)
        _put(c, 113, 151+offset, company.get("address",""), 195, 6.5)
        city_line = " ".join(x for x in [company.get("postal_code",""), company.get("city","")] if x)
        _put(c, 113, 165+offset, city_line, 195, 6.5)
        contact_line = " ".join(x for x in [company.get("phone",""), company.get("email","")] if x)
        _put(c, 113, 178+offset, contact_line, 195, 5.5)
        _put(c, 148, 188+offset, company.get("nip",""), 145, 6.5)
        # Odbiorca – środkowy panel
        _put(c, 330, 137+offset, d.get("recipient_name",""), 235, 7.5)
        _put(c, 330, 157+offset, "NIP: " + d.get("recipient_nip",""), 235, 6.5)
        _put(c, 330, 176+offset, d.get("recipient_address",""), 235, 6.5)
        # Pola po prawej. Biały prostokąt usuwa nadrukowaną przykładową datę.
        scale = page_w / 992.0
        date_x0, date_x1 = 788*scale, 882*scale
        date_y_top = page_h - (179+offset)*scale
        date_y_bottom = page_h - (194+offset)*scale
        c.setFillColorRGB(1,1,1)
        c.rect(date_x0, date_y_bottom, date_x1-date_x0, date_y_top-date_y_bottom, stroke=0, fill=1)
        c.setFillColorRGB(0,0,0)
        _put(c, 690, 132+offset, d.get("number",""), 88, 6.5)
        _put(c, 800, 132+offset, str(copy_no), 55, 6.5)
        _put(c, 692, 188+offset, d.get("warehouse_no",""), 90, 6.5)
        _put(c, 795, 186+offset, d.get("issue_date",""), 85, 6.5)
        # Pola 5–10 – pas pod nagłówkiem
        meta = [
            (112, 218, d.get("transport",""), 112),
            (232, 218, d.get("order_no",""), 105),
            (393, 218, d.get("purpose",""), 90),
            (482, 218, d.get("dispatch_date",""), 85),
            (581, 218, d.get("shipping_cost",""), 90),
            (690, 218, d.get("invoice_ref",""), 185),
        ]
        for x,y,t,w in meta: _put(c,x,y+offset,t,w,6)
        # Pozycje 11–17 – dokładne granice kolumn z formularza.
        # Indeks | nazwa | ilość zadysponowana | jm | wydana | cena | wartość | konto | zapas
        xcols=[109,209,392,476,508,577,657,741,817,883]
        row_y0=278+offset
        row_step=30.5
        for i,it in enumerate(items[:10]):
            yy=row_y0+i*row_step
            vals=[
                it.get("index_no",""), it.get("name",""),
                money(it.get("quantity_planned",0)), it.get("unit",""),
                money(it.get("quantity_issued",0)), money(it.get("price",0)),
                money(float(it.get("quantity_issued",0) or 0)*float(it.get("price",0) or 0)),
                it.get("account_no",""), it.get("stock_qty","")
            ]
            for j,val in enumerate(vals):
                _put(c,xcols[j]+3,yy,val,xcols[j+1]-xcols[j]-6,6)
        # Podpisy – pola 18, 19 i 20
        _put(c, 112, 635+offset, d.get("issuer",""), 90, 6.5)
        _put(c, 214, 635+offset, d.get("approver",""), 90, 6.5)

    c.save()
    overlay_io.seek(0)
    overlay = PdfReader(overlay_io).pages[0]
    base.merge_page(overlay)
    writer=PdfWriter()
    writer.add_page(base)
    writer.add_metadata({"/Title": d.get("number","WZ")})
    out=io.BytesIO()
    writer.write(out)
    out.seek(0)
    return out

@app.get("/api/documents/{did}/pdf")
def document_pdf(did:int):
    d=get_document(did); buf=make_pdf(d,d["items"])
    safe=d["number"].replace("/","-")
    return StreamingResponse(buf,media_type="application/pdf",
      headers={"Content-Disposition":f'inline; filename="{safe}.pdf"'})
