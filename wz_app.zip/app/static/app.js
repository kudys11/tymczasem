const $=id=>document.getElementById(id);
let recipients=[], materials=[], editingId=null, selectedRecipientId=null, activeMaterialRow=null;
$("issue_date").value=new Date().toISOString().slice(0,10);
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
async function api(url,opts={}){const r=await fetch(url,{headers:{"Content-Type":"application/json"},...opts});if(!r.ok){let e;try{e=await r.json()}catch{e={detail:await r.text()}}throw Error(e.detail||"Błąd serwera")}return r.json()}
function page(name){document.querySelectorAll(".page").forEach(x=>x.classList.add("hidden"));$("page-"+name).classList.remove("hidden");document.querySelectorAll("nav button").forEach(b=>b.classList.toggle("active",b.dataset.page===name));if(name==="archive")loadArchive();if(name==="recipients")loadRecipients();if(name==="materials")loadMaterials();if(name==="settings")loadCompany()}
document.querySelectorAll("nav button").forEach(b=>b.onclick=()=>page(b.dataset.page));

async function loadRecipients(){
 recipients=await api("/api/recipients");
 if($("recipients"))$("recipients").innerHTML=recipients.map(r=>`<tr><td>${esc(r.name)}</td><td>${esc(r.nip)}</td><td>${esc(r.address)} ${esc(r.city)}</td><td><button class="danger small" onclick="delRecipient(${r.id})">Usuń</button></td></tr>`).join("");
}
function selectRecipient(r){
 selectedRecipientId=r.id;$("recipient_search").value=r.name;$("recipient_name").value=r.name;
 $("recipient_nip").value=r.nip||"";$("recipient_address").value=[r.address,r.city].filter(Boolean).join(", ");
 $("recipient_matches").classList.add("hidden");$("addRecipientInline").classList.add("hidden");$("newRecipientBox").classList.add("hidden");
}
function searchRecipients(){
 const q=$("recipient_search").value.trim().toLocaleLowerCase("pl");
 selectedRecipientId=null;$("recipient_name").value="";
 $("recipient_nip").value="";$("recipient_address").value="";
 const matches=q?recipients.filter(r=>r.name.toLocaleLowerCase("pl").includes(q)||String(r.nip||"").includes(q)).slice(0,8):[];
 $("recipient_matches").innerHTML=matches.map(r=>`<button type="button" class="suggestion" data-id="${r.id}"><b>${esc(r.name)}</b><small>${esc(r.nip)} · ${esc([r.address,r.city].filter(Boolean).join(", "))}</small></button>`).join("");
 $("recipient_matches").classList.toggle("hidden",!matches.length);
 $("recipient_matches").querySelectorAll("button").forEach(b=>b.onclick=()=>selectRecipient(recipients.find(r=>r.id===Number(b.dataset.id))));
 $("addRecipientInline").classList.toggle("hidden",!q||matches.some(r=>r.name.toLocaleLowerCase("pl")===q));
 $("newRecipientBox").classList.add("hidden");
}
$("recipient_search").addEventListener("input",searchRecipients);
$("recipient_search").addEventListener("focus",searchRecipients);
$("addRecipientInline").onclick=()=>{
 $("nr_name").value=$("recipient_search").value.trim();["nr_nip","nr_address","nr_city"].forEach(id=>$(id).value="");
 $("newRecipientBox").classList.remove("hidden");$("recipient_matches").classList.add("hidden");
};
$("saveInlineRecipient").onclick=async()=>{
 try{
  const x={name:$("nr_name").value.trim(),nip:$("nr_nip").value.trim(),address:$("nr_address").value.trim(),city:$("nr_city").value.trim()};
  if(!x.name)throw Error("Wpisz nazwę odbiorcy.");
  const r=await api("/api/recipients",{method:"POST",body:JSON.stringify(x)});
  await loadRecipients();selectRecipient(recipients.find(z=>z.id===r.id)||{id:r.id,...x});
 }catch(e){alert(e.message)}
};
window.delRecipient=async id=>{if(confirm("Usunąć odbiorcę?")){await api("/api/recipients/"+id,{method:"DELETE"});loadRecipients()}};
$("saveRecipient").onclick=async()=>{try{await api("/api/recipients",{method:"POST",body:JSON.stringify({name:$("r_name").value.trim(),nip:$("r_nip").value,address:$("r_address").value,city:$("r_city").value})});["r_name","r_nip","r_address","r_city"].forEach(x=>$(x).value="");loadRecipients()}catch(e){alert(e.message)}};

async function loadMaterials(){
 materials=await api("/api/materials");
 if($("materials"))$("materials").innerHTML=materials.map(m=>`<tr><td>${esc(m.index_no)}</td><td>${esc(m.name)}</td><td>${esc(m.unit)}</td><td>${Number(m.default_price).toFixed(2)}</td><td><button class="danger small" onclick="delMaterial(${m.id})">Usuń</button></td></tr>`).join("");
}
window.delMaterial=async id=>{if(confirm("Usunąć materiał?")){await api("/api/materials/"+id,{method:"DELETE"});loadMaterials()}};
$("saveMaterial").onclick=async()=>{try{await api("/api/materials",{method:"POST",body:JSON.stringify({index_no:$("m_index").value.trim(),name:$("m_name").value.trim(),unit:$("m_unit").value,default_price:Number($("m_price").value||0)})});["m_index","m_name","m_price"].forEach(x=>$(x).value="");loadMaterials()}catch(e){alert(e.message)}};

function findMaterialByIndex(q){q=q.trim().toLocaleLowerCase("pl");return materials.find(m=>m.index_no.trim().toLocaleLowerCase("pl")===q)}
function findMaterialByName(q){q=q.trim().toLocaleLowerCase("pl");return materials.find(m=>m.name.trim().toLocaleLowerCase("pl")===q)}
function fillMaterial(tr,m){tr.querySelector(".idx").value=m.index_no||"";tr.querySelector(".name").value=m.name||"";tr.querySelector(".unit").value=m.unit||"szt.";tr.querySelector(".price").value=m.default_price??m.price??0;tr.querySelector(".saveMat").classList.add("hidden");calc()}
function updateMaterialAddButton(tr){
 const idx=tr.querySelector(".idx").value.trim(), name=tr.querySelector(".name").value.trim();
 const found=findMaterialByIndex(idx)||findMaterialByName(name);
 if(found){fillMaterial(tr,found);return}
 tr.querySelector(".saveMat").classList.toggle("hidden",!(idx||name));
}
function addRow(m){
 let tr=document.createElement("tr");
 tr.innerHTML=`<td><input class="idx" value="${esc(m?.index_no||"")}" placeholder="Indeks"></td><td><input class="name" value="${esc(m?.name||"")}" placeholder="Nazwa materiału"></td><td><input class="planned" type="number" step="0.001" value="${m?.quantity_planned??0}"></td><td><input class="unit" value="${esc(m?.unit||"szt.")}"></td><td><input class="issued" type="number" step="0.001" value="${m?.quantity_issued??0}"></td><td><input class="price" type="number" step="0.01" value="${m?.price??m?.default_price??0}"></td><td><input class="account" value="${esc(m?.account_no||"")}"></td><td><button class="secondary small saveMat hidden" type="button">＋ Dodaj do bazy</button><button class="danger small remove" type="button">×</button></td>`;
 tr.querySelector(".remove").onclick=()=>{tr.remove();calc()};
 tr.querySelector(".idx").addEventListener("input",()=>{let found=findMaterialByIndex(tr.querySelector(".idx").value);if(found)fillMaterial(tr,found);else updateMaterialAddButton(tr)});
 tr.querySelector(".name").addEventListener("input",()=>{let found=findMaterialByName(tr.querySelector(".name").value);if(found)fillMaterial(tr,found);else updateMaterialAddButton(tr)});
 tr.querySelector(".saveMat").onclick=()=>{
  activeMaterialRow=tr;
  $("im_index").value=tr.querySelector(".idx").value.trim();
  $("im_name").value=tr.querySelector(".name").value.trim();
  $("im_unit").value=tr.querySelector(".unit").value||"szt.";
  $("im_price").value=tr.querySelector(".price").value||0;
  $("inlineMaterialBox").classList.remove("hidden");
  $("im_name").focus();
 };
 tr.querySelectorAll("input").forEach(i=>i.addEventListener("input",calc));
 $("items").appendChild(tr);if(m){fillMaterial(tr,m)}calc();
}
$("addrow").onclick=()=>addRow();
$("saveInlineMaterial").onclick=async()=>{
 try{
  const x={index_no:$("im_index").value.trim(),name:$("im_name").value.trim(),unit:$("im_unit").value.trim()||"szt.",default_price:Number($("im_price").value||0)};
  if(!x.index_no&&!x.name)throw Error("Wpisz indeks lub nazwę materiału.");
  if(!x.name)throw Error("Wpisz nazwę materiału.");
  const r=await api("/api/materials",{method:"POST",body:JSON.stringify(x)});
  await loadMaterials();const m=materials.find(z=>z.id===r.id)||materials.find(z=>z.index_no===x.index_no);
  if(activeMaterialRow&&m)fillMaterial(activeMaterialRow,m);
  $("inlineMaterialBox").classList.add("hidden");activeMaterialRow=null;alert("Materiał dodany do bazy i przypisany do pozycji.");
 }catch(e){alert(e.message)}
};
function val(tr,cls){return tr.querySelector("."+cls).value}
function calc(){let total=0;document.querySelectorAll("#items tr").forEach(tr=>total+=Number(val(tr,"issued")||0)*Number(val(tr,"price")||0));$("total").textContent="Wartość razem: "+total.toFixed(2).replace(".",",")+" zł"}
$("save").onclick=async()=>{
 try{
  const trs=[...$("items").querySelectorAll("tr")];
  const rows=trs.map((tr,i)=>({index_no:val(tr,"idx").trim(),name:val(tr,"name").trim(),quantity_planned:Number(val(tr,"planned")||0),unit:val(tr,"unit").trim()||"szt.",quantity_issued:Number(val(tr,"issued")||0),price:Number(val(tr,"price")||0),account_no:val(tr,"account").trim()}));
  const invalid=rows.findIndex(x=>!x.name);
  if(invalid>=0)throw Error(`Pozycja ${invalid+1}: uzupełnij nazwę materiału albo usuń pusty wiersz.`);
  if(!rows.length)throw Error("Dodaj przynajmniej jedną pozycję.");
  const recipientName=$("recipient_name").value.trim()||$("recipient_search").value.trim();
  if(!recipientName)throw Error("Wpisz lub wybierz odbiorcę.");
  const body={recipient_id:selectedRecipientId,recipient_name:recipientName,recipient_nip:$("recipient_nip").value,recipient_address:$("recipient_address").value,issue_date:$("issue_date").value,warehouse_no:$("warehouse_no").value,transport:$("transport").value,order_no:$("order_no").value,purpose:$("purpose").value,dispatch_date:$("dispatch_date").value,shipping_cost:$("shipping_cost").value,invoice_ref:$("invoice_ref").value,issuer:$("issuer").value,approver:$("approver").value,items:rows};
  let result;
  if(editingId){result=await api("/api/documents/"+editingId,{method:"PUT",body:JSON.stringify(body)});result.id=editingId;$("notice").textContent="Zaktualizowano dokument."}
  else{result=await api("/api/documents",{method:"POST",body:JSON.stringify(body)});$("notice").textContent="Zapisano dokument "+result.number}
  window.open(`/api/documents/${result.id}/pdf`,"_blank");editingId=null;$("cancelEdit").classList.add("hidden");$("save").textContent="Zapisz WZ i wygeneruj PDF";await loadArchive();
 }catch(e){alert("Nie udało się zapisać: "+e.message)}
};
$("cancelEdit").onclick=()=>{editingId=null;$("cancelEdit").classList.add("hidden");$("save").textContent="Zapisz WZ i wygeneruj PDF";$("items").innerHTML="";addRow();$("notice").textContent="Anulowano edycję."};
window.editDocument=async id=>{
 let d=await api("/api/documents/"+id);editingId=id;page("new");selectedRecipientId=d.recipient_id||null;
 $("recipient_search").value=d.recipient_name;$("recipient_name").value=d.recipient_name;
 ["recipient_nip","recipient_address","issue_date","warehouse_no","transport","order_no","purpose","dispatch_date","shipping_cost","invoice_ref","issuer","approver"].forEach(k=>$(k).value=d[k]||"");
 $("items").innerHTML="";d.items.forEach(it=>addRow(it));calc();$("cancelEdit").classList.remove("hidden");$("save").textContent="Zapisz zmiany i wygeneruj PDF";$("notice").textContent="Edycja dokumentu "+d.number;
};
async function loadArchive(){let p=new URLSearchParams({q:$("search").value,date_from:$("from").value,date_to:$("to").value});let rows=await api("/api/documents?"+p);$("archive").innerHTML=rows.map(d=>`<tr><td><b>${esc(d.number)}</b></td><td>${esc(d.issue_date)}</td><td>${esc(d.recipient_name)}</td><td>${esc(d.recipient_nip)}</td><td><button class="small" onclick="editDocument(${d.id})">Edytuj</button> <button class="small" onclick="window.open('/api/documents/${d.id}/pdf','_blank')">PDF</button></td></tr>`).join("")||'<tr><td colspan="5" class="muted">Brak dokumentów spełniających kryteria.</td></tr>'}
$("filter").onclick=loadArchive;
async function loadCompany(){let c=await api("/api/settings/company");for(let k of ["name","nip","address","postal_code","city","phone","email","extra"])$("c_"+k).value=c[k]||""}
$("saveCompany").onclick=async()=>{try{let x={};for(let k of ["name","nip","address","postal_code","city","phone","email","extra"])x[k]=$("c_"+k).value;await api("/api/settings/company",{method:"PUT",body:JSON.stringify(x)});$("companyNotice").textContent="Dane firmy zapisane."; }catch(e){alert(e.message)}};
loadRecipients();loadMaterials();addRow();
