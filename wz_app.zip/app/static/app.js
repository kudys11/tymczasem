
const $=id=>document.getElementById(id);
let recipients=[], materials=[], editingId=null, selectedRecipientId=null;
$("issue_date").value=new Date().toISOString().slice(0,10);
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
async function api(url,opts={}){const r=await fetch(url,{headers:{"Content-Type":"application/json"},...opts});if(!r.ok){let e;try{e=await r.json()}catch{e={detail:await r.text()}}throw Error(e.detail||"Błąd serwera")}return r.json()}
function page(name){document.querySelectorAll(".page").forEach(x=>x.classList.add("hidden"));$("page-"+name).classList.remove("hidden");document.querySelectorAll("nav button").forEach(b=>b.classList.toggle("active",b.dataset.page===name));if(name==="archive")loadArchive();if(name==="recipients")loadRecipients();if(name==="materials")loadMaterials();if(name==="settings")loadCompany()}
document.querySelectorAll("nav button").forEach(b=>b.onclick=()=>page(b.dataset.page));
async function loadRecipients(){
 recipients=await api("/api/recipients");
 $("recipientlist").innerHTML=recipients.map(r=>`<option value="${esc(r.name)}"></option>`).join("");
 if($("recipients")) $("recipients").innerHTML=recipients.map(r=>`<tr><td>${esc(r.name)}</td><td>${esc(r.nip)}</td><td>${esc(r.address)} ${esc(r.city)}</td><td><button class="danger small" onclick="delRecipient(${r.id})">Usuń</button></td></tr>`).join("");
}
function matchRecipient(){
 const q=$("recipient_search").value.trim().toLocaleLowerCase("pl");
 const r=recipients.find(x=>x.name.trim().toLocaleLowerCase("pl")===q);
 if(r){selectedRecipientId=r.id;$("recipient_name").value=r.name;$("recipient_nip").value=r.nip;$("recipient_address").value=[r.address,r.city].filter(Boolean).join(", ");$("addRecipientInline").classList.add("hidden")}
 else {selectedRecipientId=null;$("addRecipientInline").classList.toggle("hidden",!q);if(q){$("recipient_name").value=$("recipient_search").value;$("recipient_nip").value="";$("recipient_address").value=""}}
}
$("recipient_search").addEventListener("input",matchRecipient);
$("recipient_search").addEventListener("change",matchRecipient);
$("addRecipientInline").onclick=async()=>{
 const name=$("recipient_search").value.trim(); if(!name)return;
 const nip=prompt("NIP odbiorcy (można pozostawić puste):","")??"";
 const address=prompt("Adres odbiorcy (można pozostawić puste):","")??"";
 const city=prompt("Miejscowość (można pozostawić pustą):","")??"";
 const x=await api("/api/recipients",{method:"POST",body:JSON.stringify({name,nip,address,city})});
 await loadRecipients();selectedRecipientId=x.id;$("recipient_search").value=name;$("recipient_name").value=name;$("recipient_nip").value=nip;$("recipient_address").value=[address,city].filter(Boolean).join(", ");$("addRecipientInline").classList.add("hidden");
};
window.delRecipient=async id=>{if(confirm("Usunąć odbiorcę?")){await api("/api/recipients/"+id,{method:"DELETE"});loadRecipients()}};
$("saveRecipient").onclick=async()=>{await api("/api/recipients",{method:"POST",body:JSON.stringify({name:$("r_name").value,nip:$("r_nip").value,address:$("r_address").value,city:$("r_city").value})});["r_name","r_nip","r_address","r_city"].forEach(x=>$(x).value="");loadRecipients()};
async function loadMaterials(){
 materials=await api("/api/materials");
 $("materialNames").innerHTML=materials.map(m=>`<option value="${esc(m.name)}"></option>`).join("");
 $("materialIndexes").innerHTML=materials.map(m=>`<option value="${esc(m.index_no)}"></option>`).join("");
 if($("materials"))$("materials").innerHTML=materials.map(m=>`<tr><td>${esc(m.index_no)}</td><td>${esc(m.name)}</td><td>${esc(m.unit)}</td><td>${Number(m.default_price).toFixed(2)}</td><td><button class="danger small" onclick="delMaterial(${m.id})">Usuń</button></td></tr>`).join("");
}
window.delMaterial=async id=>{if(confirm("Usunąć materiał?")){await api("/api/materials/"+id,{method:"DELETE"});loadMaterials()}};
$("saveMaterial").onclick=async()=>{await api("/api/materials",{method:"POST",body:JSON.stringify({index_no:$("m_index").value,name:$("m_name").value,unit:$("m_unit").value,default_price:Number($("m_price").value||0)})});["m_index","m_name","m_price"].forEach(x=>$(x).value="");loadMaterials()};
function findMaterial(tr){
 const idx=tr.querySelector(".idx").value.trim().toLocaleLowerCase("pl"), name=tr.querySelector(".name").value.trim().toLocaleLowerCase("pl");
 return materials.find(m=>(idx && m.index_no.toLocaleLowerCase("pl")===idx)||(name && m.name.toLocaleLowerCase("pl")===name));
}
function syncMaterial(tr){
 const m=findMaterial(tr);
 if(m){tr.querySelector(".idx").value=m.index_no;tr.querySelector(".name").value=m.name;tr.querySelector(".unit").value=m.unit;tr.querySelector(".price").value=m.default_price;tr.querySelector(".saveMat").classList.add("hidden")}
 else tr.querySelector(".saveMat").classList.toggle("hidden",!(tr.querySelector(".idx").value.trim()&&tr.querySelector(".name").value.trim()));
 calc();
}
function addRow(m){
 let tr=document.createElement("tr");
 tr.innerHTML=`<td><input class="idx" list="materialIndexes" value="${esc(m?.index_no||"")}" placeholder="Indeks"></td><td><input class="name" list="materialNames" value="${esc(m?.name||"")}" placeholder="Nazwa materiału"></td><td><input class="planned" type="number" step="0.001" value="${m?.quantity_planned??0}"></td><td><input class="unit" value="${esc(m?.unit||"szt.")}"></td><td><input class="issued" type="number" step="0.001" value="${m?.quantity_issued??0}"></td><td><input class="price" type="number" step="0.01" value="${m?.price??m?.default_price??0}"></td><td><input class="account" value="${esc(m?.account_no||"")}"></td><td><button class="secondary small saveMat hidden">Dodaj do bazy</button><button class="danger small remove">×</button></td>`;
 tr.querySelector(".remove").onclick=()=>{tr.remove();calc()};
 tr.querySelector(".idx").addEventListener("input",()=>{const q=tr.querySelector(".idx").value.trim().toLocaleLowerCase("pl");const m=materials.find(x=>x.index_no.toLocaleLowerCase("pl")===q);if(m)syncMaterial(tr);else tr.querySelector(".saveMat").classList.toggle("hidden",!(q&&tr.querySelector(".name").value.trim()))});
 tr.querySelector(".name").addEventListener("input",()=>{const q=tr.querySelector(".name").value.trim().toLocaleLowerCase("pl");const m=materials.find(x=>x.name.toLocaleLowerCase("pl")===q);if(m)syncMaterial(tr);else tr.querySelector(".saveMat").classList.toggle("hidden",!(q&&tr.querySelector(".idx").value.trim()))});
 tr.querySelector(".saveMat").onclick=async()=>{try{let obj={index_no:tr.querySelector(".idx").value.trim(),name:tr.querySelector(".name").value.trim(),unit:tr.querySelector(".unit").value||"szt.",default_price:Number(tr.querySelector(".price").value||0)};if(!obj.name)throw Error("Wpisz nazwę materiału.");await api("/api/materials",{method:"POST",body:JSON.stringify(obj)});await loadMaterials();syncMaterial(tr);alert("Materiał dodany do bazy.")}catch(e){alert(e.message)}};
 tr.querySelectorAll("input").forEach(i=>i.addEventListener("input",calc));
 $("items").appendChild(tr);calc();
}
$("addrow").onclick=()=>addRow();
function val(tr,cls){return tr.querySelector("."+cls).value}
function calc(){let total=0;document.querySelectorAll("#items tr").forEach(tr=>total+=Number(val(tr,"issued")||0)*Number(val(tr,"price")||0));$("total").textContent="Wartość razem: "+total.toFixed(2).replace(".",",")+" zł"}
$("save").onclick=async()=>{
 try{
  const trs=[...$("items").querySelectorAll("tr")];
  const rows=trs.map((tr,i)=>({index_no:val(tr,"idx").trim(),name:val(tr,"name").trim(),quantity_planned:Number(val(tr,"planned")||0),unit:val(tr,"unit").trim()||"szt.",quantity_issued:Number(val(tr,"issued")||0),price:Number(val(tr,"price")||0),account_no:val(tr,"account").trim()}));
  const invalid=rows.findIndex(x=>!x.name);
  if(invalid>=0)throw Error(`Pozycja ${invalid+1}: uzupełnij nazwę materiału albo usuń pusty wiersz.`);
  if(!rows.length)throw Error("Dodaj przynajmniej jedną pozycję.");
  const body={recipient_id:selectedRecipientId,recipient_name:$("recipient_name").value.trim(),recipient_nip:$("recipient_nip").value,recipient_address:$("recipient_address").value,issue_date:$("issue_date").value,warehouse_no:$("warehouse_no").value,transport:$("transport").value,order_no:$("order_no").value,purpose:$("purpose").value,dispatch_date:$("dispatch_date").value,shipping_cost:$("shipping_cost").value,invoice_ref:$("invoice_ref").value,issuer:$("issuer").value,approver:$("approver").value,items:rows};
  if(!body.recipient_name)throw Error("Wpisz lub wybierz odbiorcę.");
  let result;
  if(editingId){result=await api("/api/documents/"+editingId,{method:"PUT",body:JSON.stringify(body)});result.id=editingId;$("notice").textContent="Zaktualizowano dokument."}
  else{result=await api("/api/documents",{method:"POST",body:JSON.stringify(body)});$("notice").textContent="Zapisano dokument "+result.number}
  window.open(`/api/documents/${result.id}/pdf`,"_blank");editingId=null;$("cancelEdit").classList.add("hidden");$("save").textContent="Zapisz WZ i wygeneruj PDF";await loadArchive();
 }catch(e){alert("Nie udało się zapisać: "+e.message)}
};
$("cancelEdit").onclick=()=>{editingId=null;$("cancelEdit").classList.add("hidden");$("save").textContent="Zapisz WZ i wygeneruj PDF";$("items").innerHTML="";addRow();$("notice").textContent="Anulowano edycję."};
window.editDocument=async id=>{
 let d=await api("/api/documents/"+id);editingId=id;page("new");selectedRecipientId=d.recipient_id||null;
 $("recipient_search").value=d.recipient_name;
 ["recipient_name","recipient_nip","recipient_address","issue_date","warehouse_no","transport","order_no","purpose","dispatch_date","shipping_cost","invoice_ref","issuer","approver"].forEach(k=>$(k).value=d[k]||"");
 $("items").innerHTML="";d.items.forEach(it=>addRow(it));calc();$("cancelEdit").classList.remove("hidden");$("save").textContent="Zapisz zmiany i wygeneruj PDF";$("notice").textContent="Edycja dokumentu "+d.number;
};
async function loadArchive(){let p=new URLSearchParams({q:$("search").value,date_from:$("from").value,date_to:$("to").value});let rows=await api("/api/documents?"+p);$("archive").innerHTML=rows.map(d=>`<tr><td><b>${esc(d.number)}</b></td><td>${esc(d.issue_date)}</td><td>${esc(d.recipient_name)}</td><td>${esc(d.recipient_nip)}</td><td><button class="small" onclick="editDocument(${d.id})">Edytuj</button> <button class="small" onclick="window.open('/api/documents/${d.id}/pdf','_blank')">PDF</button></td></tr>`).join("")||'<tr><td colspan="5" class="muted">Brak dokumentów spełniających kryteria.</td></tr>'}
$("filter").onclick=loadArchive;
async function loadCompany(){let c=await api("/api/settings/company");for(let k of ["name","nip","address","postal_code","city","phone","email","extra"])$("c_"+k).value=c[k]||""}
$("saveCompany").onclick=async()=>{let x={};for(let k of ["name","nip","address","postal_code","city","phone","email","extra"])x[k]=$("c_"+k).value;await api("/api/settings/company",{method:"PUT",body:JSON.stringify(x)});alert("Dane firmy zapisane.")};
loadRecipients();loadMaterials();addRow();
